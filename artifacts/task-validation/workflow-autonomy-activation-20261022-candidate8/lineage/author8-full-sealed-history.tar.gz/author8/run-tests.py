import subprocess,os,json,pathlib,sys,time,hashlib
p=pathlib.Path('/tmp/clinicos-autonomy-activation-20261022');a=p/'author8';label=sys.argv[1];args=sys.argv[2:]
if (a/(label+'.json')).exists() or (a/(label+'.log')).exists(): raise RuntimeError('Evidence labels cannot be overwritten')
env={'PATH':'/usr/bin:/bin','TMPDIR':str(a/'owned-tmp'),'LANG':'C.UTF-8','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_COUNT':'2','GIT_CONFIG_KEY_0':'core.hooksPath','GIT_CONFIG_VALUE_0':'/dev/null','GIT_CONFIG_KEY_1':'protocol.allow','GIT_CONFIG_VALUE_1':'never'}
cmd=['/tmp/clinicos-node22-native12/node_modules/node/bin/node',*args];t=time.time()
r=subprocess.run(cmd,cwd=p/'source8',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
(a/(label+'.log')).write_bytes(r.stdout)
result={'command':cmd,'cwd':str(p/'source8'),'environment':env,'exitCode':r.returncode,'seconds':time.time()-t,'logSha256':hashlib.sha256(r.stdout).hexdigest()}
(a/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(r.stdout.decode()[-6500:]);print('EXIT',r.returncode)
