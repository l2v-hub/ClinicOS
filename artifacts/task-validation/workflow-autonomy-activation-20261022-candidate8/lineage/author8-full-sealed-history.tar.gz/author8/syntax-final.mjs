import {readFile,writeFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const root='/tmp/clinicos-autonomy-activation-20261022';
const old=JSON.parse(await readFile(`${root}/author7/syntax-final.json`,'utf8'));
const files=[...new Set([...old.results.map(x=>x.path),'agent-team/tests/bug-pipeline/git-data-state-fixture.mjs'])];
const results=[];
for(const path of files){const source=await readFile(`${root}/source8/${path}`),args=['--check',`${root}/source8/${path}`],r=spawnSync(process.execPath,args,{encoding:'utf8',env:process.env});results.push({path,command:[process.execPath,...args],exitCode:r.status,stdout:r.stdout,stderr:r.stderr,sourceSha256:createHash('sha256').update(source).digest('hex')});}
const out={status:results.every(x=>x.exitCode===0)?'PASS':'FAIL',checked:files.length,results};
await writeFile(`${root}/author8/syntax-final.json`,JSON.stringify(out,null,2)+'\n');console.log(JSON.stringify({status:out.status,checked:files.length,failed:results.filter(x=>x.exitCode!==0)}));process.exitCode=out.status==='PASS'?0:1;
