import ts from '/workspace/ClinicOS/node_modules/typescript/lib/typescript.js';
import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const root='/tmp/clinicos-autonomy-activation-20261022',rows=[];
const printer=ts.createPrinter({removeComments:true});
function tests(source){const file=ts.createSourceFile('test.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),out=[];function visit(n){if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='test')out.push(printer.printNode(ts.EmitHint.Expression,n,file));ts.forEachChild(n,visit)}visit(file);return out;}
for(const name of ['comment-review-handoff.test.mjs','standalone-review.test.mjs']){
 const before=await readFile(`${root}/author8/scope-before-${name}`,'utf8'),after=await readFile(`${root}/source8/agent-team/tests/bug-pipeline/${name}`,'utf8');const a=tests(before),b=tests(after);assert.deepEqual(b,a,'All original test calls/assertions must remain semantically verbatim');rows.push({name,testCalls:a.length,unchanged:true,normalizedTestCallsSha256:createHash('sha256').update(JSON.stringify(a)).digest('hex')});
}
await writeFile(`${root}/author8/role-assertion-preservation.json`,JSON.stringify({method:'TypeScript parse + removeComments printer canonicalizes each test(...) call; all statements/literals/assertions identical before/after fixture integration',rows},null,2)+'\n');console.log(JSON.stringify(rows));
