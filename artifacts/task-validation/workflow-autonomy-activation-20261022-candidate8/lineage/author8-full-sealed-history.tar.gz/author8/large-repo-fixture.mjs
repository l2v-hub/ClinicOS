export { gitDataStateFixture } from '../source8/agent-team/tests/bug-pipeline/git-data-state-fixture.mjs';
