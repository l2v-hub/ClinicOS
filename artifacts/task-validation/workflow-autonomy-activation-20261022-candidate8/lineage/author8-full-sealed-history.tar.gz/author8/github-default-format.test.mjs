import test from "node:test";
import assert from "node:assert/strict";
import {
  createGitHub,
  MAX_DURABLE_STATE_BYTES,
  RESULT_RESERVATION_BYTES,
  pendingResultBytes,
  controllerFailureCode,
} from "../../src/bug-pipeline/github.mjs";
import { createHash } from "node:crypto";

test("issue lifecycle uses additive managed labels and closes resolved issues as completed, with retry after a failed close", async () => {
  const calls = [];
  let failClose = true;
  const gh = createGitHub({
    repo: "l2v-hub/ClinicOS",
    cwd: "/tmp",
    run: async ({ args, input }) => {
      calls.push({ args, body: input ? JSON.parse(input) : null });
      if (args.includes("PATCH") && failClose) {
        failClose = false;
        return response({}, { ok: false, code: 1, stderr: "HTTP 503" });
      }
      return response({});
    },
  });
  await gh.setIssueStatus(17, "In progress");
  assert.equal(
    calls.some((call) => call.args.includes("PATCH")),
    false,
  );
  await assert.rejects(gh.setIssueStatus(17, "Risolto"), /503/);
  await gh.setIssueStatus(17, "Risolto");
  const patches = calls.filter((call) => call.args.includes("PATCH"));
  assert.equal(patches.length, 2);
  assert.deepEqual(patches[1].body, {
    state: "closed",
    state_reason: "completed",
  });
  assert.ok(
    calls
      .filter((call) => call.args.includes("DELETE"))
      .every((call) =>
        /\/labels\/(In%20progress|Risolto|Bloccato)$/.test(call.args[1]),
      ),
  );
  const count = calls.length;
  await gh.setIssueStatus(17, "Risolto");
  assert.equal(calls.length, count);
  await assert.rejects(gh.setIssueStatus(17, "approved"), /Invalid/);
});

test("dashboard state reads never initialize a branch, and source permission errors are not treated as an empty queue", async () => {
  const calls = [];
  let forbidden = false;
  const gh = createGitHub({
    repo: "l2v-hub/ClinicOS",
    cwd: "/tmp",
    run: async ({ args }) => {
      calls.push(args);
      return response(
        {},
        { ok: false, code: 1, stderr: forbidden ? "HTTP 403" : "HTTP 404" },
      );
    },
  });
  assert.equal(await gh.readDashboardState(), null);
  assert.ok(calls.every((args) => !args.includes("-X")));
  forbidden = true;
  await assert.rejects(gh.readDashboardState(), /Cannot read/);
});

function response(value, { ok = true, code = 0, stderr = "" } = {}) {
  return { ok, code, stdout: JSON.stringify(value), stderr };
}

function apiPath(args) {
  return args.find((arg, index) => index > 0 && !arg.startsWith("-"));
}

function stateContents(state) {
  return stateContentsBytes(
    Buffer.from(
      typeof state === "string" ? state : JSON.stringify(state),
      "utf8",
    ),
  );
}

function stateContentsBytes(bytes) {
  return {
    type: "file",
    sha: createHash("sha1")
      .update(`blob ${bytes.length}\0`)
      .update(bytes)
      .digest("hex"),
    size: bytes.length,
    encoding: "base64",
    content: bytes.toString("base64"),
  };
}

function blobFromContents(contents, overrides = {}) {
  return {
    sha: contents.sha,
    size: contents.size,
    encoding: "base64",
    content: contents.content,
    ...overrides,
  };
}

function wrappedBase64(value) {
  return value.match(/.{1,76}/g)?.join("\r\n") ?? "";
}

test("a maintainer labeling with the same User identity as the controller PAT is authorized", async () => {
  const calls = [];
  const gh = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args }) => {
      calls.push(args);
      const route = apiPath(args);
      if (route === "user") return response({ login: "alice", type: "User" });
      if (route.includes("/issues?"))
        return response([[{ number: 17, labels: [{ name: "codex-run" }] }]]);
      if (route.includes("/events?"))
        return response([
          [
            {
              event: "labeled",
              label: { name: "codex-run" },
              actor: { login: "alice", type: "User" },
              created_at: "2026-10-17T06:00:00Z",
            },
          ],
        ]);
      if (route.endsWith("/collaborators/alice/permission"))
        return response({ permission: "admin" });
      throw new Error(`Unexpected route ${route}`);
    },
  });
  assert.deepEqual(
    (await gh.discoverQueue()).map((i) => i.number),
    [17],
  );
  assert.ok(
    calls.every((args) => !args.includes("-X")),
    "dashboard discovery is read-only",
  );
  assert.ok(
    calls.every((args) => !apiPath(args).includes("/comments")),
    "a human label needs no slash-command workaround",
  );
});

test("scheduled normalization recovers codex-run without bug only after authorization and never mutates dashboard reads", async () => {
  const writes = [];
  const gh = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args, input }) => {
      const route = apiPath(args);
      if (args.includes("POST")) {
        writes.push({ route, body: JSON.parse(input) });
        return response({});
      }
      if (route.includes("/issues?"))
        return response([
          [
            { number: 17, labels: [{ name: "codex-run" }] },
            { number: 18, labels: [{ name: "codex-run" }] },
            { number: 19, labels: [{ name: "codex-run" }], pull_request: {} },
            {
              number: 20,
              labels: [{ name: "codex-run" }, { name: "ready-for-qa" }],
            },
          ],
        ]);
      if (route.includes("/events?"))
        return response([
          [
            {
              event: "labeled",
              label: { name: "codex-run" },
              actor: {
                login:
                  route.includes("/17/") || route.includes("/20/")
                    ? "alice"
                    : "bob",
                type: "User",
              },
              created_at: "2026-10-17T06:00:00Z",
            },
          ],
        ]);
      if (route.includes("/collaborators/"))
        return response({
          permission: route.includes("/alice/") ? "write" : "triage",
        });
      if (route.includes("/labels/")) return response({});
      throw new Error(`Unexpected route ${route}`);
    },
  });
  assert.deepEqual(
    (await gh.discoverQueue()).map((i) => i.number),
    [17, 20],
  );
  assert.equal(writes.length, 0);
  await gh.discoverQueue({ normalize: true });
  assert.deepEqual(writes, [
    {
      route: "repos/l2v-hub/ClinicOS/issues/17/labels",
      body: { labels: ["bug", "codex-triage", "codex-run"] },
    },
  ]);
});

test("bot and missing actor types cannot self-authorize even if permission lookup would grant admin", async () => {
  for (const type of ["Bot", undefined]) {
    const gh = createGitHub({
      cwd: "/tmp",
      repo: "l2v-hub/ClinicOS",
      run: async ({ args }) => {
        const route = apiPath(args);
        if (route.includes("/issues?"))
          return response([[{ number: 17, labels: [{ name: "codex-run" }] }]]);
        if (route.includes("/events?"))
          return response([
            [
              {
                event: "labeled",
                label: { name: "codex-run" },
                actor: { login: "service-account", type },
                created_at: "2026-10-17T06:00:00Z",
              },
            ],
          ]);
        if (route.includes("/comments?")) return response([[]]);
        throw new Error(`Unexpected authorization or mutation ${route}`);
      },
    });
    assert.deepEqual(await gh.discoverQueue({ normalize: true }), []);
  }
});

test("bot label fallback rejects non-human command metadata and old human commands", async () => {
  for (const command of [
    { type: "Bot", createdAt: "2026-10-17T05:59:00Z" },
    { type: undefined, createdAt: "2026-10-17T05:59:00Z" },
    { type: "User", createdAt: "2026-10-17T03:00:00Z" },
  ]) {
    const gh = createGitHub({
      cwd: "/tmp",
      repo: "l2v-hub/ClinicOS",
      run: async ({ args }) => {
        const route = apiPath(args);
        if (route.includes("/issues?"))
          return response([[{ number: 17, labels: [{ name: "codex-run" }] }]]);
        if (route.includes("/events?"))
          return response([
            [
              {
                event: "labeled",
                label: { name: "codex-run" },
                actor: { login: "github-actions[bot]", type: "Bot" },
                created_at: "2026-10-17T06:00:00Z",
              },
            ],
          ]);
        if (route.includes("/comments?"))
          return response([
            [
              {
                body: "/codex fix",
                user: { login: "alice", type: command.type },
                created_at: command.createdAt,
              },
            ],
          ]);
        throw new Error(`Unexpected authorization or mutation ${route}`);
      },
    });
    assert.deepEqual(await gh.discoverQueue({ normalize: true }), []);
  }
});

test("authorized accepts only write-capable collaborators", async () => {
  const run = async ({ args }) => {
    const path = apiPath(args);
    if (path.endsWith("/alice/permission"))
      return response({ permission: "write" });
    if (path.endsWith("/bob/permission"))
      return response({ permission: "triage" });
    return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
  };
  const gh = createGitHub({ cwd: "/tmp", repo: "l2v-hub/ClinicOS", run });
  assert.equal(await gh.authorized("alice"), true);
  assert.equal(await gh.authorized("bob"), false);
  assert.equal(await gh.authorized("bad login"), false);
});

test("intake requires exact command and authorized actor before adding all queue labels", async () => {
  const calls = [];
  const run = async ({ args, input }) => {
    calls.push({ args, input });
    const path = apiPath(args);
    if (path.endsWith("/collaborators/alice/permission"))
      return response({ permission: "maintain" });
    if (
      path.endsWith("/labels/bug") ||
      path.endsWith("/labels/codex-triage") ||
      path.endsWith("/labels/codex-run")
    ) {
      return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
    }
    return response({});
  };
  const gh = createGitHub({ cwd: "/tmp", repo: "l2v-hub/ClinicOS", run });
  assert.deepEqual(
    await gh.intake({
      action: "created",
      sender: { login: "alice" },
      issue: { number: 17 },
      comment: { body: "  /codex fix\n", user: { login: "alice" } },
    }),
    [17],
  );
  const apply = calls.find(
    (call) =>
      call.args[0] === "api" &&
      call.args[1] === "repos/l2v-hub/ClinicOS/issues/17/labels",
  );
  assert.deepEqual(JSON.parse(apply.input), {
    labels: ["bug", "codex-triage", "codex-run"],
  });
  assert.equal(
    calls.some((call) => call.args.includes("shell")),
    false,
  );
});

test("intake refuses unauthorized actors, near-match commands, and pull requests", async () => {
  const calls = [];
  const run = async (call) => {
    calls.push(call);
    return response({ permission: "read" });
  };
  const gh = createGitHub({ cwd: "/tmp", repo: "l2v-hub/ClinicOS", run });
  assert.deepEqual(
    await gh.intake({
      action: "created",
      sender: { login: "alice" },
      issue: { number: 1 },
      comment: { body: "/codex fix it" },
    }),
    [],
  );
  assert.deepEqual(
    await gh.intake({
      action: "created",
      sender: { login: "alice" },
      issue: { number: 1 },
      comment: { body: "/codex fix", user: { login: "bob" } },
    }),
    [],
  );
  assert.deepEqual(
    await gh.intake({
      action: "created",
      sender: { login: "alice" },
      issue: { number: 1, pull_request: {} },
      comment: { body: "/codex fix", user: { login: "alice" } },
    }),
    [],
  );
  assert.equal(calls.length, 0);
});

test("scheduled queue accepts only an authorized explicit codex-run event and skips blocked issues", async () => {
  const run = async ({ args }) => {
    const path = apiPath(args);
    if (
      path ===
      "repos/l2v-hub/ClinicOS/issues?state=open&labels=codex-run&per_page=100"
    )
      return response([
        [
          { number: 10, labels: [{ name: "bug" }, { name: "codex-run" }] },
          { number: 11, labels: [{ name: "bug" }, { name: "codex-run" }] },
          {
            number: 12,
            labels: [
              { name: "bug" },
              { name: "codex-run" },
              { name: "codex-in-flight" },
            ],
          },
          { number: 13, labels: [{ name: "bug" }, { name: "codex-run" }] },
          { number: 14, labels: [{ name: "bug" }, { name: "codex-run" }] },
        ],
      ]);
    if (path === "user")
      return response({}, { ok: false, code: 1, stderr: "HTTP 403" });
    if (path.endsWith("/issues/10/events?per_page=100"))
      return response([
        [
          {
            event: "labeled",
            label: { name: "codex-triage" },
            actor: { login: "alice", type: "User" },
            created_at: "2026-10-16T09:00:00Z",
          },
          {
            event: "labeled",
            label: { name: "codex-run" },
            actor: { login: "alice", type: "User" },
            created_at: "2026-10-16T10:00:00Z",
          },
        ],
      ]);
    if (path.endsWith("/issues/11/events?per_page=100"))
      return response([
        [
          {
            event: "labeled",
            label: { name: "codex-run" },
            actor: { login: "github-actions[bot]", type: "Bot" },
            created_at: "2026-10-16T10:00:00Z",
          },
        ],
      ]);
    if (path.endsWith("/issues/11/comments?per_page=100"))
      return response([[]]);
    if (path.endsWith("/issues/13/events?per_page=100"))
      return response([
        [
          {
            event: "labeled",
            label: { name: "codex-run" },
            actor: { login: "github-actions[bot]", type: "Bot" },
            created_at: "2026-10-16T10:00:00Z",
          },
        ],
      ]);
    if (path.endsWith("/issues/13/comments?per_page=100"))
      return response([
        [
          {
            body: "/codex fix",
            user: { login: "alice", type: "User" },
            created_at: "2026-10-16T09:59:00Z",
          },
        ],
      ]);
    if (path.endsWith("/issues/14/events?per_page=100"))
      return response([
        [
          {
            event: "labeled",
            label: { name: "codex-run" },
            actor: { login: "untrusted-bot[bot]", type: "Bot" },
            created_at: "2026-10-16T10:00:00Z",
          },
        ],
      ]);
    if (path.endsWith("/issues/14/comments?per_page=100"))
      return response([[]]);
    if (path.endsWith("/collaborators/alice/permission"))
      return response({ permission: "write" });
    if (path.endsWith("/collaborators/github-actions/permission"))
      return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
    throw new Error(`unexpected ${args.join(" ")}`);
  };
  const gh = createGitHub({ cwd: "/tmp", repo: "l2v-hub/ClinicOS", run });
  assert.deepEqual(
    (await gh.discoverQueue()).map((issue) => issue.number),
    [10, 13],
  );
});

test("durable state initializes only its branch from main and uses returned Contents SHA", async () => {
  const calls = [];
  const run = async ({ args, input }) => {
    calls.push({ args, input });
    const path = apiPath(args);
    if (path.includes("/git/ref/heads/codex/bug-control"))
      return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
    if (path.endsWith("/git/ref/heads/main"))
      return response({ object: { sha: "a".repeat(40) } });
    if (path.endsWith("/git/refs"))
      return response({ ref: "refs/heads/codex/bug-control" });
    if (path.includes("/.codex-bug-state.json")) {
      if (args.includes("PUT"))
        return response({ content: { sha: "b".repeat(40) } });
      return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
    }
    if (path.startsWith("repos/l2v-hub/ClinicOS/contents/"))
      return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
    throw new Error(`unexpected ${args.join(" ")}`);
  };
  const store = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run,
  }).createStateStore();
  assert.equal(await store.load(), null);
  await store.save({ attempts: { batch: 1 } });
  const branchCreate = calls.find(
    (call) => apiPath(call.args) === "repos/l2v-hub/ClinicOS/git/refs",
  );
  assert.deepEqual(JSON.parse(branchCreate.input), {
    ref: "refs/heads/codex/bug-control",
    sha: "a".repeat(40),
  });
  const write = calls.find(
    (call) => call.args.includes("-X") && call.args.includes("PUT"),
  );
  assert.equal(JSON.parse(write.input).branch, "codex/bug-control");
  assert.equal(JSON.parse(write.input).sha, undefined);
});

test("failed state CAS keeps the remembered SHA and never retries without it", async () => {
  const writes = [];
  const run = async ({ args, input }) => {
    const path = apiPath(args);
    if (path.includes("/git/ref/heads/codex/bug-control"))
      return response({ object: { sha: "a".repeat(40) } });
    if (args.includes("PUT")) {
      writes.push(JSON.parse(input));
      return response({}, { ok: false, code: 1, stderr: "HTTP 409 conflict" });
    }
    if (path.startsWith("repos/l2v-hub/ClinicOS/contents/")) {
      return response(stateContents({ count: 1 }));
    }
    throw new Error(`unexpected ${args.join(" ")}`);
  };
  const store = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run,
  }).createStateStore();
  assert.deepEqual(await store.load(), { count: 1 });
  await assert.rejects(store.save({ count: 2 }), /compare-and-swap/);
  await assert.rejects(store.save({ count: 3 }), /compare-and-swap/);
  assert.equal(writes.length, 2);
  assert.deepEqual(
    writes.map((write) => write.sha),
    [stateContents({ count: 1 }).sha, stateContents({ count: 1 }).sha],
  );
});

test("durable state over 1 MiB loads from one blob read pinned to the Contents SHA", async () => {
  const history = Array.from({ length: 1400 }, (_, index) => ({
    id: index + 1,
    note: `historical review ${index}: ${"x".repeat(900)}`,
  }));
  const expected = { batches: [{ id: "complete-history", reviews: history }] };
  const source = stateContents(expected);
  assert.ok(source.size > 1024 * 1024);
  const calls = [];
  const store = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args, maxOutputBytes }) => {
      const path = apiPath(args);
      calls.push({ path, maxOutputBytes });
      if (path.includes("/git/ref/heads/"))
        return response({ object: { sha: "a".repeat(40) } });
      if (path.includes("/contents/"))
        return response({
          type: "file",
          sha: source.sha,
          size: source.size,
          encoding: "none",
          content: "",
        });
      if (path.endsWith(`/git/blobs/${source.sha}`))
        return response(
          blobFromContents(source, { content: wrappedBase64(source.content) }),
        );
      throw new Error(`Unexpected route ${path}`);
    },
  }).createStateStore();
  assert.deepEqual(await store.load(), expected);
  assert.equal(
    calls.filter(({ path }) => path.includes("/git/blobs/")).length,
    1,
  );
  assert.ok(
    calls
      .filter(
        ({ path }) =>
          path.includes("/contents/") || path.includes("/git/blobs/"),
      )
      .every(({ maxOutputBytes }) => maxOutputBytes >= 8 * 1024 * 1024),
  );
});

test("small valid inline durable state does not read a Git blob", async () => {
  const source = stateContents({ history: [{ id: 1 }, { id: 2 }] });
  const calls = [];
  const store = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args }) => {
      const path = apiPath(args);
      calls.push(path);
      if (path.includes("/git/ref/heads/"))
        return response({ object: { sha: "a".repeat(40) } });
      if (path.includes("/contents/"))
        return response({ ...source, content: wrappedBase64(source.content) });
      throw new Error(`Unexpected route ${path}`);
    },
  }).createStateStore();
  assert.deepEqual(await store.load(), { history: [{ id: 1 }, { id: 2 }] });
  assert.ok(calls.every((path) => !path.includes("/git/blobs/")));
});

test("dashboard state reads use the same pinned blob fallback without branch initialization", async () => {
  const expected = {
    batches: [{ id: "dashboard-state", history: ["first", "second"] }],
  };
  const source = stateContents(expected);
  const calls = [];
  const gh = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args, maxOutputBytes }) => {
      const path = apiPath(args);
      calls.push({ path, maxOutputBytes });
      if (path.includes("/contents/"))
        return response({
          type: "file",
          sha: source.sha,
          size: source.size,
          encoding: "none",
          content: "",
        });
      if (path.endsWith(`/git/blobs/${source.sha}`))
        return response(blobFromContents(source));
      throw new Error(`Unexpected route ${path}`);
    },
  });
  assert.deepEqual(await gh.readDashboardState(), expected);
  assert.equal(calls.length, 2);
  assert.ok(calls.every(({ path }) => !path.includes("/git/ref/heads/")));
  assert.ok(
    calls.every(({ maxOutputBytes }) => maxOutputBytes >= 8 * 1024 * 1024),
  );
});

test("durable state rejects corrupt encoding, size, SHA, UTF-8, and oversized payloads", async (t) => {
  const valid = stateContents({ state: "preserved" });
  const cases = [
    [
      "noncanonical base64",
      { ...valid, content: `${valid.content}!` },
      /content is invalid/,
    ],
    [
      "declared size mismatch",
      { ...valid, size: valid.size + 1 },
      /content is invalid/,
    ],
    ["SHA mismatch", { ...valid, sha: "0".repeat(40) }, /SHA does not match/],
    ["invalid UTF-8", stateContentsBytes(Buffer.from([0xff])), /UTF-8/],
    [
      "oversized metadata",
      { ...valid, size: MAX_DURABLE_STATE_BYTES + 1 },
      /regular file/,
    ],
  ];
  for (const [name, source, expectedError] of cases)
    await t.test(name, async () => {
      const store = createGitHub({
        cwd: "/tmp",
        repo: "l2v-hub/ClinicOS",
        run: async ({ args }) => {
          const path = apiPath(args);
          if (path.includes("/git/ref/heads/"))
            return response({ object: { sha: "a".repeat(40) } });
          if (path.includes("/contents/")) return response(source);
          throw new Error(`Unexpected route ${path}`);
        },
      }).createStateStore();
      await assert.rejects(store.load(), expectedError);
    });
});

test("durable state blob fallback rejects unpinned or malformed data without treating it as empty", async (t) => {
  const source = stateContents({ state: "preserved" });
  for (const [name, fallback, expectedError] of [
    [
      "different SHA",
      blobFromContents(source, { sha: "0".repeat(40) }),
      /pinned Contents object/,
    ],
    [
      "different size",
      blobFromContents(source, { size: source.size + 1 }),
      /pinned Contents object/,
    ],
    [
      "invalid base64",
      blobFromContents(source, { content: "!!!!" }),
      /content is invalid/,
    ],
  ])
    await t.test(name, async () => {
      const store = createGitHub({
        cwd: "/tmp",
        repo: "l2v-hub/ClinicOS",
        run: async ({ args }) => {
          const path = apiPath(args);
          if (path.includes("/git/ref/heads/"))
            return response({ object: { sha: "a".repeat(40) } });
          if (path.includes("/contents/"))
            return response({
              type: "file",
              sha: source.sha,
              size: source.size,
              encoding: "none",
              content: "",
            });
          if (path.includes("/git/blobs/")) return response(fallback);
          throw new Error(`Unexpected route ${path}`);
        },
      }).createStateStore();
      await assert.rejects(store.load(), expectedError);
    });
});

test("durable state load distinguishes a missing file from authorization or transport failures", async () => {
  let failure = "HTTP 404";
  const store = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args }) => {
      const path = apiPath(args);
      if (path.includes("/git/ref/heads/"))
        return response({ object: { sha: "a".repeat(40) } });
      if (path.includes("/contents/"))
        return response({}, { ok: false, code: 1, stderr: failure });
      throw new Error(`Unexpected route ${path}`);
    },
  }).createStateStore();
  assert.equal(await store.load(), null);
  for (failure of ["HTTP 403", "network timeout"])
    await assert.rejects(
      store.load(),
      /Cannot read durable bug pipeline state/,
    );
});

test("oversized durable state is rejected before any remote mutation", async () => {
  const source = stateContents({ ready: true });
  const calls = [];
  const store = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args }) => {
      const path = apiPath(args);
      calls.push(args);
      if (path.includes("/git/ref/heads/"))
        return response({ object: { sha: "a".repeat(40) } });
      if (path.includes("/contents/")) return response(source);
      if (args.includes("PUT"))
        return response({ content: { sha: "b".repeat(40) } });
      throw new Error(`Unexpected route ${path}`);
    },
  }).createStateStore();
  await store.load();
  const before = calls.length;
  await assert.rejects(
    store.save({ history: "x".repeat(MAX_DURABLE_STATE_BYTES) }),
    /8 MiB save bound/,
  );
  assert.equal(calls.length, before);
});

test("review feedback binds to PR head, tracks current reviews, unresolved threads and human comments", async () => {
  const run = async ({ args }) => {
    const path = apiPath(args);
    if (args[0] === "api" && args.includes("graphql")) {
      return response({
        data: {
          repository: {
            pullRequest: {
              reviewThreads: {
                pageInfo: { hasNextPage: false },
                nodes: [{ isResolved: false }],
              },
            },
          },
        },
      });
    }
    if (path === "user") return response({ login: "pipeline-bot" });
    if (path.endsWith("/pulls/42"))
      return response({
        number: 42,
        html_url: "https://github.com/l2v-hub/ClinicOS/pull/42",
        state: "open",
        head: {
          sha: "c".repeat(40),
          ref: "codex/batch-17",
          repo: { full_name: "l2v-hub/ClinicOS", fork: false },
        },
        base: { ref: "main" },
      });
    if (path.endsWith("/reviews?per_page=100"))
      return response([
        [
          {
            id: 1,
            state: "CHANGES_REQUESTED",
            submitted_at: "2026-10-16T10:00:00Z",
            user: { login: "reviewer" },
            body: "old",
          },
          {
            id: 2,
            state: "APPROVED",
            submitted_at: "2026-10-16T11:00:00Z",
            user: { login: "reviewer" },
            body: "looks good",
          },
        ],
      ]);
    if (path.endsWith("/comments?per_page=100") && path.includes("/pulls/42/"))
      return response([
        [
          {
            id: 20,
            body: "real review comment",
            user: { login: "reviewer" },
            path: "src/a.mjs",
            line: 9,
          },
        ],
      ]);
    if (path.endsWith("/issues/42/comments?per_page=100"))
      return response([
        [
          {
            id: 21,
            body: "<!-- codex-bug-pipeline:status -->\nstatus",
            user: { login: "pipeline-bot" },
          },
          { id: 22, body: "human request", user: { login: "reviewer" } },
          {
            id: 23,
            body: "<!-- codex-bug-pipeline:spoof -->\nkeep this",
            user: { login: "reviewer" },
          },
          {
            id: 24,
            body: "<!-- clinicos-source-feedback:batch:17:9:digest:sha -->\nsource regression",
            user: { login: "pipeline-bot" },
          },
        ],
      ]);
    throw new Error(`unexpected ${args.join(" ")}`);
  };
  const result = await createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run,
  }).reviewFeedback(42);
  assert.equal(result.head, "c".repeat(40));
  assert.equal(result.headIsFork, false);
  assert.equal(result.unresolved, true);
  assert.equal(result.changesRequested, false);
  assert.deepEqual(
    result.comments.map((comment) => comment.body),
    [
      "old",
      "looks good",
      "real review comment",
      "human request",
      "<!-- codex-bug-pipeline:spoof -->\nkeep this",
      "<!-- clinicos-source-feedback:batch:17:9:digest:sha -->\nsource regression",
    ],
  );
});

test("review feedback fails closed when more than 100 review threads are returned", async () => {
  const run = async ({ args }) => {
    const path = apiPath(args);
    if (args[0] === "api" && args.includes("graphql")) {
      return response({
        data: {
          repository: {
            pullRequest: {
              reviewThreads: {
                pageInfo: { hasNextPage: true },
                nodes: [{ isResolved: true }],
              },
            },
          },
        },
      });
    }
    if (path === "user")
      return response({}, { ok: false, code: 1, stderr: "HTTP 403" });
    if (path.endsWith("/pulls/42"))
      return response({
        state: "open",
        head: {
          sha: "c".repeat(40),
          ref: "codex/batch-17",
          repo: { full_name: "l2v-hub/ClinicOS" },
        },
        base: { ref: "main" },
      });
    if (path.includes("/reviews?") || path.includes("/comments?"))
      return response([[]]);
    throw new Error(`unexpected ${args.join(" ")}`);
  };
  const result = await createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run,
  }).reviewFeedback(42);
  assert.equal(result.unresolved, true);
});

test("a commented review cannot clear an earlier request for changes; explicit approval can", async () => {
  for (const decision of ["COMMENTED", "PENDING", "APPROVED"]) {
    const run = async ({ args }) => {
      const endpoint = apiPath(args);
      if (args.includes("graphql"))
        return response({
          data: {
            repository: {
              pullRequest: {
                reviewThreads: { pageInfo: { hasNextPage: false }, nodes: [] },
              },
            },
          },
        });
      if (endpoint === "user") return response({ login: "pipeline-bot" });
      if (endpoint.endsWith("/pulls/42"))
        return response({
          state: "open",
          head: {
            sha: "c".repeat(40),
            ref: "codex/batch-17",
            repo: { full_name: "l2v-hub/ClinicOS" },
          },
          base: { ref: "main" },
        });
      if (endpoint.includes("/reviews?"))
        return response([
          [
            {
              id: 1,
              state: "CHANGES_REQUESTED",
              submitted_at: "2026-10-16T10:00:00Z",
              user: { login: "reviewer" },
              body: "Fix the regression",
            },
            {
              id: 2,
              state: decision,
              submitted_at: "2026-10-16T11:00:00Z",
              user: { login: "reviewer" },
              body: "Follow-up",
            },
          ],
        ]);
      if (endpoint.includes("/comments?")) return response([[]]);
      throw new Error("unexpected endpoint");
    };
    const result = await createGitHub({
      cwd: "/tmp",
      repo: "l2v-hub/ClinicOS",
      run,
    }).reviewFeedback(42);
    assert.equal(result.changesRequested, decision !== "APPROVED");
  }
});

test("review feedback identifies a merged PR from the real REST state and merge flag", async () => {
  const run = async ({ args }) => {
    const path = apiPath(args);
    if (args[0] === "api" && args.includes("graphql"))
      return response({
        data: {
          repository: {
            pullRequest: {
              reviewThreads: {
                pageInfo: { hasNextPage: false },
                nodes: [],
              },
            },
          },
        },
      });
    if (path === "user")
      return response({}, { ok: false, code: 1, stderr: "HTTP 403" });
    if (path.endsWith("/pulls/42"))
      return response({
        state: "closed",
        merged: true,
        merge_commit_sha: "d".repeat(40),
        head: {
          sha: "c".repeat(40),
          ref: "codex/batch-17",
          repo: { full_name: "l2v-hub/ClinicOS" },
        },
        base: { ref: "main" },
      });
    if (path.includes("/reviews?") || path.includes("/comments?"))
      return response([[]]);
    throw new Error(`unexpected ${args.join(" ")}`);
  };
  const result = await createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run,
  }).reviewFeedback(42);
  assert.equal(result.state, "MERGED");
  assert.equal(result.mergeCommitSha, "d".repeat(40));
});

test("required checks fail closed when absent and pass only when all reported checks succeed", async () => {
  let checks = [];
  const run = async () => response(checks);
  const gh = createGitHub({ cwd: "/tmp", repo: "l2v-hub/ClinicOS", run });
  assert.equal((await gh.requiredChecks(42)).ok, false);
  checks = [{ name: "build", state: "SUCCESS", bucket: "pass" }];
  assert.equal((await gh.requiredChecks(42)).ok, true);
  checks = [{ name: "build", state: "PENDING", bucket: "pending" }];
  assert.equal((await gh.requiredChecks(42)).ok, false);
  checks = [{ name: "build", state: "FAILURE", bucket: "pass" }];
  assert.equal((await gh.requiredChecks(42)).ok, false);
  checks = [{ name: "build", state: "", bucket: "pass" }];
  assert.equal((await gh.requiredChecks(42)).ok, true);
});

function guardedLifecycle({
  labelExists = true,
  creationConflict = false,
  after,
  failClose = false,
} = {}) {
  const calls = [];
  let held = false,
    triggered = false,
    inspections = 0,
    guardCalls = 0;
  const gh = createGitHub({
    repo: "l2v-hub/ClinicOS",
    cwd: "/tmp",
    run: async ({ args, input }) => {
      const route = args[1],
        method = args.includes("-X") ? args[args.indexOf("-X") + 1] : "GET";
      const step =
        method === "GET" && route.endsWith("/labels/Risolto")
          ? ++inspections === 1
            ? "label-inspection"
            : "label-retry"
          : method === "POST" && route.endsWith("/issues/17/labels")
            ? "issue-label-post"
            : method === "POST" && route.endsWith("/labels")
              ? "label-creation"
              : method === "DELETE" && route.endsWith("/In%20progress")
                ? "delete-progress"
                : method === "DELETE"
                  ? "delete-blocked"
                  : method === "PATCH"
                    ? "close"
                    : "comment";
      calls.push({
        step,
        method,
        route,
        held,
        body: input ? JSON.parse(input) : null,
      });
      await Promise.resolve();
      if (after === step && !triggered) {
        held = true;
        triggered = true;
      }
      if (step === "label-inspection" && !labelExists)
        return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
      if (step === "label-creation" && creationConflict)
        return response({}, { ok: false, code: 1, stderr: "HTTP 422" });
      if (step === "close" && failClose)
        return response({}, { ok: false, code: 1, stderr: "HTTP 503" });
      return response({});
    },
  });
  const guard = async () => {
    guardCalls++;
    assert.equal(held, false, "fresh durable hold");
  };
  return {
    gh,
    calls,
    guard,
    setHeld: (value) => {
      held = value;
    },
    guardCalls: () => guardCalls,
  };
}

test("real status adapter rechecks the optional guard after every preceding awaited API boundary", async (t) => {
  for (const options of [
    { after: "label-inspection" },
    { after: "label-inspection", labelExists: false },
    { after: "label-creation", labelExists: false },
    { after: "label-retry", labelExists: false, creationConflict: true },
    { after: "issue-label-post" },
    { after: "delete-progress" },
    { after: "delete-blocked" },
  ])
    await t.test(JSON.stringify(options), async () => {
      const f = guardedLifecycle(options);
      await assert.rejects(
        f.gh.setIssueStatus(17, "Risolto", { guard: f.guard }),
        /fresh durable hold/,
      );
      assert.equal(
        f.calls.some((call) => call.method !== "GET" && call.held),
        false,
        "No mutation may start with an active hold",
      );
      assert.equal(
        f.calls.some((call) => call.step === "close"),
        false,
      );
      f.setHeld(false);
      await f.gh.setIssueStatus(17, "Risolto", { guard: f.guard });
      assert.equal(
        f.calls.filter((call) => call.step === "close").length,
        1,
        "A prevented operation must not poison the status cache",
      );
    });
});

test("cached lifecycle status still checks a fresh guard and preserves unguarded callers", async () => {
  const f = guardedLifecycle();
  await f.gh.setIssueStatus(17, "Risolto");
  const before = f.calls.length;
  f.setHeld(true);
  await assert.rejects(
    f.gh.setIssueStatus(17, "Risolto", { guard: f.guard }),
    /fresh durable hold/,
  );
  assert.equal(f.calls.length, before);
  f.setHeld(false);
  await f.gh.setIssueStatus(17, "Risolto", { guard: f.guard });
  await f.gh.setIssueStatus(17, "Risolto");
  assert.equal(f.calls.length, before);
  assert.equal(f.guardCalls(), 2);
});

test("actual comment request accepts the optional fresh guard, rejects errors/false/invalid guards, and keeps default callers", async () => {
  const f = guardedLifecycle();
  f.setHeld(true);
  await assert.rejects(
    f.gh.commentIssue(17, "Verified deployment facts", { guard: f.guard }),
    /fresh durable hold/,
  );
  await assert.rejects(
    f.gh.commentIssue(17, "Verified deployment facts", {
      guard: async () => false,
    }),
    /rejected/,
  );
  await assert.rejects(
    f.gh.setIssueStatus(17, "Risolto", { guard: "invalid" }),
    /must be a function/,
  );
  await assert.rejects(
    f.gh.commentIssue(17, "Verified deployment facts", {
      guard: async () => {
        throw Error("State read HTTP403");
      },
    }),
    /HTTP403/,
  );
  assert.equal(f.calls.length, 0);
  await f.gh.commentIssue(17, "Existing non-release protocol");
  assert.equal(f.calls.length, 1);
});

test("a hold arriving after an already-sent close cannot undo that request, but blocks later cached calls", async () => {
  const f = guardedLifecycle({ after: "close" });
  await f.gh.setIssueStatus(17, "Risolto", { guard: f.guard });
  assert.equal(f.calls.find((call) => call.step === "close").held, false);
  const before = f.calls.length;
  await assert.rejects(
    f.gh.setIssueStatus(17, "Risolto", { guard: f.guard }),
    /fresh durable hold/,
  );
  assert.equal(
    f.calls.length,
    before,
    "No later mutation may begin after the in-flight request completes with a hold",
  );
});

test("a partial guarded lifecycle update invalidates an older cached status before reconciliation", async (t) => {
  for (const failure of ["hold", "close503"])
    await t.test(failure, async () => {
      const calls = [];
      let resolving = false,
        held = false;
      const gh = createGitHub({
        repo: "l2v-hub/ClinicOS",
        cwd: "/tmp",
        run: async ({ args, input }) => {
          const body = input ? JSON.parse(input) : null;
          calls.push({ args, body });
          if (
            resolving &&
            failure === "hold" &&
            args.includes("POST") &&
            body?.labels?.includes("Risolto")
          )
            held = true;
          if (resolving && failure === "close503" && args.includes("PATCH"))
            return response({}, { ok: false, code: 1, stderr: "HTTP 503" });
          return response({});
        },
      });
      await gh.setIssueStatus(17, "In progress");
      resolving = true;
      await assert.rejects(
        gh.setIssueStatus(17, "Risolto", {
          guard: async () => {
            if (held) throw Error("Durable hold");
          },
        }),
      );
      resolving = false;
      held = false;
      await gh.setIssueStatus(17, "In progress");
      assert.equal(
        calls.filter((call) => call.body?.labels?.includes("In progress"))
          .length,
        2,
        "Partially changed remote labels must not retain a stale In progress cache hit",
      );
    });
});

test("actual ready and merge transports reject a fresh guard before emitting commands", async () => {
  for (const action of ["draftReady", "mergePullRequest"])
    for (const verdict of [false, "throw"]) {
      const requests = [];
      const gh = createGitHub({
        cwd: "/tmp",
        repo: "l2v-hub/ClinicOS",
        run: async ({ args }) => {
          requests.push(args);
          return response({});
        },
      });
      const guard = async () => {
        await Promise.resolve();
        if (verdict === "throw") throw Error("Changed release subject");
        return false;
      };
      await assert.rejects(
        action === "draftReady"
          ? gh.draftReady(9, { guard })
          : gh.mergePullRequest(9, "a".repeat(40), { guard }),
      );
      assert.deepEqual(requests, []);
    }
});

test("guard rereads cannot promote an old snapshot to a newer Contents CAS revision", async (t) => {
  for (const boundary of ["branch-await", "guard-await"])
    for (const field of ["other batch", "manualBatches", "root field"])
      await t.test(`${boundary}: ${field}`, async () => {
        const original = {
          batches: [
            { id: "target", phase: "ready" },
            { id: "other", progress: 1 },
          ],
          manualBatches: [{ progress: 1 }],
          operatorNote: "original",
        };
        let remote = structuredClone(original),
          version = stateContents(remote).sha,
          changed = false,
          saving = false;
        const writes = [],
          originalVersion = version;
        const change = () => {
          if (changed) return;
          changed = true;
          if (field === "other batch") remote.batches[1].progress = 2;
          else if (field === "manualBatches")
            remote.manualBatches[0].progress = 2;
          else remote.operatorNote = "New operator instruction";
          version = stateContents(remote).sha;
        };
        const gh = createGitHub({
          cwd: "/tmp",
          repo: "l2v-hub/ClinicOS",
          run: async ({ args, input }) => {
            const route = apiPath(args);
            if (route.includes("/git/ref/heads/codex/bug-control")) {
              if (saving && boundary === "branch-await") change();
              return response({ object: { sha: "c".repeat(40) } });
            }
            if (args.includes("PUT")) {
              const body = JSON.parse(input);
              writes.push(body);
              if (body.sha !== version)
                return response(
                  {},
                  { ok: false, code: 1, stderr: "HTTP 409 conflict" },
                );
              remote = JSON.parse(
                Buffer.from(body.content, "base64").toString("utf8"),
              );
              return response({ content: { sha: "d".repeat(40) } });
            }
            if (route.includes("/.codex-bug-state.json"))
              return response(stateContents(remote));
            throw Error(`Unexpected transport ${route}`);
          },
        });
        const store = gh.createStateStore();
        const old = await store.load();
        old.batches[0].phase = "deployed";
        saving = true;
        const guard = async () => {
          if (boundary === "guard-await") change();
          const latest = await store.load();
          assert.deepEqual(
            latest.batches[0],
            original.batches[0],
            "Target is unchanged while another owner updates state",
          );
        };
        await assert.rejects(store.save(old, { guard }), /compare-and-swap/);
        assert.equal(changed, true);
        assert.equal(writes.length, 1);
        assert.equal(
          writes[0].sha,
          originalVersion,
          "Do not adopt the guard read revision for the old body",
        );
        assert.equal(remote.batches[0].phase, "ready");
        if (field === "other batch")
          assert.equal(remote.batches[1].progress, 2);
        else if (field === "manualBatches")
          assert.equal(remote.manualBatches[0].progress, 2);
        else assert.equal(remote.operatorNote, "New operator instruction");
      });
});

test("actual durable PUT waits for a final release guard after branch inspection", async () => {
  const writes = [];
  let held = false,
    saving = false;
  const gh = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args }) => {
      if (args[1].includes("/git/ref/heads/")) {
        if (saving) held = true;
        return response({});
      }
      if (args.includes("PUT")) {
        writes.push(args);
        return response({ content: { sha: "b".repeat(40) } });
      }
      return response(stateContents({}));
    },
  });
  const store = gh.createStateStore();
  await store.load();
  saving = true;
  await assert.rejects(
    store.save(
      { changed: true },
      {
        guard: async () => {
          if (held) throw Error("Fresh hold");
        },
      },
    ),
    /Fresh hold/,
  );
  assert.deepEqual(writes, []);
});

test("failed guarded CAS cannot retry an old state body against the revision read by its guard", async () => {
  const writes = [];
  let remote = { target: "ready", unrelated: "original" },
    version = stateContents(remote).sha;
  const originalVersion = version;
  const gh = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args, input }) => {
      if (args[1].includes("/git/ref/heads/")) return response({});
      if (args.includes("PUT")) {
        const body = JSON.parse(input);
        writes.push(body);
        if (body.sha !== version)
          return response({}, { ok: false, code: 1, stderr: "HTTP 409" });
        remote = JSON.parse(
          Buffer.from(body.content, "base64").toString("utf8"),
        );
        return response({ content: { sha: "c".repeat(40) } });
      }
      return response(stateContents(remote));
    },
  });
  const store = gh.createStateStore(),
    old = await store.load();
  old.target = "deployed";
  const guard = async () => {
    remote.unrelated = "Concurrent update";
    version = stateContents(remote).sha;
    await store.load();
  };
  await assert.rejects(store.save(old, { guard }), /compare-and-swap/);
  await assert.rejects(store.save(old), /compare-and-swap/);
  assert.deepEqual(
    writes.map((body) => body.sha),
    [originalVersion, originalVersion],
  );
  assert.deepEqual(remote, { target: "ready", unrelated: "Concurrent update" });
});

test("optional release guards reject explicitly invalid values at all actual transports", async () => {
  for (const guard of [null, false, "not a function"]) {
    const writes = [];
    const gh = createGitHub({
      cwd: "/tmp",
      repo: "l2v-hub/ClinicOS",
      run: async ({ args }) => {
        if (args[0] === "pr" || args.includes("PUT")) writes.push(args);
        if (args[1].includes("/git/ref/heads/")) return response({});
        return response(stateContents({}));
      },
    });
    const store = gh.createStateStore();
    await store.load();
    await assert.rejects(
      gh.draftReady(9, { guard }),
      /guard must be a function/,
    );
    await assert.rejects(
      gh.mergePullRequest(9, "a".repeat(40), { guard }),
      /guard must be a function/,
    );
    await assert.rejects(store.save({}, { guard }), /guard must be a function/);
    assert.deepEqual(writes, []);
  }
});

test("durable save serializes its body before any branch await can mutate the supplied object", async () => {
  let submitted, written;
  const gh = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args, input }) => {
      if (args[1].includes("/git/ref/heads/")) {
        if (submitted) submitted.target = "Unverified alias mutation";
        return response({});
      }
      if (args.includes("PUT")) {
        written = JSON.parse(input);
        return response({ content: { sha: "b".repeat(40) } });
      }
      return response(stateContents({}));
    },
  });
  const store = gh.createStateStore();
  await store.load();
  submitted = { target: "Verified transition" };
  await store.save(submitted, { guard: async () => true });
  assert.equal(
    submitted.target,
    "Unverified alias mutation",
    "The test actually mutated the submitted reference",
  );
  assert.deepEqual(
    JSON.parse(Buffer.from(written.content, "base64").toString("utf8")),
    {
      target: "Verified transition",
    },
  );
});

function stateBlobFixture(state = { payload: "文".repeat(375000) }) {
  let raw, oid;
  const f = { calls: [], writes: [], failCAS: false };
  f.setRaw = (bytes) => {
    raw = Buffer.from(bytes);
    oid = createHash("sha1")
      .update(`blob ${raw.length}\0`)
      .update(raw)
      .digest("hex");
    f.metadata = {
      type: "file",
      size: raw.length,
      sha: oid,
      encoding: "none",
      content: "",
    };
    f.blob = {
      sha: oid,
      size: raw.length,
      encoding: "base64",
      content:
        raw
          .toString("base64")
          .match(/.{1,60}/g)
          ?.join("\n") ?? "",
    };
  };
  f.setRaw(Buffer.from(JSON.stringify(state, null, 2) + "\n"));
  f.run = async (call) => {
    f.calls.push(call);
    const endpoint = call.args[1];
    if (endpoint.includes("/git/ref/heads/"))
      return response({ object: { sha: "a".repeat(40) } });
    if (call.args.includes("PUT")) {
      const body = JSON.parse(call.input);
      f.writes.push(body);
      if (f.failCAS || body.sha !== oid)
        return response(
          {},
          { ok: false, code: 1, stderr: "HTTP 409 conflict" },
        );
      f.setRaw(Buffer.from(body.content, "base64"));
      return response({ content: { sha: oid } });
    }
    if (endpoint.includes("/contents/.codex-bug-state.json"))
      return response(f.metadata);
    if (endpoint.includes("/git/blobs/")) {
      assert.ok(endpoint.endsWith("/" + f.metadata.sha));
      assert.equal(call.maxOutputBytes, 16 * 1024 * 1024);
      return response(f.blob);
    }
    assert.fail("Unexpected state endpoint " + endpoint);
  };
  f.store = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: f.run,
  }).createStateStore();
  return f;
}

test("large durable state loads from authenticated blob SHA and preserves file identity for Git Data CAS", async () => {
  const state = {
    schemaVersion: 1,
    repository: "l2v-hub/ClinicOS",
    batches: [],
    payload: "文".repeat(375000),
  };
  const f = gitDataStateFixture(state);
  assert.ok(f.metadata.size > 1024 * 1024);
  const oldSHA = f.metadata.sha,
    oldParent = f.head;
  assert.deepEqual(await f.store.load(), state);
  assert.equal(
    f.calls.filter((c) => c.args[1].includes("/git/blobs/")).length,
    1,
  );
  await f.store.save({ ...state, reconciled: true });
  assert.equal(f.refWrites.length, 1);
  assert.equal(f.contentsWrites.length, 0);
  assert.ok(f.calls.some((c) => c.path.endsWith("?ref=" + oldParent)));
  assert.notEqual(f.metadata.sha, oldSHA);
  assert.equal((await f.store.load()).reconciled, true);
});

test("read-only dashboard uses the same large-state blob decoder without branch initialization or writes", async () => {
  const state = { payload: "文".repeat(375000) };
  const f = stateBlobFixture(state);
  const github = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: f.run,
  });
  assert.deepEqual(await github.readDashboardState(), state);
  assert.ok(
    f.calls.every(
      (call) =>
        !call.args[1].includes("/git/ref/") && !call.args.includes("-X"),
    ),
  );
});

test("durable state rejects invalid blob metadata, bytes and digest before authorizing any save", async () => {
  const cases = [
    (f) => (f.metadata.type = "symlink"),
    (f) => (f.metadata.target = "elsewhere"),
    (f) => (f.metadata.submodule_git_url = "https://example.invalid/repo"),
    (f) => (f.metadata.sha = "invalid-sha"),
    (f) => (f.metadata.size = MAX_DURABLE_STATE_BYTES + 1),
    (f) => (f.metadata.size = 1.5),
    (f) => delete f.metadata.size,
    (f) => (f.metadata.content = "unexpected-inline-body"),
    (f) => (f.metadata.encoding = "utf8"),
    (f) => (f.blob.sha = "f".repeat(40)),
    (f) => f.blob.size++,
    (f) => (f.blob.encoding = "none"),
    (f) => (f.blob.content += "@"),
    (f) => {
      f.blob.content = Buffer.from("x".repeat(f.metadata.size)).toString(
        "base64",
      );
    },
    (f) => {
      f.blob.size = f.metadata.size;
      f.blob.content = Buffer.from("{}").toString("base64");
    },
    (f) => f.setRaw(Buffer.from([123, 34, 120, 34, 58, 34, 255, 34, 125])),
    (f) => f.setRaw(Buffer.from("not valid JSON")),
  ];
  for (const change of cases) {
    const f = stateBlobFixture({ payload: "synthetic" });
    change(f);
    await assert.rejects(f.store.load());
    await assert.rejects(
      f.store.save({ shouldNotSave: true }),
      /load durable state/,
    );
    assert.equal(f.writes.length, 0);
  }
});

test("explicit inline state metadata validates canonical base64, supplied size and UTF8 without requiring blob I/O", async () => {
  const state = { counter: 1 };
  const f = stateBlobFixture(state);
  f.metadata.encoding = "base64";
  f.metadata.content = f.blob.content;
  assert.deepEqual(await f.store.load(), state);
  assert.equal(
    f.calls.some((c) => c.args[1].includes("/git/blobs/")),
    false,
  );
  for (const change of [
    (f) => f.metadata.size++,
    (f) => (f.metadata.content += "@"),
    (f) => (f.metadata.encoding = "unexpected"),
  ]) {
    const invalid = stateBlobFixture(state);
    invalid.metadata.encoding = "base64";
    invalid.metadata.content = invalid.blob.content;
    change(invalid);
    await assert.rejects(invalid.store.load());
  }
});

test("state save rejects >8MiB before any mutation/guard and exact8MiB remains reloadable", async () => {
  const f = gitDataStateFixture({});
  await f.store.load();
  const priorCalls = f.calls.length;
  let guards = 0;
  await assert.rejects(
    f.store.save(
      { payload: "x".repeat(MAX_DURABLE_STATE_BYTES) },
      {
        guard: async () => {
          guards++;
        },
      },
    ),
    /8 MiB save bound/,
  );
  assert.equal(guards, 0);
  assert.equal(f.writes.length, 0);
  assert.equal(f.calls.length, priorCalls);
  const overhead = Buffer.byteLength(JSON.stringify({ payload: "" }));
  const exact = { payload: "x".repeat(MAX_DURABLE_STATE_BYTES - overhead) };
  await f.store.save(exact);
  assert.equal(f.metadata.size, MAX_DURABLE_STATE_BYTES);
  assert.equal(
    Buffer.byteLength(JSON.stringify(await f.store.load())),
    MAX_DURABLE_STATE_BYTES,
  );
});

test("blob-loaded state CAS failure retains the original metadata SHA and never retries without it", async () => {
  const f = stateBlobFixture();
  await f.store.load();
  const expected = f.metadata.sha;
  f.failCAS = true;
  await assert.rejects(f.store.save({ attempt: 1 }), /compare-and-swap/);
  await assert.rejects(f.store.save({ attempt: 2 }), /compare-and-swap/);
  assert.deepEqual(
    f.writes.map((body) => body.sha),
    [expected, expected],
  );
});

const entityState = () => ({
  schemaVersion: 1,
  repository: "l2v-hub/ClinicOS",
  batches: [
    { id: "batch-a", implementation: [{ round: 1, status: "running" }] },
    { id: "batch-b", implementation: [] },
  ],
  manualBatches: [{ id: "manual-a", status: "planned" }],
  standaloneReviews: [{ id: "standalone-a", reviews: [] }],
});
const entityValidator = (state) => {
  assert.equal(state.repository, "l2v-hub/ClinicOS");
  for (const key of ["batches", "manualBatches", "standaloneReviews"]) {
    assert.ok(Array.isArray(state[key]));
    assert.equal(
      new Set(state[key].map((item) => item.id)).size,
      state[key].length,
    );
  }
  assert.notEqual(
    state.invalidOwnership,
    true,
    "Full merged ownership validator rejects illegal combinations",
  );
};

test("explicit disjoint rebase saves a NEW validated body and preserves nested caller object/array references", async () => {
  const f = stateBlobFixture(entityState()),
    other = createGitHub({
      cwd: "/tmp",
      repo: "l2v-hub/ClinicOS",
      run: f.run,
    }).createStateStore();
  const ours = await f.store.load(),
    theirs = await other.load();
  const arrays = [ours.batches, ours.manualBatches, ours.standaloneReviews],
    batch = ours.batches[0],
    attempts = batch.implementation,
    attempt = attempts[0],
    manual = ours.manualBatches[0];
  attempt.status = "passed";
  theirs.batches[1].remote = "retained";
  theirs.manualBatches[0].status = "complete";
  theirs.standaloneReviews.push({ id: "standalone-b", reviews: [] });
  theirs.updatedAt = "remote";
  await other.save(theirs);
  const remoteSHA = f.metadata.sha;
  let guards = 0,
    validations = 0;
  await f.store.save(ours, {
    rebaseIndependentSubjects: (state) => {
      validations++;
      entityValidator(state);
    },
    guard: async () => {
      guards++;
      assert.equal(attempt.status, "passed");
    },
  });
  assert.equal(guards, 2);
  assert.equal(validations, 2);
  assert.equal(f.writes.at(-1).sha, remoteSHA);
  const old = JSON.parse(Buffer.from(f.writes.at(-2).content, "base64")),
    fresh = JSON.parse(Buffer.from(f.writes.at(-1).content, "base64"));
  assert.equal(old.batches[1].remote, undefined);
  assert.equal(fresh.batches[1].remote, "retained");
  assert.equal(fresh.batches[0].implementation[0].status, "passed");
  assert.equal(fresh.standaloneReviews.length, 2);
  assert.equal(ours.batches, arrays[0]);
  assert.equal(ours.manualBatches, arrays[1]);
  assert.equal(ours.standaloneReviews, arrays[2]);
  assert.equal(ours.batches[0], batch);
  assert.equal(batch.implementation, attempts);
  assert.equal(attempts[0], attempt);
  assert.equal(ours.manualBatches[0], manual);
  assert.equal(manual.status, "complete");
  attempt.afterRebase = "original reference still live";
  await f.store.save(ours);
  assert.equal(
    (await f.store.load()).batches[0].implementation[0].afterRebase,
    "original reference still live",
  );
});

test("strict default still rejects disjoint409 and opt-in rejects same entity, conflicting root fields and invalid merged state", async () => {
  for (const kind of [
    "strict",
    "same-entity",
    "root-field",
    "invalid-merge",
    "duplicate-id",
  ]) {
    const f = stateBlobFixture(entityState()),
      other = createGitHub({
        cwd: "/tmp",
        repo: "l2v-hub/ClinicOS",
        run: f.run,
      }).createStateStore();
    const a = await f.store.load(),
      b = await other.load();
    a.batches[0].local = true;
    if (kind === "same-entity") b.batches[0].remote = true;
    else if (kind === "root-field") {
      a.shared = { local: true };
      b.shared = { remote: true };
    } else if (kind === "invalid-merge") b.invalidOwnership = true;
    else if (kind === "duplicate-id")
      b.manualBatches.push({ ...b.manualBatches[0] });
    else b.batches[1].remote = true;
    await other.save(b);
    let guards = 0;
    const options = {
      guard: async () => {
        guards++;
      },
      ...(kind === "strict"
        ? {}
        : { rebaseIndependentSubjects: entityValidator }),
    };
    await assert.rejects(f.store.save(a, options));
    assert.equal(guards, 1);
    assert.equal(
      f.writes.length,
      2,
      "No second PUT after unsafe conflict/validation",
    );
    assert.equal(
      JSON.parse(Buffer.from(f.blob.content.replace(/\n/g, ""), "base64"))
        .batches[0].local,
      undefined,
    );
  }
});

test("rebase reruns authorization guard and refuses nonce/subject changes instead of replaying stale authority", async () => {
  const f = stateBlobFixture(entityState()),
    other = createGitHub({
      cwd: "/tmp",
      repo: "l2v-hub/ClinicOS",
      run: f.run,
    }).createStateStore();
  const a = await f.store.load(),
    b = await other.load();
  a.batches[0].local = true;
  b.batches[1].remote = true;
  await other.save(b);
  let guardCalls = 0;
  await assert.rejects(
    f.store.save(a, {
      rebaseIndependentSubjects: entityValidator,
      guard: async () => {
        if (++guardCalls === 2)
          throw new Error("Synthetic authorization revoked");
      },
    }),
    /revoked/,
  );
  assert.equal(guardCalls, 2);
  assert.equal(f.writes.length, 2, "Retry guard prevents second PUT");
  const g = stateBlobFixture(entityState()),
    peer = createGitHub({
      cwd: "/tmp",
      repo: "l2v-hub/ClinicOS",
      run: g.run,
    }).createStateStore();
  const x = await g.store.load(),
    y = await peer.load();
  x.standaloneReviews[0].claimId = "old-claim";
  y.standaloneReviews[0].claimId = "new-claim";
  await peer.save(y);
  await assert.rejects(
    g.store.save(x, { rebaseIndependentSubjects: entityValidator }),
    (error) => error.code === "state-rebase-conflict",
  );
});

test("rebase uses fresh serialized snapshots even when guards reload a third disjoint state, with bounded retries", async () => {
  const f = stateBlobFixture(entityState()),
    other = createGitHub({
      cwd: "/tmp",
      repo: "l2v-hub/ClinicOS",
      run: f.run,
    }).createStateStore();
  const a = await f.store.load(),
    b = await other.load();
  a.batches[0].local = true;
  b.batches[1].remote = 1;
  await other.save(b);
  let guards = 0;
  await f.store.save(a, {
    rebaseIndependentSubjects: entityValidator,
    guard: async () => {
      if (++guards === 2) {
        const third = createGitHub({
          cwd: "/tmp",
          repo: "l2v-hub/ClinicOS",
          run: f.run,
        }).createStateStore();
        const latest = await third.load();
        latest.manualBatches[0].remote = 2;
        await third.save(latest);
        await f.store.load();
      }
    },
  });
  assert.equal(guards, 3);
  const final = await f.store.load();
  assert.equal(final.batches[0].local, true);
  assert.equal(final.batches[1].remote, 1);
  assert.equal(final.manualBatches[0].remote, 2);
  const g = stateBlobFixture(entityState());
  const value = await g.store.load();
  value.batches[0].local = true;
  g.failCAS = true;
  await assert.rejects(
    g.store.save(value, { rebaseIndependentSubjects: entityValidator }),
    (error) => error.code === "state-cas-conflict",
  );
  assert.equal(g.writes.length, 4);
});

test("capacity counts simultaneous running reviews and Codex QA across every entity collection before any PUT or guard", async () => {
  const state = {
    batches: [
      {
        id: "a",
        reviews: [{ status: "running" }],
        externalReview: { status: "running" },
      },
    ],
    manualBatches: [{ id: "b", reviews: [{ status: "running" }] }],
    standaloneReviews: [
      { id: "c", reviews: [], codexFinalReview: { status: "running" } },
    ],
  };
  assert.equal(
    pendingResultBytes(state.batches[0]),
    RESULT_RESERVATION_BYTES,
    "Do not double count one external reservation",
  );
  const overhead = Buffer.byteLength(
    JSON.stringify({ ...state, payload: "" }, null, 2) + "\n",
  );
  state.payload = "x".repeat(
    MAX_DURABLE_STATE_BYTES - overhead - 3 * RESULT_RESERVATION_BYTES - 512,
  );
  const f = gitDataStateFixture({});
  await f.store.load();
  await f.store.save(state);
  const writes = f.writes.length,
    calls = f.calls.length;
  let guards = 0;
  state.standaloneReviews.push({ id: "d", reviews: [{ status: "running" }] });
  await assert.rejects(
    f.store.save(state, {
      guard: async () => {
        guards++;
      },
    }),
    (error) => error.code === "state-capacity-exhausted",
  );
  assert.equal(f.writes.length, writes);
  assert.equal(f.calls.length, calls);
  assert.equal(guards, 0);
  state.standaloneReviews.pop();
  state.batches[0].reviews[0].status = "approved";
  state.batches[0].externalReview.status = "finished";
  state.batches[0].reviewReports = {
    "claude-review-1.json": JSON.stringify({
      subject_sha: "a".repeat(40),
      verdict: "approved",
      summary: "漢".repeat(50000),
      findings: [],
    }),
  };
  await f.store.save(state);
});

test("diagnostics expose only owned bounded codes and preserve known cause chains", () => {
  const privateError = new Error(
    "Synthetic private stderr must not be exposed",
  );
  privateError.code = "arbitrary-untrusted-code";
  assert.equal(
    controllerFailureCode(privateError),
    "controller-execution-failed",
  );
  const cause = Object.assign(new Error("Private underlying text"), {
    code: "state-capacity-exhausted",
  });
  assert.equal(
    controllerFailureCode(new Error("wrapper", { cause })),
    "state-capacity-exhausted",
  );
});

test("F5 state writes distinguish confirmed409, definite502 and uncertain timeout without blind retry", async () => {
  for (const [result, expected] of [
    [
      { ok: false, code: 1, stderr: "HTTP 409 conflict", stdout: "{}" },
      "state-cas-conflict",
    ],
    [
      { ok: false, code: 1, stderr: "HTTP 502", stdout: "{}" },
      "state-write-failed",
    ],
    [
      { ok: false, error: "timeout", stderr: "", stdout: "" },
      "state-write-uncertain",
    ],
  ]) {
    let puts = 0;
    const gh = createGitHub({
      repo: "l2v-hub/ClinicOS",
      cwd: "/tmp",
      run: async ({ args }) => {
        if (args.includes("PUT")) {
          puts++;
          return result;
        }
        if (args[1].includes("/contents/"))
          return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
        return response({ object: { sha: "a".repeat(40) } });
      },
    });
    const store = gh.createStateStore();
    await store.load();
    await assert.rejects(
      store.save({
        schemaVersion: 1,
        repository: "l2v-hub/ClinicOS",
        batches: [],
      }),
      (error) => controllerFailureCode(error) === expected,
    );
    assert.equal(puts, 1);
  }
});

test("F1/F3 native human approval requires current head, nonauthor User and enforced stale-dismissal protection", async () => {
  const head = "a".repeat(40);
  let review = {
    state: "APPROVED",
    commit_id: head,
    submitted_at: "2026-10-18T01:00:00Z",
    user: { login: "human", type: "User" },
  };
  let protectedMain = true;
  const gh = createGitHub({
    repo: "l2v-hub/ClinicOS",
    cwd: "/tmp",
    run: async ({ args }) => {
      const route = args[1];
      if (route.endsWith("/pulls/81"))
        return response({
          state: "open",
          head: { sha: head },
          user: { login: "author" },
        });
      if (route.includes("/reviews?")) return response([[review]]);
      if (route.endsWith("/protection"))
        return protectedMain
          ? response({
              enforce_admins: { enabled: true },
              required_pull_request_reviews: {
                required_approving_review_count: 1,
                dismiss_stale_reviews: true,
              },
            })
          : response({}, { ok: false, code: 1, stderr: "HTTP 404" });
      if (route.includes("/permission"))
        return response({ permission: "write" });
      if (route.endsWith("/rules/branches/main"))
        return response([{ type: "required_status_checks" }]);
      assert.fail(route);
    },
  });
  assert.equal(
    (await gh.nativeReviewAuthorization(81, head)).humanApproved,
    true,
  );
  assert.equal(
    (
      await gh.nativeReviewAuthorization(81, head, {
        excludedLogins: ["human"],
      })
    ).humanApproved,
    false,
  );
  for (const mutation of [
    { user: { login: "author", type: "User" } },
    { user: { login: "automation", type: "Bot" } },
    { commit_id: "b".repeat(40) },
    { state: "DISMISSED" },
  ]) {
    const original = review;
    review = { ...review, ...mutation };
    assert.equal(
      (await gh.nativeReviewAuthorization(81, head)).humanApproved,
      false,
    );
    review = original;
  }
  protectedMain = false;
  assert.equal(
    (await gh.nativeReviewAuthorization(81, head)).humanApproved,
    false,
  );
  await assert.rejects(
    gh.nativeReviewAuthorization(81, "b".repeat(40)),
    /subject changed/,
  );
});

test("GitHub failure semantics distinguish positive status evidence, default POST and merge uncertainty without raw diagnostics", async () => {
  const { githubOperationError, githubApiOperation } =
    await import("../../src/bug-pipeline/github.mjs");
  assert.equal(githubApiOperation({ body: { body: "notice" } }), "mutation");
  assert.equal(githubApiOperation({}), "read");
  assert.equal(githubApiOperation({ method: "GET", body: {} }), "read");
  for (const status of [401, 403, 404, 422]) {
    const error = githubOperationError({
      stderr: `gh: denied (HTTP ${status})`,
    });
    assert.equal(error.code, "github-read-rejected");
    assert.equal(error.httpStatus, status);
  }
  for (const status of [408, 429, 500, 503])
    assert.equal(
      githubOperationError({ stderr: `gh: rejected (HTTP ${status})` }).code,
      "github-read-transient",
    );
  assert.equal(
    githubOperationError({ stderr: "gh: API rate limit exceeded (HTTP 403)" })
      .code,
    "github-read-transient",
  );
  assert.equal(
    githubOperationError({ error: "timeout" }).code,
    "github-read-transient",
  );
  const unknown = githubOperationError({
    stderr: "synthetic patient 503 bearer PRIVATE_TOKEN " + "x".repeat(100000),
  });
  assert.equal(unknown.httpStatus, null);
  assert.equal(unknown.code, "github-read-failed");
  assert.ok(JSON.stringify(unknown).length < 300);
  assert.doesNotMatch(JSON.stringify(unknown), /PRIVATE_TOKEN|patient/);
  for (const [response, expected] of [
    [{ stderr: "gh: protected (HTTP 405)" }, "github-write-rejected"],
    [{ error: "timeout" }, "github-write-uncertain"],
    [{ stderr: "gh: upstream (HTTP 503)" }, "github-write-uncertain"],
  ]) {
    const calls = [];
    const github = createGitHub({
      repo: "l2v-hub/ClinicOS",
      cwd: "/synthetic",
      run: async (call) => {
        calls.push(call);
        return { ok: false, ...response };
      },
    });
    await assert.rejects(github.mergePullRequest(81, "a".repeat(40)), {
      code: expected,
    });
    assert.equal(calls.length, 1, "No blind second merge attempt");
    assert.equal(calls[0].timeoutMs, 30000);
    await assert.rejects(github.commentPR(81, "Synthetic notice"), {
      code: expected,
    });
    assert.ok(calls.at(-1).input, "Comment request carries a mutation body");
  }

  const refusal =
    "GraphQL: Head branch was modified. Review and try the merge again. (mergePullRequest)";
  for (const [result, expectedCode, expectedDiagnostic] of [
    [
      { ok: false, code: 1, stderr: refusal },
      "github-write-rejected",
      "graphql-merge-refusal",
    ],
    [
      { ok: false, code: 1, stderr: `prefix ${refusal}` },
      "github-write-uncertain",
      "unknown",
    ],
    [
      {
        ok: false,
        code: 1,
        stderr: `${refusal}\nGraphQL: another error (mergePullRequest)`,
      },
      "github-write-uncertain",
      "unknown",
    ],
    [
      { ok: false, code: 1, stderr: refusal, error: "spawn-failed" },
      "github-write-uncertain",
      "spawn-failed",
    ],
    [
      { ok: false, code: null, stderr: refusal, error: "timeout" },
      "github-write-uncertain",
      "timeout",
    ],
    [
      { ok: false, code: 0, stderr: refusal },
      "github-write-uncertain",
      "unknown",
    ],
  ]) {
    const gh = createGitHub({
      repo: "l2v-hub/ClinicOS",
      cwd: "/synthetic",
      run: async () => result,
    });
    await assert.rejects(gh.mergePullRequest(81, "a".repeat(40)), (error) => {
      assert.equal(error.code, expectedCode);
      assert.equal(error.diagnostic, expectedDiagnostic);
      assert.equal(error.operation, "merge");
      assert.equal(error.httpStatus, null);
      assert.doesNotMatch(JSON.stringify(error), /Head branch|GraphQL/);
      return true;
    });
  }
  const wrongOperation = createGitHub({
    repo: "l2v-hub/ClinicOS",
    cwd: "/synthetic",
    run: async () => ({ ok: false, code: 1, stderr: refusal }),
  });
  await assert.rejects(wrongOperation.commentPR(81, "Synthetic notice"), {
    code: "github-write-uncertain",
    diagnostic: "unknown",
  });
});

test("strict integrated decoder rejects JSON scalars/arrays and oversized raw wrapping without permitting a save", async () => {
  for (const contents of [
    stateContents(null),
    stateContents([]),
    stateContents(7),
    {
      ...stateContents({}),
      content: stateContents({}).content + "\n".repeat(12 * 1024 * 1024),
    },
  ]) {
    const writes = [];
    const store = createGitHub({
      repo: "l2v-hub/ClinicOS",
      cwd: "/synthetic",
      run: async (call) => {
        if (call.args.includes("PUT")) {
          writes.push(call);
          assert.fail("Invalid state must not authorize a save");
        }
        return response(
          apiPath(call.args).includes("/git/ref/heads/")
            ? { object: { sha: "a".repeat(40) } }
            : contents,
        );
      },
    }).createStateStore();
    await assert.rejects(store.load(), /JSON object|metadata is invalid/);
    await assert.rejects(
      store.save({ replacement: true }),
      /load durable state/,
    );
    assert.equal(writes.length, 0);
  }
});

test("evidence blobs accept the exact 32MiB ceiling with bounded base64 JSON transport", async () => {
  const { MAX_EVIDENCE_BYTES, MAX_EVIDENCE_TRANSPORT_BYTES } =
    await import("../../src/bug-pipeline/evidence-limits.mjs");
  const bytes = Buffer.alloc(MAX_EVIDENCE_BYTES, 37);
  const oid = createHash("sha1")
    .update(`blob ${bytes.length}\0`)
    .update(bytes)
    .digest("hex");
  let limit;
  const gh = createGitHub({
    repo: "l2v-hub/ClinicOS",
    cwd: "/tmp",
    run: async ({ args, maxOutputBytes }) => {
      if (args[1].includes("/contents/"))
        return response({ type: "file", sha: oid, size: bytes.length });
      limit = maxOutputBytes;
      return response({
        sha: oid,
        encoding: "base64",
        size: bytes.length,
        content: bytes.toString("base64").replace(/.{76}/g, "$&\n"),
      });
    },
  });
  const actual = await gh.readFileAtRevision(
    "artifacts/trace.zip",
    "a".repeat(40),
  );
  assert.equal(actual.bytes, MAX_EVIDENCE_BYTES);
  assert.equal(actual.sha256, createHash("sha256").update(bytes).digest("hex"));
  assert.equal(actual.content, undefined);
  assert.equal(limit, MAX_EVIDENCE_TRANSPORT_BYTES);
});

test("evidence blob ceiling, declared sizes, canonical base64 and object digest fail closed", async () => {
  const { MAX_EVIDENCE_BYTES } =
    await import("../../src/bug-pipeline/evidence-limits.mjs");
  const bytes = Buffer.alloc(32, 23);
  const oid = createHash("sha1")
    .update(`blob ${bytes.length}\0`)
    .update(bytes)
    .digest("hex");
  for (const change of [
    "over-limit",
    "metadata-size",
    "blob-size",
    "object-sha",
    "payload-hash",
    "base64",
  ]) {
    let blobReads = 0;
    const metadata = { type: "file", sha: oid, size: bytes.length };
    const blob = {
      sha: oid,
      encoding: "base64",
      size: bytes.length,
      content: bytes.toString("base64"),
    };
    if (change === "over-limit") metadata.size = MAX_EVIDENCE_BYTES + 1;
    if (change === "metadata-size") metadata.size++;
    if (change === "blob-size") blob.size++;
    if (change === "object-sha") blob.sha = "f".repeat(40);
    if (change === "payload-hash")
      blob.content = Buffer.alloc(32, 24).toString("base64");
    if (change === "base64") blob.content += "!";
    const gh = createGitHub({
      repo: "l2v-hub/ClinicOS",
      cwd: "/tmp",
      run: async ({ args }) => {
        if (args[1].includes("/contents/")) return response(metadata);
        blobReads++;
        return response(blob);
      },
    });
    await assert.rejects(
      gh.readFileAtRevision("artifacts/trace.zip", "a".repeat(40)),
      /size|base64/,
      change,
    );
    if (change === "over-limit") assert.equal(blobReads, 0);
  }
});

test("recovery authorization requires actual authenticated owner/admin and fixed manual main workflow identity", async () => {
  const context = {
    repository: "l2v-hub/ClinicOS",
    eventName: "workflow_dispatch",
    ref: "refs/heads/main",
    workflowRef:
      "l2v-hub/ClinicOS/.github/workflows/codex-bug-release.yml@refs/heads/main",
    actor: "l2v-hub",
    triggeringActor: "l2v-hub",
    sha: "a".repeat(40),
    workflowSha: "a".repeat(40),
  };
  for (const change of [
    null,
    "user",
    "permission",
    "actor",
    "trigger",
    "event",
    "ref",
    "workflow",
    "sha",
    "repo",
  ]) {
    let login = "l2v-hub",
      permission = "admin";
    const input = { ...context };
    if (change === "user") login = "impostor";
    if (change === "permission") permission = "maintain";
    if (change === "actor") input.actor = "other";
    if (change === "trigger") input.triggeringActor = "other";
    if (change === "event") input.eventName = "workflow_run";
    if (change === "ref") input.ref = "refs/heads/feature";
    if (change === "workflow") input.workflowRef = "other.yml";
    if (change === "sha") input.workflowSha = "b".repeat(40);
    if (change === "repo") input.repository = "other/repo";
    const run = async ({ args }) =>
      response(
        args[1] === "user"
          ? { login }
          : { permission, user: { login: "l2v-hub" } },
      );
    const github = createGitHub({ repo: "l2v-hub/ClinicOS", cwd: "/tmp", run });
    if (change) await assert.rejects(github.authorizeReleaseRecovery(input));
    else assert.equal(await github.authorizeReleaseRecovery(input), "l2v-hub");
  }
});

test("queue exclusions prevent normalization and authorization reads on claimed issues while new missed events recover", async () => {
  const calls = [];
  const gh = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async ({ args, input }) => {
      const route = apiPath(args);
      calls.push({ route, args, input });
      if (route.includes("/issues?"))
        return response([
          [17, 18].map((number) => ({
            number,
            labels: [{ name: "codex-run" }],
          })),
        ]);
      if (route.includes("/events?")) {
        assert.ok(
          !route.includes("/17/"),
          "owned issue must be filtered before any normalization work",
        );
        return response([
          [
            {
              event: "labeled",
              label: { name: "codex-run" },
              actor: { login: "alice", type: "User" },
              created_at: "2026-10-22T00:00:00Z",
            },
          ],
        ]);
      }
      if (route.endsWith("/collaborators/alice/permission"))
        return response({ permission: "write" });
      if (route.includes("/labels/")) return response({});
      if (route.endsWith("/issues/18/labels") && args.includes("POST"))
        return response({});
      assert.fail("Unexpected route " + route);
    },
  });
  assert.deepEqual(
    (await gh.discoverQueue({ normalize: true, excludeIssues: [17] })).map(
      (x) => x.number,
    ),
    [18],
  );
  assert.deepEqual(
    calls.filter((x) => x.args.includes("POST")).map((x) => x.route),
    ["repos/l2v-hub/ClinicOS/issues/18/labels"],
  );
});
test("malformed queue exclusions fail closed before any GitHub read or label write", async () => {
  const gh = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: async () => assert.fail("no transport"),
  });
  for (const excludeIssues of [
    null,
    {},
    "17",
    [0],
    [-1],
    [1.5],
    ["17"],
    [Number.MAX_SAFE_INTEGER + 1],
  ])
    await assert.rejects(
      gh.discoverQueue({ normalize: true, excludeIssues }),
      /Invalid excluded/,
    );
});

test("Claude1 F5 read-only observation never promotes a writer base or bypasses native409", async () => {
  const f = stateBlobFixture(entityState());
  const ours = await f.store.load();
  ours.batches[0].local = "pending";
  const remote = entityState();
  remote.batches[1].remote = "preserved";
  f.setRaw(Buffer.from(JSON.stringify(remote)));
  assert.equal((await f.store.observe()).batches[1].remote, "preserved");
  await f.store.save(ours, { rebaseIndependentSubjects: entityValidator });
  assert.equal(
    f.writes.length,
    2,
    "old writer SHA must receive native409 before rebase",
  );
  assert.notEqual(f.writes[0].sha, f.writes[1].sha);
  const actual = await f.store.load();
  assert.equal(actual.batches[1].remote, "preserved");
  assert.equal(actual.batches[0].local, "pending");
});

test("Claude1 F5 native state store preserves finite ownership code instead of generic rebase error", async () => {
  const f = stateBlobFixture(entityState());
  const ours = await f.store.load();
  ours.batches[0].local = true;
  const remote = entityState();
  remote.operatorTakeover = { active: true };
  f.setRaw(Buffer.from(JSON.stringify(remote)));
  await assert.rejects(
    f.store.save(ours, {
      rebaseIndependentSubjects: (state) => {
        if (state.operatorTakeover)
          throw Object.assign(new Error("observed ownership"), {
            code: "review-operator-owned",
          });
      },
    }),
    (error) => error.code === "review-operator-owned",
  );
  assert.equal(f.writes.length, 1);
  assert.deepEqual(await f.store.load(), remote);
});

test("Claude1 F5 fresh owner hook never forgives unowned same-entity conflicts or malformed canonical data", async () => {
  for (const target of ["a", "b", "malformed"]) {
    const f = stateBlobFixture(entityState());
    const ours = await f.store.load();
    const index = target === "b" ? 1 : 0;
    ours.batches[index].local = "pending";
    const remote = entityState();
    if (target === "malformed") remote.batches = "invalid";
    else remote.batches[index].remote = "canonical concurrent data";
    f.setRaw(Buffer.from(JSON.stringify(remote)));
    let ownershipChecks = 0;
    await assert.rejects(
      f.store.save(ours, {
        checkFreshOwnership: (fresh) => {
          ownershipChecks++;
          entityValidator(fresh);
        },
        rebaseIndependentSubjects: entityValidator,
      }),
      (error) =>
        error.code ===
        (target === "malformed"
          ? "state-rebase-invalid"
          : "state-rebase-conflict"),
    );
    assert.equal(ownershipChecks, 1);
    assert.equal(f.writes.length, 1);
    assert.deepEqual(await f.store.load(), remote);
  }
});

test("Claude1 F5 fresh owner hook is never used after auth failures, definite rejection or uncertain writes", async () => {
  for (const failure of [
    { ok: false, code: 1, stderr: "HTTP 403 Forbidden" },
    { ok: false, code: 1, stderr: "HTTP 502 Bad Gateway" },
    { ok: false, code: 1, stderr: "", error: "timeout" },
  ]) {
    const f = stateBlobFixture(entityState());
    const store = createGitHub({
      cwd: "/tmp",
      repo: "l2v-hub/ClinicOS",
      run: async (call) =>
        call.args.includes("PUT") ? response({}, failure) : f.run(call),
    }).createStateStore();
    const ours = await store.load();
    ours.batches[0].local = true;
    let ownershipChecks = 0;
    await assert.rejects(
      store.save(ours, {
        rebaseIndependentSubjects: entityValidator,
        checkFreshOwnership: () => {
          ownershipChecks++;
          throw Object.assign(new Error("not observed"), {
            code: "review-operator-owned",
          });
        },
      }),
      (error) =>
        ["state-write-failed", "state-write-uncertain"].includes(error.code),
    );
    assert.equal(ownershipChecks, 0);
    assert.deepEqual(await store.load(), entityState());
  }
});

test("Author7 F3 observer reads authenticated Contents without branch creation and caches only unchanged identity", async () => {
  let state = {
      schemaVersion: 1,
      repository: "l2v-hub/ClinicOS",
      batches: [],
      retained: "x".repeat(1024 * 1024 + 1),
    },
    blobs = 0;
  const calls = [];
  const gh = createGitHub({
    repo: "l2v-hub/ClinicOS",
    cwd: "/synthetic",
    run: async (call) => {
      calls.push(call);
      const endpoint = call.args[1];
      assert.ok(
        !endpoint.includes("/git/ref/") && !call.args.includes("POST"),
        "Read-only observation never ensures/creates the branch",
      );
      const contents = stateContents(state);
      if (endpoint.includes("/git/blobs/")) {
        blobs++;
        return response({ ...contents, encoding: "base64" });
      }
      return response({ ...contents, encoding: "none", content: "" });
    },
  });
  const store = gh.createStateStore();
  assert.deepEqual(await store.observe(), state);
  assert.equal(blobs, 1);
  const copy = await store.observe();
  copy.retained = "local-only";
  assert.equal(blobs, 1);
  assert.equal((await store.observe()).retained, state.retained);
  state.note = "fresh owner";
  assert.equal((await store.observe()).note, "fresh owner");
  assert.equal(blobs, 2);
  assert.equal(calls.filter((c) => c.args[1].includes("/contents/")).length, 4);
});

// Semantic repository model: immutable objects, pinned reads, non-forced fast-forward.
function gitDataStateFixture(
  initial = {},
  { absent = false, mode = "100644" } = {},
) {
  const blobs = new Map(),
    trees = new Map(),
    commits = new Map();
  const f = {
    calls: [],
    writes: [],
    objectWrites: [],
    refWrites: [],
    contentsWrites: [],
  };
  const digest = (type, bytes) =>
    createHash("sha1")
      .update(`${type} ${bytes.length}\0`)
      .update(bytes)
      .digest("hex");
  const blob = (bytes) => {
    const sha = digest("blob", bytes);
    blobs.set(sha, Buffer.from(bytes));
    return sha;
  };
  const sorted = (entries) =>
    structuredClone(entries).sort((a, b) =>
      Buffer.compare(
        Buffer.from(a.path + (a.type === "tree" ? "/" : "")),
        Buffer.from(b.path + (b.type === "tree" ? "/" : "")),
      ),
    );
  const tree = (entries) => {
    entries = sorted(entries);
    const bytes = Buffer.concat(
      entries.map((e) =>
        Buffer.concat([
          Buffer.from(`${e.mode.replace(/^0/, "")} ${e.path}\0`),
          Buffer.from(e.sha, "hex"),
        ]),
      ),
    );
    const sha = digest("tree", bytes);
    trees.set(sha, entries);
    return sha;
  };
  let serial = 0;
  const commit = (treeSHA, parents) => {
    const sha = digest(
      "commit",
      Buffer.from(
        `tree ${treeSHA}\n${parents.map((p) => `parent ${p}\n`).join("")}fixture ${++serial}\n`,
      ),
    );
    commits.set(sha, {
      sha,
      tree: { sha: treeSHA },
      parents: parents.map((sha) => ({ sha })),
    });
    return sha;
  };
  const sentinel = blob(Buffer.from("unrelated exact bytes\n"));
  f.sentinels = sorted([
    { path: "README.md", mode: "100644", type: "blob", sha: sentinel },
    { path: "executable", mode: "100755", type: "blob", sha: sentinel },
    { path: "backend", mode: "040000", type: "tree", sha: tree([]) },
    {
      path: "shortcut",
      mode: "120000",
      type: "blob",
      sha: blob(Buffer.from("README.md")),
    },
    { path: "vendor", mode: "160000", type: "commit", sha: "9".repeat(40) },
  ]);
  const entriesAt = (sha) =>
    structuredClone(trees.get(commits.get(sha).tree.sha));
  const stateEntry = (sha = f.head) =>
    entriesAt(sha).find((e) => e.path === ".codex-bug-state.json");
  f.head = commit(
    tree([
      ...f.sentinels,
      ...(absent
        ? []
        : [
            {
              path: ".codex-bug-state.json",
              mode,
              type: "blob",
              sha: blob(Buffer.from(JSON.stringify(initial, null, 2) + "\n")),
            },
          ]),
    ]),
    [],
  );
  f.readBytes = (sha = f.head) => Buffer.from(blobs.get(stateEntry(sha).sha));
  f.readState = () => JSON.parse(f.readBytes());
  f.entries = () => entriesAt(f.head);
  f.advance = (state) => {
    f.head = commit(
      tree([
        ...entriesAt(f.head).filter((e) => e.path !== ".codex-bug-state.json"),
        {
          path: ".codex-bug-state.json",
          mode,
          type: "blob",
          sha: blob(Buffer.from(JSON.stringify(state))),
        },
      ]),
      [f.head],
    );
  };
  Object.defineProperty(f, "metadata", {
    get() {
      return stateContentsBytes(f.readBytes());
    },
  });
  const ancestor = (before, after) =>
    before === after ||
    commits.get(after)?.parents.some((p) => ancestor(before, p.sha));
  f.run = async (call) => {
    const path = call.args[1],
      index = call.args.indexOf("-X"),
      method = index < 0 ? "GET" : call.args[index + 1],
      body = call.input ? JSON.parse(call.input) : undefined;
    const request = { path, method, body, args: call.args, call };
    f.calls.push(request);
    const override = await f.before?.(request);
    if (override) return override;
    let value;
    if (path.includes("/git/ref/heads/"))
      value = {
        ref: "refs/heads/codex/bug-control",
        object: { type: "commit", sha: f.head },
      };
    else if (path.includes("/contents/.codex-bug-state.json")) {
      if (method === "PUT") {
        f.contentsWrites.push(body);
        f.writes.push(body);
        const bytes = Buffer.from(body.content, "base64");
        if (bytes.length > 1024 * 1024)
          return response(
            {},
            {
              ok: false,
              code: 1,
              stderr: "HTTP 400 synthetic large Contents rejection",
            },
          );
        if ((stateEntry()?.sha ?? undefined) !== body.sha)
          return response(
            {},
            { ok: false, code: 1, stderr: "HTTP 409 conflict" },
          );
        f.advance(JSON.parse(bytes));
        value = { content: { sha: stateEntry().sha } };
      } else {
        const ref = new URLSearchParams(path.split("?")[1]).get("ref"),
          at = ref === "codex/bug-control" ? f.head : ref;
        assert.ok(
          commits.has(at),
          "Contents read pins a real branch or commit",
        );
        const entry = stateEntry(at);
        if (!entry)
          return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
        value = stateContentsBytes(blobs.get(entry.sha));
        if (value.size > 1024 * 1024) {
          value.encoding = "none";
          value.content = "";
        }
      }
    } else if (path.endsWith("/git/blobs") && method === "POST") {
      f.objectWrites.push(request);
      assert.equal(body.encoding, "base64");
      const bytes = Buffer.from(body.content, "base64");
      assert.equal(bytes.toString("base64"), body.content);
      value = { sha: blob(bytes) };
    } else if (path.includes("/git/blobs/") && method === "GET") {
      const sha = path.split("/").at(-1),
        bytes = blobs.get(sha);
      assert.ok(bytes);
      assert.equal(call.maxOutputBytes, 16 * 1024 * 1024);
      value = {
        sha,
        size: bytes.length,
        encoding: "base64",
        content: bytes.toString("base64"),
      };
    } else if (path.endsWith("/git/trees") && method === "POST") {
      f.objectWrites.push(request);
      assert.equal(body.tree.length, 1);
      assert.equal(body.tree[0].path, ".codex-bug-state.json");
      assert.ok(blobs.has(body.tree[0].sha));
      const sha = tree([
        ...structuredClone(trees.get(body.base_tree)).filter(
          (e) => e.path !== ".codex-bug-state.json",
        ),
        body.tree[0],
      ]);
      value = { sha, truncated: false, tree: structuredClone(trees.get(sha)) };
    } else if (path.includes("/git/trees/") && method === "GET") {
      const sha = path.split("/").at(-1);
      assert.ok(trees.has(sha));
      value = { sha, truncated: false, tree: structuredClone(trees.get(sha)) };
    } else if (path.endsWith("/git/commits") && method === "POST") {
      f.objectWrites.push(request);
      assert.equal(body.parents.length, 1);
      assert.ok(trees.has(body.tree));
      assert.ok(commits.has(body.parents[0]));
      value = structuredClone(commits.get(commit(body.tree, body.parents)));
    } else if (path.includes("/git/commits/") && method === "GET") {
      value = structuredClone(commits.get(path.split("/").at(-1)));
      assert.ok(value);
    } else if (
      path.endsWith("/git/refs/heads/codex/bug-control") &&
      method === "PATCH"
    ) {
      f.refWrites.push(request);
      f.writes.push(request);
      assert.equal(body.force, false);
      assert.ok(commits.has(body.sha));
      if (!ancestor(f.head, body.sha))
        return response(
          {},
          {
            ok: false,
            code: 1,
            stderr: "HTTP 422 update is not a fast forward",
          },
        );
      f.head = body.sha;
      value = {
        ref: "refs/heads/codex/bug-control",
        object: { type: "commit", sha: f.head },
      };
    } else assert.fail(`Unexpected semantic route ${method} ${path}`);
    await f.after?.(request, value);
    return response(value);
  };
  f.store = createGitHub({
    cwd: "/tmp",
    repo: "l2v-hub/ClinicOS",
    run: f.run,
  }).createStateStore();
  return f;
}

test("Author8 causal: large Contents rejection still permits exact-byte Git Data save and preserves unrelated tree modes", async () => {
  const state = { ...entityState(), payload: "漢".repeat(375000) },
    f = gitDataStateFixture(state);
  const intended = await f.store.load();
  intended.batches[0].local = "durably reserved";
  const bytes = Buffer.from(JSON.stringify(intended)),
    parent = f.head;
  const sha = await f.store.save(intended, {
    rebaseIndependentSubjects: entityValidator,
  });
  assert.deepEqual(f.readBytes(), bytes);
  assert.equal(sha, stateContentsBytes(bytes).sha);
  assert.notEqual(f.head, parent);
  assert.deepEqual(
    f.entries().filter((e) => e.path !== ".codex-bug-state.json"),
    f.sentinels,
  );
  assert.equal(
    f.contentsWrites.length,
    0,
    "Large state selects Git Data before writing",
  );
  assert.equal(f.refWrites.length, 1);
  assert.deepEqual(await f.store.load(), intended);
});

const largeEntityState8 = () => ({
  ...entityState(),
  payload: "x".repeat(1024 * 1024),
});
const stateBytes8 = (size) => ({
  payload: "x".repeat(
    size - Buffer.byteLength(JSON.stringify({ payload: "" })),
  ),
});
const refAttempts8 = (f) => f.calls.filter((c) => c.method === "PATCH");

test("Author8 threshold uses serialized UTF8 bytes, preserves small guards, and creates absent large files without rewriting sentinels", async (t) => {
  for (const [label, state, options, large] of [
    ["exact1MiB", stateBytes8(1024 * 1024), {}, false],
    ["plus1byte", stateBytes8(1024 * 1024 + 1), {}, true],
    ["unicode", { payload: "漢".repeat(350000) }, {}, true],
    ["executable-state", largeEntityState8(), { mode: "100755" }, true],
    ["absent", largeEntityState8(), { absent: true }, true],
  ])
    await t.test(label, async () => {
      const f = gitDataStateFixture({}, options),
        base = await f.store.load();
      assert.equal(base === null, options.absent === true);
      let guards = 0;
      const sha = await f.store.save(state, {
        guard: () => {
          guards++;
        },
      });
      assert.equal(guards, 1);
      assert.equal(f.contentsWrites.length, large ? 0 : 1);
      assert.equal(f.refWrites.length, large ? 1 : 0);
      assert.equal(sha, stateContents(state).sha);
      assert.deepEqual(f.readBytes(), Buffer.from(JSON.stringify(state)));
      assert.deepEqual(
        f.entries().filter((e) => e.path !== ".codex-bug-state.json"),
        f.sentinels,
      );
      assert.equal(
        f.entries().find((e) => e.path === ".codex-bug-state.json").mode,
        options.mode ?? "100644",
      );
    });
});

test("Author8 each await race keeps a frozen body, proves contention, and preserves independent remote progress", async (t) => {
  const stages = [
    "before-parent",
    "after-parent-tree",
    "after-blob",
    "after-tree",
    "after-commit",
    "guard-load",
    "ref422",
  ];
  for (const stage of stages)
    await t.test(stage, async () => {
      const initial = largeEntityState8(),
        f = gitDataStateFixture(initial),
        ours = await f.store.load();
      const heldBatch = ours.batches[0],
        heldAttempt = heldBatch.implementation[0];
      heldAttempt.status = "passed";
      let raced = false,
        validations = 0;
      const remote = () => {
        const state = f.readState();
        state.batches[1].remote = stage;
        state.manualBatches[0].reservation = "preserved";
        f.advance(state);
        raced = true;
      };
      if (stage === "before-parent") remote();
      f.after = async (req) => {
        if (raced) return;
        if (
          (stage === "after-parent-tree" &&
            req.path.includes("/git/trees/") &&
            req.method === "GET") ||
          (stage === "after-blob" && req.path.endsWith("/git/blobs")) ||
          (stage === "after-tree" && req.path.endsWith("/git/trees")) ||
          (stage === "after-commit" && req.path.endsWith("/git/commits"))
        )
          remote();
      };
      f.before = (req) => {
        if (stage === "ref422" && !raced && req.method === "PATCH") remote();
      };
      await f.store.save(ours, {
        rebaseIndependentSubjects: (state) => {
          validations++;
          entityValidator(state);
        },
        guard: async () => {
          if (stage === "guard-load" && !raced) {
            remote();
            await f.store.load();
          }
        },
      });
      assert.equal(raced, true);
      assert.ok(validations >= 2);
      assert.equal(f.readState().batches[0].implementation[0].status, "passed");
      assert.equal(f.readState().batches[1].remote, stage);
      assert.equal(f.readState().manualBatches[0].reservation, "preserved");
      assert.equal(ours.batches[0], heldBatch);
      assert.equal(heldBatch.implementation[0], heldAttempt);
      assert.equal(f.contentsWrites.length, 0);
      assert.equal(f.refWrites.length, stage === "ref422" ? 2 : 1);
      assert.deepEqual(
        f.entries().filter((e) => e.path !== ".codex-bug-state.json"),
        f.sentinels,
      );
    });
});

test("Author8 strict/same-entity/shared-field conflicts never persist stale bytes", async (t) => {
  for (const kind of ["strict", "same-entity", "shared-root"])
    await t.test(kind, async () => {
      const f = gitDataStateFixture(largeEntityState8()),
        ours = await f.store.load();
      ours.batches[0].local = true;
      const remote = f.readState();
      if (kind === "same-entity") remote.batches[0].remote = true;
      else remote.batches[1].remote = true;
      if (kind === "shared-root") {
        ours.shared = "ours";
        remote.shared = "theirs";
      }
      f.advance(remote);
      const head = f.head;
      await assert.rejects(
        f.store.save(
          ours,
          kind === "strict"
            ? {}
            : { rebaseIndependentSubjects: entityValidator },
        ),
        (e) =>
          e.code ===
          (kind === "strict" ? "state-cas-conflict" : "state-rebase-conflict"),
      );
      assert.equal(f.head, head);
      assert.equal(refAttempts8(f).length, 0);
      assert.deepEqual(f.readState(), remote);
    });
});

test("Author8 final ownership and guard are checked after object awaits, with finite ownership failures and no authority grant", async (t) => {
  for (const kind of [
    "owner-hook",
    "guard",
    "false-guard",
    "hook-invalid",
    "missing-hooks-strict-CAS",
  ])
    await t.test(kind, async () => {
      const f = gitDataStateFixture(largeEntityState8()),
        ours = await f.store.load();
      ours.batches[0].local = true;
      const parent = f.head;
      let checked = 0;
      f.after = (req) => {
        if (req.path.endsWith("/git/commits")) checked = 1;
      };
      const ownerError = Object.assign(new Error("Synthetic owner takeover"), {
        code: "review-operator-owned",
      });
      let options = {};
      if (kind === "owner-hook" || kind === "hook-invalid")
        options.checkFreshOwnership = (state) => {
          assert.equal(checked, 1);
          assert.equal(state.batches[0].local, undefined);
          throw kind === "owner-hook"
            ? ownerError
            : new Error("Invalid ownership schema");
        };
      else if (kind === "guard")
        options.guard = () => {
          assert.equal(checked, 1);
          throw ownerError;
        };
      else if (kind === "false-guard") options.guard = () => false;
      else
        f.after = (req) => {
          if (req.path.endsWith("/git/commits")) {
            const remote = f.readState();
            remote.batches[1].remote = true;
            f.advance(remote);
          }
        };
      await assert.rejects(f.store.save(ours, options), (e) =>
        kind === "hook-invalid"
          ? e.code === "state-rebase-invalid"
          : kind === "missing-hooks-strict-CAS"
            ? e.code === "state-cas-conflict"
            : kind === "false-guard"
              ? /rejected/.test(e.message)
              : e === ownerError,
      );
      assert.equal(refAttempts8(f).length, 0);
      assert.equal(f.readState().batches[0].local, undefined);
      if (kind !== "missing-hooks-strict-CAS") assert.equal(f.head, parent);
    });
});

test("Author8 alias mutation and same-store reload cannot promote frozen bytes or the remembered original file CAS", async () => {
  const f = gitDataStateFixture(largeEntityState8()),
    ours = await f.store.load();
  ours.batches[0].verified = true;
  const bytes = Buffer.from(JSON.stringify(ours)),
    initial = f.head;
  await f.store.save(ours, {
    rebaseIndependentSubjects: () => {
      ours.batches[0].unverified = true;
    },
    guard: async () => {
      await f.store.load();
      ours.payload = "unverified replacement";
    },
  });
  assert.deepEqual(f.readBytes(), bytes);
  assert.notEqual(f.head, initial);
  const g = gitDataStateFixture(largeEntityState8()),
    stale = await g.store.load();
  stale.batches[0].local = true;
  await assert.rejects(
    g.store.save(stale, {
      guard: async () => {
        const remote = g.readState();
        remote.batches[1].remote = true;
        g.advance(remote);
        await g.store.load();
      },
    }),
    (e) => e.code === "state-cas-conflict",
  );
  assert.equal(refAttempts8(g).length, 0);
  await assert.rejects(
    g.store.save(stale),
    (e) => e.code === "state-cas-conflict",
  );
  assert.equal(
    refAttempts8(g).length,
    0,
    "Failure restores original expected-file SHA despite guard load",
  );
});

test("Author8 repeated independent conflicts have a shared four-candidate bound and preserve the latest remote state", async () => {
  const f = gitDataStateFixture(largeEntityState8()),
    ours = await f.store.load();
  ours.batches[0].local = true;
  let rounds = 0;
  await assert.rejects(
    f.store.save(ours, {
      rebaseIndependentSubjects: entityValidator,
      guard: () => {
        const state = f.readState();
        state.batches[1].remote = ++rounds;
        f.advance(state);
      },
    }),
    (e) => e.code === "state-cas-conflict",
  );
  assert.equal(rounds, 4);
  assert.equal(
    f.objectWrites.filter((c) => c.path.endsWith("/git/commits")).length,
    4,
  );
  assert.equal(refAttempts8(f).length, 0);
  assert.equal(f.readState().batches[1].remote, 4);
  assert.equal(f.readState().batches[0].local, undefined);
});

test("Author8 rebase transport changes only with new validated bytes across the exact threshold", async (t) => {
  for (const direction of ["small-to-large", "large-to-small"])
    await t.test(direction, async () => {
      const initial =
        direction === "small-to-large" ? entityState() : largeEntityState8();
      const f = gitDataStateFixture(initial),
        ours = await f.store.load();
      ours.batches[0].local = true;
      const remote = f.readState();
      remote.batches[1].remote = true;
      if (direction === "small-to-large")
        remote.payload = "x".repeat(1024 * 1024);
      else delete remote.payload;
      f.advance(remote);
      await f.store.save(ours, { rebaseIndependentSubjects: entityValidator });
      assert.equal(f.readState().batches[0].local, true);
      assert.equal(f.readState().batches[1].remote, true);
      assert.equal(f.refWrites.length, direction === "small-to-large" ? 1 : 0);
      assert.equal(
        f.contentsWrites.length,
        direction === "small-to-large" ? 1 : 1,
      );
    });
});

test("Author8 independent rebase rechecks reserved-result capacity before any second candidate mutation", async () => {
  const initial = largeEntityState8();
  initial.payload = "x".repeat(MAX_DURABLE_STATE_BYTES - 750000);
  const f = gitDataStateFixture(initial),
    ours = await f.store.load();
  ours.batches[0].reviews = [{ status: "running" }];
  const remote = f.readState();
  remote.batches[1].reviews = [{ status: "running" }];
  f.advance(remote);
  const head = f.head;
  await assert.rejects(
    f.store.save(ours, { rebaseIndependentSubjects: entityValidator }),
    (e) => e.code === "state-capacity-exhausted",
  );
  assert.equal(f.head, head);
  assert.equal(f.objectWrites.length, 0);
  assert.equal(refAttempts8(f).length, 0);
});

test("Author8 mutation failures at every object/ref stage are fatal without fallback, hidden retries or postfailure ownership skips", async (t) => {
  const stages = [
    "git/blobs",
    "git/trees",
    "git/commits",
    "git/refs/heads/codex/bug-control",
  ];
  const failures = [
    ["400", { stderr: "HTTP 400" }, "state-write-failed"],
    ["401", { stderr: "HTTP 401" }, "state-write-failed"],
    ["403", { stderr: "HTTP 403" }, "state-write-failed"],
    ["409unchanged", { stderr: "HTTP 409" }, "state-write-failed"],
    ["422unchanged", { stderr: "HTTP 422" }, "state-write-failed"],
    ["502", { stderr: "HTTP 502" }, "state-write-failed"],
    ["timeout", { error: "timeout", stderr: "" }, "state-write-uncertain"],
    [
      "output-limit",
      { error: "output-limit", stderr: "" },
      "state-write-uncertain",
    ],
    [
      "spawn-failed",
      { error: "spawn-failed", stderr: "" },
      "state-write-uncertain",
    ],
    ["unknown", { stderr: "" }, "state-write-uncertain"],
    [
      "badJSON",
      { ok: true, code: 0, stdout: "not JSON", stderr: "" },
      "state-write-uncertain",
    ],
    ["thrown", null, "state-write-uncertain"],
  ];
  for (const [index, stage] of stages.entries())
    for (const [label, failure, code] of failures)
      await t.test(`${stage}:${label}`, async () => {
        const f = gitDataStateFixture(largeEntityState8()),
          ours = await f.store.load(),
          parent = f.head;
        ours.batches[0].local = true;
        let owners = 0,
          validations = 0;
        f.before = (req) => {
          if (req.method !== "GET" && req.path.endsWith("/" + stage)) {
            if (!failure) throw new Error("Synthetic transport exception");
            return { ok: false, code: 1, stdout: "{}", ...failure };
          }
        };
        await assert.rejects(
          f.store.save(ours, {
            rebaseIndependentSubjects: () => {
              validations++;
            },
            checkFreshOwnership: () => {
              owners++;
            },
          }),
          (e) => e.code === code,
        );
        assert.equal(f.head, parent);
        assert.equal(f.contentsWrites.length, 0);
        assert.equal(validations, 1);
        assert.equal(owners, index === 3 ? 1 : 0);
        assert.equal(
          f.calls.filter((req) => req.method !== "GET").length,
          index + 1,
        );
        assert.equal(f.readState().batches[0].local, undefined);
      });
});

test("Author8 ref409/422 require proven fresh change; auth/server errors cannot gain a rebase even when the head changes", async (t) => {
  for (const status of [409, 422, 400, 401, 403, 502])
    await t.test(String(status), async () => {
      const f = gitDataStateFixture(largeEntityState8()),
        ours = await f.store.load();
      ours.batches[0].local = true;
      let failed = false;
      f.before = (req) => {
        if (req.method === "PATCH" && !failed) {
          failed = true;
          const remote = f.readState();
          remote.batches[1].remote = status;
          f.advance(remote);
          return response({}, { ok: false, code: 1, stderr: `HTTP ${status}` });
        }
      };
      if ([409, 422].includes(status)) {
        await f.store.save(ours, {
          rebaseIndependentSubjects: entityValidator,
        });
        assert.equal(f.readState().batches[0].local, true);
        assert.equal(refAttempts8(f).length, 2);
      } else {
        await assert.rejects(
          f.store.save(ours, { rebaseIndependentSubjects: entityValidator }),
          (e) => e.code === "state-write-failed",
        );
        assert.equal(f.readState().batches[0].local, undefined);
        assert.equal(refAttempts8(f).length, 1);
      }
      assert.equal(f.readState().batches[1].remote, status);
    });
});

test("Author8 an unknown ref outcome after an actual effect remains fatal and never triggers a second write or owner skip", async (t) => {
  for (const kind of [
    "timeout-after-effect",
    "malformed-ref",
    "missing-ref-sha",
    "changed-ref-type",
  ])
    await t.test(kind, async () => {
      const f = gitDataStateFixture(largeEntityState8()),
        ours = await f.store.load(),
        old = f.head;
      ours.batches[0].local = true;
      const store = createGitHub({
        cwd: "/tmp",
        repo: "l2v-hub/ClinicOS",
        run: async (call) => {
          const result = await f.run(call);
          if (!call.args.includes("PATCH")) return result;
          if (kind === "timeout-after-effect")
            return {
              ok: false,
              code: 1,
              error: "timeout",
              stderr: "",
              stdout: "",
            };
          const value = JSON.parse(result.stdout);
          if (kind === "malformed-ref") value.ref = "refs/heads/main";
          if (kind === "missing-ref-sha") delete value.object.sha;
          if (kind === "changed-ref-type") value.object.type = "tag";
          return response(value);
        },
      }).createStateStore();
      await store.load();
      let owners = 0;
      await assert.rejects(
        store.save(ours, {
          checkFreshOwnership: () => {
            owners++;
          },
          rebaseIndependentSubjects: entityValidator,
        }),
        (e) => e.code === "state-write-uncertain",
      );
      assert.notEqual(f.head, old);
      assert.equal(f.readState().batches[0].local, true);
      assert.equal(refAttempts8(f).length, 1);
      assert.equal(owners, 1);
      assert.equal(f.contentsWrites.length, 0);
    });
});

test("Author8 malformed parent/blob/tree/commit metadata and target types cannot authorize a ref effect", async (t) => {
  const variants = [
    "ref-name",
    "ref-type",
    "ref-sha",
    "parent-sha",
    "parent-tree",
    "parent-parents",
    "tree-truncated",
    "tree-duplicate",
    "tree-path",
    "tree-mode",
    "tree-sha",
    "contents-sha",
    "contents-size",
    "contents-encoding",
    "blob-sha",
    "new-tree-extra",
    "new-tree-sha",
    "new-commit-parent",
    "new-commit-tree",
    "new-commit-sha",
  ];
  for (const kind of variants)
    await t.test(kind, async () => {
      const f = gitDataStateFixture(largeEntityState8()),
        ours = await f.store.load(),
        head = f.head;
      ours.batches[0].local = true;
      let changed = false,
        references = 0;
      f.after = (req, value) => {
        if (changed) return;
        const ref = req.path.includes("/git/ref/") && ++references === 2,
          parent = req.path.includes("/git/commits/") && req.method === "GET";
        const oldTree =
            req.path.includes("/git/trees/") && req.method === "GET",
          contents = req.path.includes("/contents/");
        if (kind.startsWith("ref-") && ref) {
          value[kind === "ref-name" ? "ref" : "object"] =
            kind === "ref-name"
              ? "refs/heads/main"
              : {
                  ...value.object,
                  [kind === "ref-type" ? "type" : "sha"]:
                    kind === "ref-type" ? "tag" : "invalid",
                };
          changed = true;
        } else if (kind.startsWith("parent-") && parent) {
          value[kind.slice(7)] =
            kind === "parent-sha"
              ? "a".repeat(40)
              : kind === "parent-tree"
                ? { sha: "invalid" }
                : [{ sha: "invalid" }];
          changed = true;
        } else if (kind.startsWith("tree-") && oldTree) {
          if (kind === "tree-truncated") value.truncated = true;
          else if (kind === "tree-duplicate") value.tree.push(value.tree[0]);
          else if (kind === "tree-path") value.tree[0].path = "nested/entry";
          else if (kind === "tree-mode") value.tree[0].mode = "999999";
          else value.sha = "f".repeat(40);
          changed = true;
        } else if (kind.startsWith("contents-") && contents) {
          value[kind.slice(9)] =
            kind === "contents-sha"
              ? "a".repeat(40)
              : kind === "contents-size"
                ? MAX_DURABLE_STATE_BYTES + 1
                : "utf8";
          changed = true;
        } else if (kind === "blob-sha" && req.path.endsWith("/git/blobs")) {
          value.sha = "f".repeat(40);
          changed = true;
        } else if (
          kind.startsWith("new-tree-") &&
          req.path.endsWith("/git/trees")
        ) {
          if (kind === "new-tree-extra") value.tree[0].sha = "f".repeat(40);
          else value.sha = "invalid";
          changed = true;
        } else if (
          kind.startsWith("new-commit-") &&
          req.path.endsWith("/git/commits")
        ) {
          if (kind === "new-commit-parent")
            value.parents = [{ sha: "f".repeat(40) }];
          else if (kind === "new-commit-tree") value.tree.sha = "f".repeat(40);
          else value.sha = "invalid";
          changed = true;
        }
      };
      await assert.rejects(
        f.store.save(ours, { rebaseIndependentSubjects: entityValidator }),
      );
      assert.equal(changed, true);
      assert.equal(f.head, head);
      assert.equal(refAttempts8(f).length, 0);
    });
  for (const mode of ["120000", "160000", "040000"])
    await t.test(`target-mode:${mode}`, async () => {
      const f = gitDataStateFixture(largeEntityState8(), { mode }),
        ours = await f.store.load(),
        head = f.head;
      await assert.rejects(f.store.save(ours));
      assert.equal(f.head, head);
      assert.equal(f.objectWrites.length, 0);
    });
});

test("Author8 large creation proves tree absence and positive HTTP404, while read/auth failures authorize no mutation", async (t) => {
  for (const kind of [
    "auth403",
    "text404-with403",
    "unknown-read",
    "target-missing-contents",
    "absence-mismatch",
  ])
    await t.test(kind, async () => {
      const absent = kind !== "target-missing-contents",
        f = gitDataStateFixture({}, { absent });
      await f.store.load();
      const head = f.head;
      f.before = (req) => {
        if (!req.path.includes("/contents/") || req.path.includes("ref=codex"))
          return;
        if (kind === "auth403")
          return response({}, { ok: false, code: 1, stderr: "HTTP 403" });
        if (kind === "text404-with403")
          return response(
            {},
            { ok: false, code: 1, stderr: "HTTP 403 denied path 404" },
          );
        if (kind === "unknown-read")
          return response({}, { ok: false, code: 1, stderr: "" });
        if (kind === "target-missing-contents")
          return response({}, { ok: false, code: 1, stderr: "HTTP 404" });
        return response(stateContents({ spoof: true }));
      };
      await assert.rejects(f.store.save(largeEntityState8()));
      assert.equal(f.head, head);
      assert.equal(f.objectWrites.length, 0);
      assert.equal(refAttempts8(f).length, 0);
    });
});
