from pathlib import Path
import json,hashlib
p=Path('/tmp/clinicos-autonomy-activation-20261022');a=p/'author8';scope=json.loads((a/'root-test-fixture-scope-acceptance.json').read_bytes());assert scope['reservedBeforeAdditionalEdits']
t=p/'source8/agent-team/tests/bug-pipeline';g=t/'github.test.mjs';s=g.read_text();start=s.index('function gitDataStateFixture(');end=s.index("test('Author8 causal:");fixture=s[start:end];header="import assert from 'node:assert/strict';\nimport { createHash } from 'node:crypto';\nimport { createGitHub } from '../../src/bug-pipeline/github.mjs';\nfunction response(value, options = {}) { return { ok: true, code: 0, stdout: JSON.stringify(value), stderr: '', ...options }; }\nfunction stateContentsBytes(bytes) { return { type: 'file', sha: createHash('sha1').update(`blob ${bytes.length}\\0`).update(bytes).digest('hex'), size: bytes.length, encoding: 'base64', content: bytes.toString('base64') }; }\n// Immutable semantic repository server shared by transport and actual-role tests.\n"
(t/'git-data-state-fixture.mjs').write_text(header+fixture.replace('function gitDataStateFixture(', 'export function gitDataStateFixture(',1))
g.write_text("import { gitDataStateFixture } from './git-data-state-fixture.mjs';\n"+s[:start]+s[end:])
f=t/'comment-review-handoff.test.mjs';s=f.read_text();s="import { gitDataStateFixture } from './git-data-state-fixture.mjs';\n"+s
anchor='  const apiRun = async (call) => {'
code='''  const stateTransport = blobState ? gitDataStateFixture(remote) : null;
  if (stateTransport) stateTransport.after = (request, value) => {
    if (request.method === 'GET' && request.path.includes('/git/blobs/'))
      value.content = value.content.match(/.{1,60}/g).join('\\n');
  };
'''
assert anchor in s;s=s.replace(anchor,code+anchor)
anchor="    if (endpoint === `repos/${repo}/git/ref/heads/codex/bug-control`)"
code='''    // Source packet recursive-tree/native API stubs remain independent of state Git objects.
    if (stateTransport && (
      endpoint.startsWith(`repos/${repo}/contents/.codex-bug-state.json`) ||
      endpoint === `repos/${repo}/git/ref/heads/codex/bug-control` ||
      endpoint === `repos/${repo}/git/refs/heads/codex/bug-control` ||
      endpoint.startsWith(`repos/${repo}/git/blobs/`) ||
      endpoint.startsWith(`repos/${repo}/git/commits/`) ||
      ['blobs', 'trees', 'commits'].some((kind) => endpoint === `repos/${repo}/git/${kind}`) ||
      (endpoint.startsWith(`repos/${repo}/git/trees/`) && !endpoint.includes('?'))
    )) {
      // Test-side external edits create a new immutable commit, never alter pinned history.
      if (JSON.stringify(stateTransport.readState()) !== JSON.stringify(remote)) stateTransport.advance(remote);
      const result = await stateTransport.run(call);
      if (result.ok && ['PUT', 'PATCH'].includes(method)) {
        writes.push({ endpoint, method, body: JSON.parse(call.input) });
        const next = stateTransport.readState();
        for (const key of Object.keys(remote)) delete remote[key];
        Object.assign(remote, next);
      }
      return result;
    }
'''
assert anchor in s;s=s.replace(anchor,code+anchor);f.write_text(s)
f=t/'standalone-review.test.mjs';s=f.read_text();s="import { gitDataStateFixture } from './git-data-state-fixture.mjs';\n"+s
start=s.index('function realSharedStateStore(initial) {');end=s.index('function actualController(',start)
s=s[:start]+'''function realSharedStateStore(initial) {
  const fixture = gitDataStateFixture(initial);
  const stats = { writes: 0, conflicts: 0, puts: [] };
  const transport = createGitHub({
    cwd: '/tmp', repo,
    run: async (call) => {
      const method = call.args.includes('-X') ? call.args[call.args.indexOf('-X') + 1] : 'GET';
      if (method === 'PUT') stats.puts.push(JSON.parse(call.input));
      const result = await fixture.run(call);
      if (['PUT', 'PATCH'].includes(method)) {
        if (result.ok) stats.writes++;
        else if (/HTTP (409|422)\\b/.test(result.stderr)) stats.conflicts++;
      }
      return result;
    },
  });
  return { createStateStore: transport.createStateStore, stats,
    state: fixture.readState, bytes: () => fixture.readBytes().length };
}
''' +s[end:];f.write_text(s)
(a/'fixture-extraction-receipt.json').write_text(json.dumps({'acceptanceStateCommit':scope['stateCommit'],'helperOrigin':'Current github.test.mjs semantic fixture extracted verbatim; pure imports/utilities added; all tests remain in original test modules.','functionalAssertionsChanged':False,'originalPayloadSizesChanged':False,'sourceProductionChanges':False},indent=2)+'\n')
