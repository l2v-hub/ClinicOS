import pathlib,json,hashlib,subprocess,os
out=pathlib.Path(__file__).parent;root=out.parent;src=root/'qa-source8'
digest=lambda b:hashlib.sha256(b).hexdigest()
binding=lambda p:{'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size}
manifest=json.loads((root/'source8-frozen-snapshot-manifest.json').read_text())
actual={name:binding(src/name) for name in manifest}
assert actual==manifest
(out/'source-before.json').write_text(json.dumps(actual,indent=2)+'\n')
repo='/workspace/ClinicOS';sha='0f3833480fda5a056e91fa9922552d4f91bca346';parent='57d25ed04f1e4faddc232ef77d190d3bc339a643';base='2ee298957c3e1733b01a4b4aca4b48b890032f69'
def git(*args):return subprocess.check_output(['git','-C',repo,*args],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'})
rawmismatch=[]
for name,b in actual.items():
 raw=git('show',sha+':'+name)
 if digest(raw)!=b['sha256']:
  assert name=='scripts/automation/setup-claude-review-windows.ps1' and (src/name).read_bytes().replace(b'\r\n',b'\n')==raw
  rawmismatch.append({'path':name,'onlyKnownUnchangedCRLF':True,'git':{'bytes':len(raw),'sha256':digest(raw)}})
delta=git('diff','--name-only',parent,sha).decode().splitlines()
allowed=json.loads((root/'author8/effective-allowlist.json').read_text())
assert set(delta)==set(allowed) and len(delta)==7
changed=[p for p in git('diff','--name-only',base,sha).decode().splitlines() if not p.startswith('artifacts/')]
assert len(changed)==27
def tree(commit):
 return {line.split(b'\t',1)[1].decode():line.split(b'\t',1)[0].split()[2].decode() for line in git('ls-tree','-r',commit).splitlines()}
old=tree(parent);new=tree(sha)
packets={p:h for p,h in old.items() if p.startswith('artifacts/task-validation/workflow-autonomy-activation-20261022')}
assert len(packets)==560 and all(new.get(p)==h for p,h in packets.items())
seals=[]
for directory in ['author8','Luna-state-transport-docs8','author7','independent-qa7']:
 p=root/directory/'seal.json';seal=json.loads(p.read_text());files=seal['files']
 for name,expected in files.items():assert binding(p.parent/name)==expected,(directory,name)
 seals.append({'directory':directory,'seal':binding(p),'verifiedFiles':len(files)})
support=json.loads((root/'source7-readonly-test-support-receipt.json').read_text())
assert binding(pathlib.Path(support['privateCopy']))=={'bytes':support['bytes'],'sha256':support['sha256']}
links={str(p.relative_to(src)):os.readlink(p) for p in src.rglob('*') if p.is_symlink()}
record={'sourceSha':sha,'sourceFiles':len(actual),'frozenManifest':binding(root/'source8-frozen-snapshot-manifest.json'),'rawGitMismatches':rawmismatch,'changedDelta':delta,'cumulativeChangedCode':len(changed),'changedCodeRawExact':all(p not in [e['path'] for e in rawmismatch] for p in changed),'oldPacketBlobs':len(packets),'allOldPacketBlobsUnchanged':True,'seals':seals,'links':links,'supportExact':True,'gitOperations':'show/diff/ls-tree read only'}
(out/'integrity-before.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k not in ['links','changedDelta']},indent=2))
