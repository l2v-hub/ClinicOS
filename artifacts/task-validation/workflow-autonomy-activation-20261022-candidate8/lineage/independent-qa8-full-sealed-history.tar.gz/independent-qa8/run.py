import subprocess,os,json,pathlib,sys,time,hashlib,re
out=pathlib.Path(__file__).parent
src=out.parent/'qa-source8'
label=sys.argv[1];cmd=sys.argv[2:]
assert not (out/(label+'.json')).exists()
(out/'tmp').mkdir(exist_ok=True)
env={'PATH':'/usr/bin:/bin','TMPDIR':str(out/'tmp'),'LANG':'C.UTF-8','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_COUNT':'2','GIT_CONFIG_KEY_0':'core.hooksPath','GIT_CONFIG_VALUE_0':'/dev/null','GIT_CONFIG_KEY_1':'protocol.allow','GIT_CONFIG_VALUE_1':'never'}
start=time.time()
r=subprocess.run(cmd,cwd=src,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
(out/(label+'.log')).write_bytes(r.stdout)
summary={k:int(v) for k,v in re.findall(rb'^# (tests|pass|fail|cancelled|skipped|todo) (\d+)$',r.stdout,re.M)}
summary={k.decode() if isinstance(k,bytes) else k:v for k,v in summary.items()}
record={'command':cmd,'cwd':str(src),'environment':env,'exitCode':r.returncode,'seconds':time.time()-start,'logSha256':hashlib.sha256(r.stdout).hexdigest(),'summary':summary}
(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print(r.stdout.decode()[-1800:])
