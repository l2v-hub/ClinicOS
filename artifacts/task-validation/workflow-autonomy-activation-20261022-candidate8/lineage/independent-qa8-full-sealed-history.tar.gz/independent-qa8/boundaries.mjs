import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createGitHub,MAX_DURABLE_STATE_BYTES} from '../qa-source8/agent-team/src/bug-pipeline/github.mjs';
import {gitDataStateFixture} from '../qa-source8/agent-team/tests/bug-pipeline/git-data-state-fixture.mjs';
const initial=()=>({batches:[{id:'A',value:0},{id:'B',value:0}],payload:'z'.repeat(1048576)});
const valid=s=>{assert.equal(s.batches.length,2);assert.equal(new Set(s.batches.map(x=>x.id)).size,2);};
const digest=b=>createHash('sha1').update(`blob ${b.length}\0`).update(b).digest('hex');
const reply=x=>({ok:true,code:0,stdout:JSON.stringify(x),stderr:''});

test('QA8 exact serialization accounts for escaped characters, combining Unicode and lone surrogates',async()=>{
 const f=gitDataStateFixture({}),state={payload:'\u0000\n"\\'.repeat(100000),unicode:'é漢e\u0301\ud800'};
 await f.store.load();const bytes=Buffer.from(JSON.stringify(state));assert(bytes.length>1048576);
 assert.equal(await f.store.save(state),digest(bytes));assert.deepEqual(f.readBytes(),bytes);
 assert.equal(f.contentsWrites.length,0);assert.equal(f.refWrites.length,1);
});

test('QA8 caller validator mutating its clone cannot change pending bytes or grant later stale CAS',async()=>{
 const f=gitDataStateFixture(initial()),state=await f.store.load();state.batches[0].value=1;
 let validators=0;
 await f.store.save(state,{rebaseIndependentSubjects:async clone=>{validators++;clone.batches[0].value=999;clone.payload='small';await Promise.resolve();}});
 assert.equal(validators,1);assert.equal(f.readState().batches[0].value,1);assert.equal(f.contentsWrites.length,0);
});

test('QA8 pinned Contents await may see a forward ref, but full independent retry preserves both original intents',async()=>{
 const f=gitDataStateFixture(initial()),state=await f.store.load();state.batches[0].value=1;let moved=false;
 f.after=req=>{if(!moved&&req.method==='GET'&&req.path.includes('/contents/')&&!req.path.includes('ref=codex')){moved=true;const remote=f.readState();remote.batches[1].value=2;f.advance(remote);}};
 await f.store.save(state,{rebaseIndependentSubjects:valid});
 assert(moved);assert.deepEqual(f.readState().batches,[{id:'A',value:1},{id:'B',value:2}]);assert.equal(f.refWrites.length,1);
});

test('QA8 fresh ownership receives authenticated immutable parent, never proposed edits or callback aliases',async()=>{
 const f=gitDataStateFixture(initial()),state=await f.store.load();state.batches[0].value=1;
 await f.store.save(state,{checkFreshOwnership:async parent=>{assert.equal(parent.batches[0].value,0);parent.batches[0].value=99;await Promise.resolve();}});
 assert.equal(f.readState().batches[0].value,1);
});

test('QA8 absent large creation ownership hook observes null and a rejected caller guard emits zero refs',async()=>{
 const f=gitDataStateFixture({},{absent:true});assert.equal(await f.store.load(),null);let checked=0;
 await assert.rejects(f.store.save(initial(),{checkFreshOwnership:s=>{assert.equal(s,null);checked++;},guard:()=>false}),/guard rejected/);
 assert.equal(checked,1);assert.equal(f.refWrites.length,0);assert.equal(f.objectWrites.length,3);
});

test('QA8 server cannot omit a valid unrelated directory even with a newly consistent tree hash',async()=>{
 const f=gitDataStateFixture(initial()),state=await f.store.load(),head=f.head;
 f.after=(req,value)=>{if(req.method==='POST'&&req.path.endsWith('/git/trees')){
  value.tree=value.tree.filter(e=>e.type!=='tree');const raw=Buffer.concat(value.tree.map(e=>Buffer.concat([Buffer.from(`${e.mode.replace(/^0/,'')} ${e.path}\0`),Buffer.from(e.sha,'hex')])));
  value.sha=createHash('sha1').update(`tree ${raw.length}\0`).update(raw).digest('hex');
 }};
 await assert.rejects(f.store.save(state),/changed unrelated entries/);assert.equal(f.head,head);assert.equal(f.refWrites.length,0);
});

test('QA8 final ref proof transport timeout after guard never sends a PATCH or another candidate',async()=>{
 const f=gitDataStateFixture(initial()),state=await f.store.load();let guarded=false,validated=0;
 f.before=req=>{if(guarded&&req.path.includes('/git/ref/'))return{ok:false,code:1,error:'timeout',stderr:'',stdout:''};};
 await assert.rejects(f.store.save(state,{guard:()=>{guarded=true;},rebaseIndependentSubjects:()=>{validated++;}}),e=>e.code==='github-read-transient');
 assert.equal(f.refWrites.length,0);assert.equal(validated,1);assert.equal(f.objectWrites.length,3);
});

test('QA8 output-limit after a real ref effect never authorizes another mutation despite observed takeover',async()=>{
 const f=gitDataStateFixture(initial());let first=true,owners=0;
 const store=createGitHub({repo:'l2v-hub/ClinicOS',run:async call=>{const r=await f.run(call);if(first&&call.args.includes('PATCH')){first=false;const remote=f.readState();remote.batches[0].operatorCoordination={active:true,owner:'offline'};f.advance(remote);return{ok:false,code:1,error:'output-limit',stderr:'',stdout:''};}return r;}}).createStateStore();
 const state=await store.load();state.batches[0].value=1;
 await assert.rejects(store.save(state,{rebaseIndependentSubjects:valid,checkFreshOwnership:()=>{owners++;}}),e=>e.code==='state-write-uncertain');
 assert.equal(owners,1);assert.equal(f.refWrites.length,1);assert.equal(f.readState().batches[0].value,1);assert(f.readState().batches[0].operatorCoordination.active);
});

test('QA8 capacity includes the exact candidate and pending reserves after threshold transition',async()=>{
 const f=gitDataStateFixture({}),state={batches:[{id:'A',reviews:[{status:'running'},{status:'running'}]}],payload:'x'.repeat(MAX_DURABLE_STATE_BYTES-1048576)};
 await f.store.load();await assert.rejects(f.store.save(state),e=>e.code==='state-capacity-exhausted');assert.equal(f.objectWrites.length,0);assert.equal(f.contentsWrites.length,0);
});

test('QA8 definite 422 with a malformed fresh-ref proof keeps rejection and blocks validator replay',async()=>{
 const f=gitDataStateFixture(initial()),state=await f.store.load();let rejected=false,validated=0;
 f.before=req=>{if(req.method==='PATCH'){rejected=true;return{ok:false,code:1,stderr:'HTTP 422',stdout:''};}if(rejected&&req.path.includes('/git/ref/'))return reply({ref:'refs/heads/main',object:{type:'commit',sha:f.head}});};
 await assert.rejects(f.store.save(state,{rebaseIndependentSubjects:()=>{validated++;}}),e=>e.code==='state-write-failed'&&e.cause.httpStatus===422&&e.proofError?.message.includes('reference metadata'));
 assert.equal(validated,1);assert.equal(f.refWrites.length,0);assert.equal(f.calls.filter(c=>c.method==='PATCH').length,1);
});
