import pathlib,json,hashlib,datetime,os
q=pathlib.Path(__file__).parent;r=q.parent;src=r/'qa-source8'
digest=lambda b:hashlib.sha256(b).hexdigest()
binding=lambda p:{'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size}
read=lambda p:json.loads(p.read_text())
write=lambda name,value:(q/name).write_text(json.dumps(value,indent=2)+'\n')
before=read(q/'source-before.json');after={n:binding(src/n) for n in before};assert before==after
write('source-after.json',after)
prior=read(r/'source7-frozen-snapshot-manifest.json')
for directory in ['source7','qa-source7']:
 assert all(binding(r/directory/n)==v for n,v in prior.items())
seals=[]
for directory in ['author','author2','author3','author4','author5','author6','author7','author8','independent-qa','independent-qa3','independent-qa4','independent-qa5','independent-qa6','independent-qa7','Luna-state-transport-docs8']:
 p=r/directory/'seal.json';seal=read(p)
 for name,expected in seal['files'].items():assert binding(p.parent/name)==expected,(directory,name)
 seals.append({'directory':directory,'seal':binding(p),'verifiedFiles':len(seal['files'])})
initial=read(q/'integrity-before.json')
assert initial['links']=={str(p.relative_to(src)):os.readlink(p) for p in src.rglob('*') if p.is_symlink()}
docs=read(r/'root-docs8-integration/actual-delivery-receipt.json')['delivery']
assert all(binding(src/n)==v for n,v in docs['integratedAfter'].items())
verification=read(q/'verification-results.json');assert verification['syntax']['checked']==17
commands={label:read(q/(label+'.json')) for label in ['integrated','boundaries','callers','callers-corrected','canonical','verification','verification-corrected','verification-final']}
assert all(commands[n]['exitCode']==0 for n in ['integrated','boundaries','callers-corrected','canonical','verification-final'])
assert sum(commands[n]['summary']['tests'] for n in ['integrated','boundaries','callers-corrected'])==944
receipts=[]
for p in [r/'author8/failure-history.json',r/'author8/command-history.md',r/'author8/source.patch',r/'author8/root-plan-acceptance.json',r/'author8/root-test-fixture-scope-acceptance.json',r/'author8/format-fixture-integration.json',r/'author8/format-late-tests.json',r/'root-docs8-integration/actual-delivery-receipt.json',r/'native-git-data-noop-probe8/actual-protocol-proof.json',r/'root-source7-existing-checkout-normalization-proof.json']:
 receipts.append({'path':str(p),'binding':binding(p)})
write('read-receipts.json',{'method':'Actual code/caller/delta inspection, initial failure logs plus AST preservation checks, offline input hashing; reading data grants no authority.','inputs':receipts,'fixtureReuse':[{'own':n,'origin':str(r/'author8'/n),'changes':'Only source8 import URL changed to frozen qa-source8; no tests imported/registered by these helper files.'} for n in ['pipeline-fixture.mjs','large-pipeline-loader.mjs']],'seals':seals,'source7AndQaSource7FilesExact':len(prior),'docsIntegratedBindingsExact':True})
failures=[{'label':'callers','class':'private assertion expectation','tests':2,'pass':1,'fail':1,'reason':'Expected top-level state-write-uncertain, but actual caller intentionally wraps the cause. Original test/log retained. Corrected uses production controllerFailureCode and unchanged no-inference/no-ref/exact-state assertions.','corrected':'callers-corrected'}, {'label':'verification','class':'private AST comparator formatting artifact','reason':'TS printer retains multiline/trailing-comma formatting in the causal save options. Original script/log retained; semantic AST structure and literal tokens compare instead.'},{'label':'verification-corrected','class':'private AST comparator source text inclusion','reason':'SourceFile.text carries full formatting; excluded that one nonsemantic property. Original second script/log retained; final structural AST comparison includes node kinds, identifier/literal text and all children.'}]
write('failure-history.json',{'ownFailures':failures,'authorHistoryReviewed':verification['authorFailureHistory'],'productionChanges':0,'repeatedTestsCountedAgain':False})
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
result={'status':'verified','sourceSha':'0f3833480fda5a056e91fa9922552d4f91bca346','nonce':'06bcaa0f-316b-4372-871a-118be6c53e11','findings':[],'verifiedAt':now,'sourceFrozen':True,'sourceFiles':139,'deltaPaths':initial['changedDelta'],'cumulativeCodePaths':27,'oldPublicPacketBlobsUnchanged':560,'sourceBeforeAfterExact':True,'gitBindings':initial,'sealsRechecked':seals,'tests':{'distinctFunctional':944,'integrated15Suites':932,'independentTransportBoundaries':10,'actualPipelineBoundaries':2,'syntax':17,'separatelyClassifiedOfflineCanonicalValidationCommands':1,'skipped':0,'failedFinal':0,'duplicateRunsExcluded':True},'commands':commands,'ownInitialFailures':failures,'canonical':read(q/'canonical-results.json'),'assertionPreservation':verification['preserved'],'causalOriginalAssertionsSemanticallyExact':True,'limitations':['Offline synthetic protocol tests and recorded canonical validation only. No actual GitHub module write performed by QA8.','Ref force:false protects ordinary forward writers; no atomic guarantee against external forced rewind/ABA after the final ref read.','New Git objects alone are not durable reservations. Unknown outcomes require reconciliation; no fallback or model retry tested as success.','Actual source8 live module probe, publication, six new native CI checks, genuine Claude review, final Codex gate, protected merge and event activation remain root-owned future gates.','No clinical completion claim; original23 clinical issues/Railway remain separately deferred.'],'scope':{'sourceEdits':False,'network':False,'models':False,'subagents':False,'canonicalWrites':False,'realRepositoryGitWrites':False,'temporarySyntheticGitFixtures':'Inherited applicable tests only; private TMPDIR and Git configuration.'}}
write('results.json',result)
report='''# Independent QA8

Verified with zero actionable findings on frozen source `0f3833480fda5a056e91fa9922552d4f91bca346`. I authored none of the candidate and made no source changes.

The 15 affected suites passed 932/932; ten independently selected transport probes and two actual-pipeline boundary probes passed. That is 944 distinct functional tests, zero skips, plus 17 syntax checks. Repeated corrected runs are excluded. Actual canonical before/proposed states passed all three frozen source8 validators offline, preserving all old22 subjects and native implementation7/review1; no external claim or globalAutomation own property appeared. Only digests/counts are exported.

Review covered the changed GitHub store, shared semantic fixture, three test deltas and both documentation deltas, together with pipeline, handoff, standalone and release guards. The writer freezes bytes and expected file identity before awaits, proves a fixed parent/root tree/state object, retains unrelated entries and their modes, confirms blob/tree/one-parent commit metadata, then rechecks ownership, caller guard and parent immediately before nonforced ref publication. Ordinary forward races require proven contention, full opt-in validation and at most four total candidates. Unknown object/ref results stop; orphan objects are not reservations. Small Contents semantics and raw8MiB plus pending reservations remain covered.

Selected new cases independently exercised escaped characters/Unicode/lone surrogates, validator clone mutation, ref advance during pinned Contents read, parent-state ownership clone isolation, absent creation with rejected final guard, hash-consistent omitted unrelated directory, timeout during final ref proof, output-limit after actual synthetic ref effect, exact pending capacity, and malformed fresh proof after422. The actual pipeline takeover case preserved owned A exactly and progressed only eligible B; unknown upload stopped before any inference or later-subject reservation. The VM loader executes frozen pipeline/external-review code and replaces issue communication/process plumbing with inert test adapters. Batch/loader helpers originate in sealed author fixtures with only source URLs rebound; assertions and selected races are independently authored.

All139 frozen source bindings remain exact before/after. Readonly Git shows seven effective delta paths and27 cumulative changed code paths, all raw-exact. The sole Git/frozen mismatch is the known unchanged PowerShell CRLF baseline. All560 old packet blob IDs are unchanged. Source7/QA-source7 retain138 exact files; every listed historical author/QA seal and Luna8 seal reverified. Integrated documentation hashes match root's receipt; the sealed Luna workflow document intentionally predates one recorded root sentence clarification.

The author's initial old-Contents causal failure and later success are authenticated by raw log hashes; the causal test retains the same semantic AST/assertions. All92 original role test calls/assertions remain identical. Reviewed history distinguishes three original large-save fixture failures, the genuine strict404 defect and correction, inherited ensureBranch metadata injection correction, two role fixture failures requiring the prior scope acceptance, and repository-format correction. None is relabeled as a passing original run.

My first caller probe expected a top-level error code; the caller intentionally wraps it in cause. The corrected assertion uses the production failure-code chain and preserves all behavioral assertions. Two initial private provenance-comparator failures concerned TS printer formatting and SourceFile.text, resolved by structural AST comparison. Original scripts, logs and statuses remain in this packet. No production fix occurred.

This is offline independent code QA. The earlier root no-op protocol proves endpoint permissions, not execution of this new module. Root still owns the actual source8 module probe, publication, six new native CI checks, genuine Claude/final Codex gates, protected merge and finite event activation. No clinical completion is claimed. GitHub nonforced updates protect ordinary forward writers; external force-rewind/ABA after the final read remains outside that guarantee.
'''
(q/'report.md').write_text(report)
write('STOP.json',{'status':'verified','stoppedAt':now,'sourceSha':result['sourceSha'],'nonce':result['nonce'],'findings':[],'sourceFrozen':True,'filesFrozenAfterSeal':True,'liveOperationsPerformed':False,'rootFutureGatesRetained':True})
files={str(p.relative_to(q)):binding(p) for p in sorted(q.rglob('*')) if p.is_file() and p.name!='seal.json'}
write('seal.json',{'schemaVersion':1,'status':'verified','sealedAt':now,'sourceSha':result['sourceSha'],'nonce':result['nonce'],'files':files})
print(json.dumps({'status':'verified','findings':0,'distinctFunctional':944,'syntax':17,'privateFilesSealed':len(files),'seal':binding(q/'seal.json')}))
