import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import ts from '/workspace/ClinicOS/node_modules/typescript/lib/typescript.js';
const out=path.dirname(new URL(import.meta.url).pathname),root=path.dirname(out),src=path.join(root,'qa-source8');
const read=p=>fs.readFileSync(p,'utf8'),hash=x=>createHash('sha256').update(x).digest('hex');
const printer=ts.createPrinter({removeComments:true});
function tests(source){const file=ts.createSourceFile('test.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),out=[];function visit(n){if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='test')out.push({name:n.arguments[0]?.text,body:printer.printNode(ts.EmitHint.Expression,n,file)});ts.forEachChild(n,visit);}visit(file);return out;}
const preserved=[];
for(const name of ['comment-review-handoff.test.mjs','standalone-review.test.mjs']){
 const before=tests(read(`${root}/author8/scope-before-${name}`)),after=tests(read(`${src}/agent-team/tests/bug-pipeline/${name}`));assert.deepEqual(after,before);preserved.push({name,testCalls:before.length,allOriginalAssertionsPreserved:true,sha256:hash(JSON.stringify(before))});
}
const oldCausal=tests(read(`${root}/author8/causal-original.test.mjs`)).find(x=>x.name.startsWith('Author8 causal:'));
const currentCausal=tests(read(`${src}/agent-team/tests/bug-pipeline/github.test.mjs`)).find(x=>x.name.startsWith('Author8 causal:'));
// The TS printer preserves source multiline flags/trailing commas. Compare AST
// structure and literal text to ignore those formatting-only distinctions.
function structural(body){const file=ts.createSourceFile('causal.mjs',body,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);const shape=n=>{const children=[];ts.forEachChild(n,c=>{children.push(shape(c));});return[n.kind,typeof n.text==='string'?n.text:null,children];};return shape(file);}
assert.equal(currentCausal.name,oldCausal.name);assert.deepEqual(structural(currentCausal.body),structural(oldCausal.body));
const failures=[];
for(const label of ['causal-original','causal-implemented','github-first','github-failures-first','github-failures-corrected','roles-focused','roles-integrated-final']){
 const raw=fs.readFileSync(`${root}/author8/${label}.log`),receipt=JSON.parse(read(`${root}/author8/${label}.json`));assert.equal(hash(raw),receipt.logSha256);
 failures.push({label,exitCode:receipt.exitCode,logSha256:hash(raw),summary:Object.fromEntries([...raw.toString().matchAll(/^# (tests|pass|fail|skipped|cancelled|todo) (\d+)$/gm)].map(m=>[m[1],Number(m[2])])),failedNames:[...raw.toString().matchAll(/^not ok \d+ - (.*)$/gm)].map(m=>m[1])});
}
const syntax=[];
for(const entry of JSON.parse(read(`${root}/author8/syntax-final.json`)).results){const filename=path.join(src,entry.path),r=spawnSync(process.execPath,['--check',filename],{encoding:'utf8',env:process.env});assert.equal(r.status,0);syntax.push({path:entry.path,exitCode:r.status,sha256:hash(fs.readFileSync(filename))});}
assert.equal(syntax.length,17);
fs.writeFileSync(path.join(out,'verification-results.json'),JSON.stringify({sourceSha:'0f3833480fda5a056e91fa9922552d4f91bca346',preserved,causalExactOriginalAssertions:true,authorFailureHistory:failures,syntax:{checked:syntax.length,results:syntax}},null,2)+'\n');
console.log('PASS unchanged 92 role test calls and causal assertions; authenticated initial failure logs; 17 frozen source syntax checks.');
