import test from 'node:test';
import assert from 'node:assert/strict';
import {batchFor} from './pipeline-fixture.mjs';
import {actualPipeline} from './large-pipeline-loader.mjs';
import {gitDataStateFixture} from '../qa-source8/agent-team/tests/bug-pipeline/git-data-state-fixture.mjs';
import {feedbackFingerprint,sha256} from '../qa-source8/agent-team/src/bug-pipeline/contracts.mjs';
const repo='l2v-hub/ClinicOS';
const feedback=b=>({state:'OPEN',head:b.sha,headRef:b.branch,headRepo:repo,headIsFork:false,baseRef:'main',comments:[],unresolved:false,changesRequested:false});
function subject(n){
 const b=batchFor({issues:[n],phase:'waiting-review',reviews:[{round:1,status:'approved',subjectSha:'a'.repeat(40)}]});
 b.pr={number:n+64,url:`https://github.com/${repo}/pull/${n+64}`};
 const report=JSON.stringify({subject_sha:b.sha,verdict:'approved',summary:'Offline QA8 synthetic fixture',findings:[]});
 b.reviewLedger={rounds:[{round:1,subject_sha:b.sha,verdict:'approved',review_sha256:sha256(report)}]};
 b.reviewReports={'claude-review-1.json':report};b.externalReview={status:'published',subjectSha:b.sha,feedbackFingerprint:feedbackFingerprint(feedback(b))};return b;
}
function setup(){
 const f=gitDataStateFixture({schemaVersion:1,repository:repo,batches:[subject(17),subject(18)],payload:'x'.repeat(1048576)}),qa=[];
 const gh={intake:async()=>{},discoverQueue:async()=>[],setIssueStatus:async()=>{},commentIssue:async()=>{},commentPR:async()=>{},viewIssue:async()=>({state:'open'}),reviewFeedback:async n=>feedback(f.readState().batches.find(b=>b.pr.number===n)),requiredChecks:async()=>({ok:true}),draftReady:async()=>{},createStateStore:()=>f.store};
 const options={repo,event:{},gh,store:f.store,reviewMode:'external',models:{},workspace:{root:'/offline-qa8',prepare:async()=>{},finalQa:async b=>{qa.push(b.id);return{status:'verified',summary:'Offline QA8 fixture result'};}}};return{f,qa,options};
}
test('QA8 actual pipeline takeover during pinned parent Contents read preserves A exactly and performs only eligible B QA',async()=>{
 const{f,qa,options}=setup();let frozenA,moved=false;
 f.after=req=>{if(!moved&&req.method==='GET'&&req.path.includes('/contents/')&&!req.path.includes('ref=codex')){
  const next=f.readState();next.batches[0].operatorCoordination={active:true,owner:'offline-maintainer'};next.batches[0].remoteNote='Preserve this exact subject';frozenA=structuredClone(next.batches[0]);f.advance(next);moved=true;
 }};
 await(await actualPipeline())(options);
 assert(moved);assert.deepEqual(f.readState().batches[0],frozenA);assert.deepEqual(qa,['bug-batch-18']);assert.equal(f.readState().batches[1].phase,'ready');assert.equal(f.contentsWrites.length,0);assert(f.refWrites.length>0);
});
test('QA8 actual pipeline unconfirmed blob upload prevents every inference and later-subject reservation',async()=>{
 const{f,qa,options}=setup();const before=f.readBytes();let uploads=0;
 f.before=req=>{if(req.method==='POST'&&req.path.endsWith('/git/blobs')){uploads++;return{ok:false,code:1,error:'output-limit',stderr:'',stdout:''};}};
 await assert.rejects((await actualPipeline())(options),e=>e.code==='state-write-uncertain');
 assert.equal(uploads,1);assert.deepEqual(qa,[]);assert.deepEqual(f.readBytes(),before);assert.equal(f.refWrites.length,0);assert.equal(f.contentsWrites.length,0);
});
