import assert from 'node:assert/strict';
import {mkdir,writeFile,rm,mkdtemp} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {createRunner} from '../source9/agent-team/src/bug-pipeline/process.mjs';
const safeGitRunner=createRunner({env:{PATH:process.env.PATH},runtimeRoot:os.tmpdir()});
async function tempDir(t, prefix = 'clinicos-bug-pipeline-') {
  const directory = await mkdtemp(path.join(os.tmpdir(), prefix));
  t.after(() => rm(directory, { recursive: true, force: true }));
  return directory;
}
function evidencePlan(batch = 17) {
  return {
    evidence: [
      {
        issue: batch,
        screenshot: `artifacts/task-validation/bug-batch-${batch}/evidence/issue-${batch}.png`,
        trace: `artifacts/task-validation/bug-batch-${batch}/evidence/issue-${batch}-trace.zip`,
        video: '',
      },
    ],
  };
}
function implementationPlan(issues = [17]) {
  const batch = Math.min(...issues);
  return {
    title: 'Stabilize the patient list filter',
    feature: 'Patient list',
    rationale: 'Related reports share filter behavior.',
    execution: {
      difficulty: 'low',
      mode: 'delegate',
      reason: 'Bounded, independently testable change.',
    },
    analysis: 'The issue is caused by stale filter state.',
    issues,
    scope: ['frontend/src/features/patients/filter.ts'],
    acceptance: issues.map((issue) => ({ issue, criteria: [`Issue #${issue} is fixed`] })),
    tasks: [
      {
        title: 'Fix the state update',
        files: ['frontend/src/features/patients/filter.ts'],
        steps: ['Update state handling'],
      },
    ],
    verification: [
      { command: 'node', args: ['--test', 'frontend/src/features/patients/filter.test.mjs'] },
    ],
    evidence: evidencePlan(batch).evidence,
  };
}
async function git(cwd, ...args) {
  const result = await safeGitRunner({
    command: 'git',
    args,
    cwd,
    envMode: 'controller',
    timeoutMs: 10000,
    maxOutputBytes: 128 * 1024,
  });
  assert.equal(result.ok, true, `git ${args.join(' ')} failed: ${result.stderr}`);
  return result.stdout.trim();
}
async function gitFixture(t) {
  const root = await tempDir(t, 'clinicos-workspace-git-');
  const bare = path.join(root, 'remote.git');
  await git(root, 'init', '--bare', '--initial-branch=main', bare);
  const cwd = path.join(root, 'checkout');
  await mkdir(cwd);
  await git(cwd, 'init', '--initial-branch=main');
  await git(cwd, 'config', 'user.name', 'Pipeline test');
  await git(cwd, 'config', 'user.email', 'pipeline-test@example.invalid');
  await mkdir(path.join(cwd, 'frontend/src/features/patients'), { recursive: true });
  await writeFile(
    path.join(cwd, 'frontend/src/features/patients/filter.ts'),
    'export const filter = "before";\n',
  );
  await mkdir(path.join(cwd, 'node_modules'));
  await writeFile(path.join(cwd, 'node_modules/.present'), 'fixture\n');
  await writeFile(path.join(cwd, 'README.md'), 'baseline\n');
  await git(cwd, 'add', '.');
  await git(cwd, 'commit', '-m', 'fixture baseline');
  await git(cwd, 'remote', 'add', 'origin', bare);
  await git(cwd, 'push', '-u', 'origin', 'main');
  return { root: cwd };
}
export {gitFixture,implementationPlan};
