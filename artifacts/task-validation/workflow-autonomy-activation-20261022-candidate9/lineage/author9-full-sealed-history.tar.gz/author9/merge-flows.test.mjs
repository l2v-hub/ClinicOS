import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './release-fixture8.mjs';
import {batchFor,openFeedback} from './pipeline-fixture9.mjs';
import {actualPipeline} from './actual-pipeline9.mjs';
import {releaseBatch} from '../source9/agent-team/src/bug-pipeline/release.mjs';
import {createCommentReviewHandoff} from '../source9/agent-team/src/bug-pipeline/comment-review-handoff.mjs';
import {historyDigest} from '../source9/agent-team/src/bug-pipeline/attempt-budget.mjs';
import {feedbackFingerprint} from '../source9/agent-team/src/bug-pipeline/contracts.mjs';
const repo='l2v-hub/ClinicOS',runPipeline=await actualPipeline();
function setup(){
 const f=fixture(['docs/release.md']);f.batch.codexFinalReview={status:'verified',subjectSha:f.batch.sha,claudeRound:1,feedbackFingerprint:f.batch.feedbackFingerprint,nonce:'flow9',reservedAt:'2026-10-22T00:00:00Z'};f.batch.externalReview={status:'published',subjectSha:f.batch.sha,feedbackFingerprint:f.batch.feedbackFingerprint};
 const save=f.store.save;f.store.save=async(s,o)=>{await o?.guard?.();return save(s)};
 Object.assign(f.github,{createStateStore:()=>f.store,authorized:async()=>true,authorizedMaintainer:async()=>true,intake:async()=>{},discoverQueue:async()=>[],commentPR:async()=>{},commentIssue:async()=>{},setIssueStatus:async()=>{}});
 const view=f.github.viewIssue;f.github.viewIssue=async n=>({...await view(n),labels:['bug','codex-run']});
 f.handoff=createCommentReviewHandoff({github:f.github,cwd:'/synthetic',run:async()=>({ok:true,stdout:JSON.stringify({login:'maintainer'})})});
 f.release=()=>releaseBatch({repo,github:f.github,store:f.store,batchId:f.batch.id,reviewedSha:f.batch.sha,configured:{botToken:true},execute:true,automatic:true});return f;
}
for(const kind of ['guard-feedback','HTTP405'])test(`Author9 actual ${kind} archive/resume returns new feedback to external correction`,async()=>{
 const f=setup();let merges=0;
 f.github.mergePullRequest=async(_p,_s,{guard})=>{if(kind==='guard-feedback')f.feedback.unresolved=true;await guard();merges++;throw Object.assign(new Error('Definite refusal'),{code:'github-write-rejected',operation:'merge',httpStatus:405});};
 await assert.rejects(f.release(),e=>e.code==='github-merge-rejected');let b=f.getSaved().batches[0];const archived=structuredClone(b.mergeHistory[0]);assert.equal(b.release,undefined);assert.equal(merges,kind==='guard-feedback'?0:1);
 if(kind==='HTTP405')f.feedback.unresolved=true;
 await f.handoff.recover(9,{action:'resume',expectedSha:b.sha,token:historyDigest({phase:'blocked',failureCode:'github-merge-rejected'}),reason:'Fresh native exact-head OPEN proof'});
 let executions=0;
 const workspace={prepare:async()=>{},execute:async(_b,c)=>{executions++;assert.equal(c.phase,'external-review-correction');assert.equal(c.feedback.github.unresolved,true);return {status:'blocked'};}};
 await runPipeline({repo,event:{},gh:f.github,workspace,models:{},store:f.store,reviewMode:'external',triageWindowMs:0});b=f.getSaved().batches[0];assert.equal(executions,1);assert.equal(b.controllerProgress.status,'failed');assert.equal(b.release,undefined);assert.deepEqual(b.mergeHistory[0],archived);assert.equal(merges,kind==='guard-feedback'?0:1);
});
for(const timing of ['guard','catch'])test(`Author9 actual ownership loss during merge ${timing} preserves exact A while eligible B progresses`,async()=>{
 const f=setup();let frozen;
 const own=()=>{f.getSaved().batches[0].operatorCoordination={active:true};frozen=structuredClone(f.getSaved().batches[0]);};
 f.github.mergePullRequest=async(_p,_s,{guard})=>{if(timing==='guard')own();await guard();own();throw Object.assign(new Error('Refused'),{code:'github-write-rejected',operation:'merge',httpStatus:405});};
 await assert.rejects(f.release());assert.deepEqual(f.getSaved().batches[0],frozen);
 const b=batchFor({issues:[18],phase:'waiting-checks'});b.feedbackFingerprint=feedbackFingerprint(openFeedback(b));f.getSaved().batches.push(b);
 const feedback=f.github.reviewFeedback;f.github.reviewFeedback=async n=>n===9?feedback():openFeedback(b);
 const workspace={prepare:async()=>{},review:async subject=>({subject_sha:subject.sha,verdict:'approved',summary:'Synthetic eligible B approval',findings:[]}),reviewBody:()=>'',issueEvidence:async()=>''};
 await runPipeline({repo,event:{},gh:f.github,workspace,models:{},store:f.store,reviewMode:'internal',triageWindowMs:0});assert.deepEqual(f.getSaved().batches[0],frozen);assert.equal(f.getSaved().batches[1].phase,'ready');
});
