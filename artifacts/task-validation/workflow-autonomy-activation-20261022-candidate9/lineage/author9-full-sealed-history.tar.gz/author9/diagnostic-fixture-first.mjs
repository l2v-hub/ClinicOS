for (const kind of ['load-timeout', 'init-ref-timeout', 'init-ref-output-limit'])
  test(`Author9 F4 ${kind} preserves bounded diagnostic without raw transport text`, async () => {
    let refs = 0;
    const gh = createGitHub({ repo: 'l2v-hub/ClinicOS', run: async ({ args }) => {
      const endpoint = args[1];
      const error = kind.endsWith('output-limit') ? 'output-limit' : 'timeout';
      const failure = response({}, { ok: false, code: 1, error, stderr: 'PRIVATE_TOKEN patient: secret' });
      if (endpoint.includes('/contents/')) return failure;
      if (kind === 'load-timeout') return response({ object: { sha: 'a'.repeat(40) } });
      if (endpoint.endsWith('/git/ref/heads/main')) return response({ object: { sha: 'a'.repeat(40) } });
      if (args.includes('POST')) return response({}, { ok: false, code: 1, stderr: 'HTTP 422' });
      return ++refs === 1 ? response({}, { ok: false, code: 1, stderr: 'HTTP 404' }) : failure;
    } });
    await assert.rejects(gh.createStateStore().load(), error => {
      assert.equal(error.diagnostic, kind.endsWith('output-limit') ? 'output-limit' : 'timeout');
      assert.equal(error.httpStatus, null);
      assert.equal(error.code, kind.endsWith('output-limit') ? 'github-read-failed' : 'github-read-transient');
      assert.doesNotMatch(JSON.stringify(error), /PRIVATE_TOKEN|patient|secret/);
      return true;
    });
  });
