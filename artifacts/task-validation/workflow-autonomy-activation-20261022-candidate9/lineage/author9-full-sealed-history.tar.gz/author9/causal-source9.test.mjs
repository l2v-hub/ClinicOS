import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './release-fixture8.mjs';
import {gitDataStateFixture} from '../source8/agent-team/tests/bug-pipeline/git-data-state-fixture.mjs';
const root = new URL('../source9/agent-team/src/bug-pipeline/',import.meta.url);
const {releaseBatch}=await import(new URL('release.mjs',root));
const {runImplementationStages}=await import(new URL('workspace.mjs',root));
const {createGitHub,controllerFailureCode}=await import(new URL('github.mjs',root));
const response=(v,opts={})=>({ok:true,code:0,stdout:JSON.stringify(v),stderr:'',...opts});
function releaseFixture(){const f=fixture(['docs/release.md']);f.batch.codexFinalReview={status:'verified',subjectSha:f.batch.sha,claudeRound:1,feedbackFingerprint:f.batch.feedbackFingerprint,nonce:'causal9',reservedAt:'2026-10-22T00:00:00Z'};return f;}
const release=(f)=>releaseBatch({repo:f.state.repository,github:f.github,store:f.store,batchId:f.batch.id,reviewedSha:f.batch.sha,configured:{botToken:true},execute:true});
for(const kind of ['guard-feedback','HTTP405'])test(`causal F1 ${kind} ends only a known rejected merge reservation`,async()=>{
 const f=releaseFixture();let native=0;f.github.mergePullRequest=async(_p,_s,{guard})=>{if(kind==='guard-feedback')f.feedback.unresolved=true;await guard();native++;throw Object.assign(new Error('Definite merge refusal'),{code:'github-write-rejected',operation:'merge',httpStatus:405,diagnostic:'http-status'});};
 await assert.rejects(release(f));const b=f.getSaved().batches[0];assert.equal(native,kind==='guard-feedback'?0:1);assert.equal(b.release,undefined);assert.equal(b.phase,'blocked');assert.equal(b.failureCode,'github-merge-rejected');assert.equal(b.mergeHistory.at(-1).status,'merging');assert.ok(b.mergeHistory.at(-1).reviewProof);
});
for(const kind of ['verify','executor','qa'])test(`causal F2 ${kind} known failure sets failed journal`,async()=>{
 const batch={id:'b',sha:'a'.repeat(40),plan:{},implementation:[],reviews:[]};const workspace={execute:async()=>({status:kind==='executor'?'blocked':'implemented'}),simplify:async()=>({status:'implemented'}),verify:async()=>{if(kind==='verify')throw new Error('required verification failed or executed no tests');},qa:async()=>({status:'blocked'}),checkpoint:async()=>'',publish:async()=>{}};
 await assert.rejects(runImplementationStages({batch,workspace,save:async()=>{},context:{phase:'external-review-correction',round:2}}));assert.equal(batch.controllerProgress.status,'failed');assert.equal(batch.controllerProgress.failedStep,kind==='verify'?'verify-before':kind==='executor'?'execute':'qa');
});
function largeFixture(){const f=gitDataStateFixture({payload:'x'.repeat(1024*1024),batches:[]});f.store=createGitHub({repo:'l2v-hub/ClinicOS',run:(req)=>f.run(req)}).createStateStore();return f;}
test('causal F3 unchanged parent reuses pinned loaded state',async()=>{const f=largeFixture(),s=await f.store.load(),before=f.calls.filter(c=>c.path.includes('/git/blobs/')).length;s.local=true;await f.store.save(s);assert.equal(f.calls.filter(c=>c.path.includes('/git/blobs/')).length,before);});
test('causal F3 blob timeout is canonical not applied',async()=>{const f=largeFixture(),s=await f.store.load(),head=f.head;f.before=(r)=>r.method==='POST'&&r.path.endsWith('/git/blobs')?response({},{ok:false,code:1,error:'timeout'}):undefined;await assert.rejects(f.store.save(s),e=>e.code==='state-write-failed');assert.equal(f.head,head);assert.equal(f.refWrites.length,0);});
test('causal F3 ref timeout resolves only exact created next positive proof',async()=>{const f=largeFixture();f.store=createGitHub({repo:'l2v-hub/ClinicOS',run:async req=>{const r=await f.run(req);return req.args.includes('PATCH')?response({},{ok:false,code:1,error:'timeout'}):r;}}).createStateStore();const s=await f.store.load();s.local=true;await f.store.save(s);assert.equal(f.readState().local,true);assert.equal(f.refWrites.length,1);});
test('causal F4 load timeout surfaces finite diagnostic',async()=>{const g=createGitHub({repo:'l2v-hub/ClinicOS',run:async req=>req.args[1].includes('/contents/')?response({},{ok:false,code:1,error:'timeout',stderr:'PRIVATE_TOKEN patient'}):response({object:{sha:'a'.repeat(40)}})});await assert.rejects(g.createStateStore().load(),e=>e.code==='github-read-transient'&&e.diagnostic==='timeout'&&!JSON.stringify(e).includes('PRIVATE_TOKEN'));});
test('causal F5 executor blocked retains implementation code',async()=>{const b={plan:{}};await assert.rejects(runImplementationStages({batch:b,workspace:{execute:async()=>({status:'blocked'})},save:async()=>{},context:{phase:'pr-feedback',round:2}}),e=>controllerFailureCode(e)==='implementation-blocked');});
