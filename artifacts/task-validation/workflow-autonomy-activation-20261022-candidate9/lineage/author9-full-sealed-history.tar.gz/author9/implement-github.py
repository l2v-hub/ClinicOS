from pathlib import Path
p=Path('/tmp/clinicos-autonomy-activation-20261022/source9/agent-team/src/bug-pipeline/github.mjs');s=p.read_text()
s=s.replace("{ input, allowFailure = false, maxOutputBytes = 2 * 1024 * 1024, operation = 'read' } = {},","{ input, allowFailure = false, maxOutputBytes = 2 * 1024 * 1024, operation = 'read', timeoutMs = 30000 } = {},")
s=s.replace('timeoutMs: 30000,\n      maxOutputBytes,','timeoutMs,\n      maxOutputBytes,',1)
s=s.replace("async function api(path, { method, body, allowFailure = false, maxOutputBytes, guard } = {})", "async function api(path, { method, body, allowFailure = false, maxOutputBytes, guard, timeoutMs } = {})")
s=s.replace("...(maxOutputBytes === undefined ? {} : { maxOutputBytes }),\n    });","...(maxOutputBytes === undefined ? {} : { maxOutputBytes }),\n      ...(timeoutMs === undefined ? {} : { timeoutMs }),\n    });",1)
s=s.replace("if (!created.ok && !(await api(refPath, { allowFailure: true })).ok) {\n        throw new Error('Cannot initialize durable state branch');\n      }", "if (!created.ok) {\n        const confirmed = await api(refPath, { allowFailure: true });\n        if (!confirmed.ok) throw githubOperationError(confirmed.result, 'read');\n      }")
s=s.replace('function failedStateMutation(response) {','function failedStateMutation(response, refAttempted = true) {')
s=s.replace("const uncertain = !!result?.error || error.httpStatus === null;", "const uncertain = refAttempted && (!!result?.error || error.httpStatus === null || error.httpStatus >= 500 || error.httpStatus === 408);")
s=s.replace('// Only a confirmed ref update is durable. Failed/unknown object uploads never retry.', '// Object creation cannot publish canonical state; only a confirmed ref update is durable.\n    // No mutation is retried after an unconfirmed transport result.')
s=s.replace("let invoked = guard === undefined;\n      let response;", "const refAttempted = path.startsWith('git/refs/');\n      let invoked = guard === undefined;\n      let response;")
s=s.replace("method: path.startsWith('git/refs/') ? 'PATCH' : 'POST',\n          body,", "method: refAttempted ? 'PATCH' : 'POST',\n          ...(refAttempted ? {} : { timeoutMs: 120000 }),\n          body,")
s=s.replace("'state-write-uncertain',\n          'Durable state mutation result is unconfirmed; reconcile before retrying',", "refAttempted ? 'state-write-uncertain' : 'state-write-failed',\n          refAttempted\n            ? 'Durable state mutation result is unconfirmed; reconcile before retrying'\n            : 'Durable state object creation failed before reference publication',")
s=s.replace('throw failedStateMutation(response);','throw failedStateMutation(response, refAttempted);')
s=s.replace('async function saveGitData(content, expectedSHA, guard, checkFreshOwnership) {','async function saveGitData(content, expectedSHA, parentSnapshot, guard, checkFreshOwnership) {')
start=s.index('      const contents = await api(`repos/${repo}/contents/${STATE_PATH}?ref=${parent}`',s.index('async function saveGitData'))
end=s.index("      const blob = await stateMutation('git/blobs'",start)
s=s[:start]+'''      if ((target?.sha ?? null) !== expectedSHA) return { conflict: true };
      // The writer's candidate base was pinned before all awaits. A concurrent
      // load/validator cannot substitute its state for this matching blob identity.
      const parentState = target ? structuredClone(parentSnapshot) : null;
      if (target && !parentState)
        throw new Error('Pinned durable state base is unavailable');
      if (!target) {
        const contents = await api(`repos/${repo}/contents/${STATE_PATH}?ref=${parent}`, {
          allowFailure: true,
          maxOutputBytes: STATE_OUTPUT_BYTES,
        });
        if (contents.ok || githubOperationError(contents.result, 'read').httpStatus !== 404) {
          if (!contents.ok) throw githubOperationError(contents.result, 'read');
          throw new Error('Durable state absence does not match parent tree');
        }
      }
      let next;
      try {
'''+s[end:]
# replace metadata uncertain with failed in object section only
start=s.index('      let next;',s.index('async function saveGitData'));end=s.index('      const conflictSignal',start)
piece=s[start:end].replace("stateError('state-write-uncertain', 'Durable state blob SHA was not confirmed')", "stateError('state-write-failed', 'Durable state blob SHA was not confirmed')").replace('const next = created.value;', 'next = created.value;').replace("'state-write-uncertain',\n          'Durable state commit parent", "'state-write-failed',\n          'Durable state commit parent")
piece+='''      } catch (error) {
        if (error?.code === 'state-write-failed') throw error;
        throw stateError('state-write-failed', 'Durable state objects failed before reference publication', error);
      }
      // A positive exact-next read can confirm this write. Seeing the old parent
      // cannot rule out a still-running server request applying later.
      const confirmNext = async (failure) => {
        try {
          return (await stateReference()) === next.sha;
        } catch (error) {
          failure.proofError = error;
          return false;
        }
      };
'''
s=s[:start]+piece+s[end:]
s=s.replace("if (error === conflictSignal) return { conflict: true };\n        throw error;", "if (error === conflictSignal) return { conflict: true };\n        if (error?.code === 'state-write-uncertain' && (await confirmNext(error)))\n          return { sha: blobSHA };\n        throw error;")
s=s.replace("const failure = failedStateMutation(updated);\n        if (", "const failure = failedStateMutation(updated);\n        if (failure.code === 'state-write-uncertain' && (await confirmNext(failure)))\n          return { sha: blobSHA };\n        if (")
a=s.index("      if (\n        updated.value?.ref",s.index('async function saveGitData'));z=s.index("      return { sha: blobSHA };",a)
s=s[:a]+'''      if (
        updated.value?.ref !== `refs/heads/${STATE_BRANCH}` ||
        updated.value.object?.type !== 'commit' ||
        updated.value.object.sha !== next.sha
      ) {
        const failure = stateError(
          'state-write-uncertain',
          'Durable state reference update was not confirmed; reconcile before retrying',
        );
        if (!(await confirmNext(failure))) throw failure;
      }
'''+s[z:]
s=s.replace('candidateSHA = expectedFileSHA;', 'candidateSHA = expectedFileSHA,\n        candidateBase = structuredClone(originalBase);')
s=s.replace('saveGitData(content, candidateSHA, guard, checkFreshOwnership)', 'saveGitData(content, candidateSHA, candidateBase, guard, checkFreshOwnership)')
s=s.replace('const freshSHA = fileSHA; // A subsequent validator or guard load cannot promote this body.', 'const freshSHA = fileSHA,\n            freshBase = structuredClone(fresh); // Pin before any ownership/validator await.')
s=s.replace('candidateSHA = freshSHA;', 'candidateSHA = freshSHA;\n          candidateBase = freshBase;')
p.write_text(s)
print('github implementation written')
