from pathlib import Path
import hashlib,json,datetime
out=Path('/tmp/clinicos-autonomy-activation-20261022/author9');root=out.parent/'source9'
def bind(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def dump(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
r=json.loads((out/'results.json').read_text());manifest=json.loads((out/'source-manifest.json').read_text())
for n,v in manifest['all139BeforeAfter'].items():assert bind(root/n)==v['after']
assert len(manifest['all139BeforeAfter'])==139
# Every failed command is accounted for explicitly; no final failed command remains.
for n in ['integrated-final','private-final','syntax-command']:
 v=json.loads((out/(n+'.json')).read_text());assert v['exitCode']==0 and v['sourceUnchangedDuringCommand']
findings={'status':'author-implemented-awaiting-independent-QA','actualStaticReport':6360608335,'nativeClaim':False,'addressed':[{'id':'F1','scope':'batch merge known rejection archive and supported resume; uncertainty retained'},{'id':'F2','scope':'known stage failures, real three-flow reserved retry, unknown-work tombstones and exact failed worktree'},{'id':'F3','scope':'pinned parent/cache, pre-ref canonical-not-applied and positive-next-only reconciliation'},{'id':'F4','scope':'finite read diagnostic propagation including remaining init/read timeout branch'},{'id':'F5','scope':'blocked implementation code mapping'}],'authorKnownActionableOpenFindings':[],'independentQaPending':True,'limits':r['knownLimits']}
dump('findings.json',findings)
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
dump('STOP.json',{'status':r['status'],'nonce':r['nonce'],'sourceFrozen':True,'sourceFiles':139,'allowedChangedPaths':len(manifest['changedPaths']),'distinctFinalFunctionalNodeTests':1009,'causalOverlapTestsNotAdded':11,'syntaxChecks':17,'source9FinalRawSha256':r['source9FinalRawSha256'],'sourceManifestSha256':bind(out/'source-manifest.json')['sha256'],'at':now,'awaiting':'Root independent QA9/native/source9 module proof/peer/final/protected merge and activation gates','handoffComplete':False,'selfApproval':False,'noFurtherAuthorWrites':True})
files={str(p.relative_to(out)):bind(p) for p in sorted(out.rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='seal.json'}
seal={'schemaVersion':1,'status':r['status'],'nonce':r['nonce'],'sealedAt':now,'source9FinalRawSha256':r['source9FinalRawSha256'],'fileCount':len(files),'files':files}
dump('seal.json',seal)
print(json.dumps({'status':r['status'],'sourceFiles':139,'changedPaths':len(manifest['changedPaths']),'source9FinalRawSha256':r['source9FinalRawSha256'],'sourceManifestSha256':bind(out/'source-manifest.json')['sha256'],'sealSha256':bind(out/'seal.json')['sha256'],'sealedFiles':len(files),'distinctFunctionalTests':1009,'syntaxChecks':17},indent=2))
