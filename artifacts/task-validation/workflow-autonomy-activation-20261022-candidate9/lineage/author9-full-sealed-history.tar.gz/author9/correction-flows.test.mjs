import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './handoff-fixture9.mjs';
import {actualPipeline} from './actual-pipeline9.mjs';
import {feedbackFingerprint,sha256} from '../source9/agent-team/src/bug-pipeline/contracts.mjs';
import {historyDigest} from '../source9/agent-team/src/bug-pipeline/attempt-budget.mjs';
const repo='l2v-hub/ClinicOS';
const runPipeline=await actualPipeline();
for(const [flow,failure] of [['external-review-correction','verify'],['review-correction','qa'],['pr-feedback','executor']])test(`Author9 actual ${flow} failure, audited allowance, supported resume and new reserved correction`,async()=>{
 const f=fixture();f.setPermission('admin');f.batch.implementation=[1,2,3].map(round=>({round,status:'passed'}));
 delete f.batch.externalReview;
 const findings=[{file:'src/feature.ts',line:1,severity:'medium',problem:'Synthetic correction needed',requested_change:'Correct behavior',test_expectation:'Verify behavior'}];
 const verdict={subject_sha:f.batch.sha,verdict:'changes-requested',summary:'Synthetic findings',findings};
 if(flow!=='review-correction')f.batch.reviews=[{round:1,status:flow==='pr-feedback'?'approved':'changes-requested',subjectSha:f.batch.sha}];
 f.batch.feedbackFingerprint=feedbackFingerprint(await f.github.reviewFeedback(81));
 if(flow==='pr-feedback')f.feedback.comments.push({id:999,author:'maintainer',body:'Actual new correction feedback'});
 if(flow==='external-review-correction'){
  const raw=JSON.stringify(verdict);f.batch.reviewReports={'claude-review-1.json':raw};f.batch.reviewLedger={rounds:[{round:1,subject_sha:f.batch.sha,verdict:'changes-requested',review_sha256:sha256(raw)}]};f.batch.externalReview={status:'published',subjectSha:f.batch.sha,feedbackFingerprint:f.batch.feedbackFingerprint};
 }
 const prior=f.batch.implementation.map(x=>({...x}));
 let fixed=false,executions=0,reviews=0;const contexts=[];
 const workspace={root:'/synthetic',prepare:async()=>{},execute:async(b,c)=>{executions++;contexts.push(structuredClone(c));return {status:!fixed&&failure==='executor'?'blocked':'implemented'};},verify:async()=>{if(!fixed&&failure==='verify')throw new Error('required verification failed or executed no tests');},simplify:async()=>({status:'implemented'}),qa:async()=>({status:!fixed&&failure==='qa'?'blocked':'verified'}),checkpoint:async()=>{f.feedback.head='b'.repeat(40);return f.feedback.head;},publish:async()=>{},issueEvidence:async()=>'',reviewBody:()=>'',review:async b=>{reviews++;return {subject_sha:b.sha,verdict:flow==='review-correction'&&reviews===1?'changes-requested':'approved',summary:'Synthetic model report',findings:flow==='review-correction'&&reviews===1?findings:[]};}};
 f.github.intake=async()=>{};f.github.discoverQueue=async()=>[];f.github.setIssueStatus=async()=>{};f.github.commentIssue=async()=>{};f.github.commentPR=async()=>{};
 const view=f.github.viewIssue;f.github.viewIssue=async n=>({...await view(n),labels:['bug','codex-run']});
 const invoke=()=>runPipeline({repo,event:{},gh:f.github,workspace,models:{},store:f.github.createStateStore(),reviewMode:flow==='external-review-correction'?'external':'internal',triageWindowMs:0});
 await invoke();let b=f.remote.batches[0];assert.equal(b.phase,'blocked');assert.equal(b.controllerProgress.status,'failed');assert.equal(b.controllerProgress.flow,flow);assert.equal(b.controllerProgress.failedStep,failure==='verify'?'verify-before':failure==='qa'?'qa':'execute');assert.equal(b.implementation.length,4);assert.equal(b.implementation[3].status,'failed');assert.equal(executions,1);const failed=structuredClone(b.controllerProgress),oldReviews=structuredClone(b.reviews);
 const resume=()=>f.handoff.recover(81,{action:'resume',expectedSha:b.sha,token:historyDigest({phase:'blocked',failureCode:b.failureCode}),reason:'Audited next correction'});
 await assert.rejects(resume(),/allowances/);
 await f.handoff.extendBudget(81,{kind:'implementation',limit:5,authorizationRef:'test:author9',reason:'Exactly one additional correction'});
 await resume();fixed=true;await invoke();b=f.remote.batches[0];
 assert.equal(executions,2);assert.deepEqual(b.implementation.slice(0,3),prior);assert.equal(b.implementation[3].status,'failed');assert.equal(b.implementation[4].status,'passed');assert.equal(b.controllerProgress.implementationRound,5);assert.deepEqual(b.controllerProgressHistory,[failed]);assert.deepEqual(b.reviews.slice(0,oldReviews.length),oldReviews);assert.equal(b.controllerProgress.status,'completed');
 if(flow==='review-correction'){assert.deepEqual(contexts[1].feedback,failed.feedback);assert.equal(contexts[1].reviewRound,1);assert.equal(reviews,2);}
 if(flow==='external-review-correction'){assert.equal(b.phase,'waiting-review');assert.equal(b.externalReview.status,'requested');}else assert.equal(b.phase,'ready');
});
