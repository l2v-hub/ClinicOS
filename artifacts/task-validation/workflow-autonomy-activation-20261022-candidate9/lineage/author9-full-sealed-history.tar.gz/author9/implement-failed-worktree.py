from pathlib import Path
r=Path('/tmp/clinicos-autonomy-activation-20261022/source9/agent-team/src/bug-pipeline')
p=r/'workspace.mjs';s=p.read_text().replace("import { implementationAttempts }", "import { activeImplementation, implementationAttempts }")
a=s.index('export function createWorkspace')
s=s[:a]+'''// These fields are controller evidence, not a generic retry flag. Running/unknown
// work and malformed/stale failed journals cannot authorize another correction.
export function knownFailedCorrection(batch) {
  const progress = batch.controllerProgress;
  return Boolean(progress?.status === 'failed' &&
    ['pr-feedback', 'review-correction', 'external-review-correction'].includes(progress.flow) &&
    ((['execute', 'simplify'].includes(progress.failedStep) && progress.failureCode === 'implementation-blocked') ||
      (progress.failedStep === 'qa' && progress.failureCode === 'independent-qa-blocked') ||
      (['verify-before', 'verify-after'].includes(progress.failedStep) &&
        ['workspace-verification-failed', 'workspace-evidence-invalid', 'workspace-scope-invalid'].includes(progress.failureCode))) &&
    progress.sourceSha === batch.sha &&
    progress.planSha256 === sha256(JSON.stringify(batch.plan)) &&
    progress.feedbackSha256 === sha256(JSON.stringify(progress.feedback)) &&
    !activeImplementation(batch) && !batch.reviews.some((entry) => entry.status === 'running') &&
    (progress.implementationRound === undefined ||
      (progress.round === progress.implementationRound &&
        implementationAttempts(batch).at(-1)?.round === progress.implementationRound &&
        implementationAttempts(batch).at(-1)?.status === 'failed')));
}

'''+s[a:]
s=s.replace("    async prepare(batch) {\n      const { cwd, packet } = coordinates(batch);", """    async prepare(batch) {
      const { cwd, packet } = coordinates(batch);
      if (knownFailedCorrection(batch)) {
        const checkpoint = batch.controllerProgress.checkpoint;
        if (!checkpoint || checkpoint.head !== batch.sha ||
          JSON.stringify(await captureCheckpoint(batch)) !== JSON.stringify(checkpoint))
          throw new Error('Exact failed correction checkpoint is missing or changed; no model replay');
        return; // Retain only these exact owned dirty outputs; never clean or reconstruct them.
      }""")
s=s.replace("      if (definite) {\n        progress.status = 'failed';", """      if (definite) {
        // Failure capture is itself a boundary: if it fails, keep running and
        // require explicit recovery rather than treating unknown output as reusable.
        if (typeof workspace.captureCheckpoint === 'function')
          progress.checkpoint = await workspace.captureCheckpoint(batch);
        progress.status = 'failed';""")
p.write_text(s)
p=r/'comment-review-handoff.mjs';s=p.read_text();s="import { knownFailedCorrection } from './workspace.mjs';\n"+s
a=s.index('        const knownCorrection =');z=s.index('        const allowance =',a)
s=s[:a]+"        const knownCorrection = knownFailedCorrection(batch) && progress.failureCode === batch.failureCode;\n"+s[z:];p.write_text(s)
print('Accepted failed-worktree boundary implemented')
