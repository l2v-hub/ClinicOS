from pathlib import Path
root=Path('/tmp/clinicos-autonomy-activation-20261022/source9/agent-team/src/bug-pipeline')
p=root/'workspace.mjs';s=p.read_text();s="import { implementationAttempts } from './attempt-budget.mjs';\nimport { controllerFailureCode, stateError } from './github.mjs';\n"+s
s=s.replace("      throw new Error('Unknown implementation outcome requires explicit recovery');\n    progress =", "      throw new Error('Unknown implementation outcome requires explicit recovery');\n    if (progress?.status === 'failed') {\n      batch.controllerProgressHistory ??= [];\n      batch.controllerProgressHistory.push(structuredClone(progress));\n    }\n    progress =")
s=s.replace("      flow: context.phase,\n      round: context.round,", "      flow: context.phase,\n      round: context.round,\n      ...(context.implementationRound === undefined ? {} : { implementationRound: context.implementationRound }),\n      ...(context.reviewRound === undefined ? {} : { reviewRound: context.reviewRound }),")
# Bind new journals to the real reserved implementation identity before invoking anything.
a=s.index('  for (let index = progress.next;',s.index('export async function runImplementationStages'))
s=s[:a]+'''  if (progress.implementationRound !== undefined &&
    (progress.implementationRound !== context.implementationRound ||
      !implementationAttempts(batch).some((entry) =>
        entry.round === progress.implementationRound && entry.status === 'running')))
    throw new Error('Implementation reservation changed');
'''+s[a:]
a=s.index("    if (step === 'execute') {",s.index('export async function runImplementationStages'));z=s.index('    progress.completed.push',a)
s=s[:a]+'''    try {
      if (step === 'execute' || step === 'simplify' || step === 'qa') {
        result = step === 'execute'
          ? await workspace.execute(batch, context)
          : await workspace[step](batch);
        const accepted = step === 'qa' ? 'verified' : 'implemented';
        if (result?.status === 'blocked')
          throw stateError(step === 'qa' ? 'independent-qa-blocked' : 'implementation-blocked',
            step === 'execute' ? 'executor blocked' : step === 'simplify' ? 'simplification blocked' : 'Independent QA blocked');
        if (result?.status !== accepted)
          throw stateError('model-result-invalid', 'Implementation stage result is unconfirmed');
      } else if (step === 'checkpoint') {
        result = await workspace.checkpoint(batch);
        batch.sha = result;
      } else if (step === 'publish') await workspace.publish(batch);
      else await workspace.verify(batch);
    } catch (error) {
      // Only explicit blocked model results or definite verification validation
      // failures end an attempt. Transport/model exceptions and all surrounding
      // persistence/checkpoint/guard boundaries retain their running tombstone.
      const code = controllerFailureCode(error);
      const definite =
        (['execute', 'simplify', 'qa'].includes(step) &&
          ['implementation-blocked', 'independent-qa-blocked'].includes(error?.code)) ||
        (['verify-before', 'verify-after'].includes(step) &&
          ['workspace-verification-failed', 'workspace-evidence-invalid', 'workspace-scope-invalid'].includes(code));
      if (definite) {
        progress.status = 'failed';
        progress.failedStep = step;
        progress.failureCode = code;
      }
      throw error;
    }
'''+s[z:];p.write_text(s)
p=root/'external-review.mjs';s=p.read_text();s=s.replace("phase: 'external-review-correction',\n          round: attempt.round,", "phase: 'external-review-correction',\n          round: attempt.round,\n          ...(resumingCorrection && batch.controllerProgress.implementationRound === undefined\n            ? {} : { implementationRound: attempt.round }),")
s=s.replace("if (!['review-operator-owned', 'ownership-observation-failed'].includes(error?.code))\n        attempt.status = 'failed';", "if (batch.controllerProgress?.status === 'failed') attempt.status = 'failed';")
p.write_text(s)
p=root/'pipeline.mjs';s=p.read_text();s=s.replace("phase: 'implementation',\n                round: attempt.round,", "phase: 'implementation',\n                round: attempt.round,\n                ...(resuming && batch.controllerProgress.implementationRound === undefined\n                  ? {} : { implementationRound: attempt.round }),")
s=s.replace("              persistenceFailed ||\n              resuming ||", "              persistenceFailed ||\n              batch.controllerProgress?.status !== 'failed' ||\n              resuming ||")
s=s.replace("if (batch.controllerProgress) batch.controllerProgress.status = 'failed';\n",'')
# Preserve unknown active journal/attempt identity in the generic catch; completed known histories still finalize existing behavior.
s=s.replace("if (a.status === 'running') a.status = 'failed';", "if (a.status === 'running' && batch.controllerProgress?.status !== 'running') a.status = 'failed';")
# helper inserted before batch loop, uses existing guarded workspace/save/clock.
a=s.index('  for (const id of state.batches.map((batch) => batch.id)) {')
s=s[:a]+'''  const runCorrection = async (batch, context, retained = false) => {
    const previous = batch.controllerProgress;
    // Legacy observation-resume journals used review rounds, without a paid
    // implementation reservation. Resume those exact retained stages as before.
    const legacyResume = retained && previous.implementationRound === undefined;
    const attempt = legacyResume ? null : retained
      ? implementationAttempts(batch).find((entry) =>
          entry.round === previous.implementationRound && entry.status === 'running')
      : reserveImplementation(batch, () => new Date(now()));
    if (!legacyResume && !attempt) throw new Error('Implementation reservation changed');
    try {
      await runImplementationStages({ batch, workspace, save, context: {
        ...context,
        round: legacyResume ? previous.round : attempt.round,
        ...(legacyResume ? {} : { implementationRound: attempt.round }),
      } });
      if (attempt) attempt.status = 'passed';
    } catch (error) {
      if (attempt && batch.controllerProgress?.status === 'failed') attempt.status = 'failed';
      throw error;
    }
  };
'''+s[a:]
# PR feedback caller replace precise block
start=s.index('        await runImplementationStages({',s.index('// New PR feedback'))
end=s.index('        await report(batch, await workspace.issueEvidence(batch));',start)
s=s[:start]+'''        await runCorrection(batch, {
          phase: 'pr-feedback',
          reviewRound: batch.reviews.length + 1,
          feedback: resuming && batch.controllerProgress.flow === 'pr-feedback'
            ? batch.controllerProgress.feedback : feedback,
        }, resuming && batch.controllerProgress.flow === 'pr-feedback');
'''+s[end:]
start=s.index("      if (resuming && batch.controllerProgress.flow === 'review-correction') {")
end=s.index('        batch.approvedSha = null;',start)
s=s[:start]+'''      if ((resuming || batch.controllerProgress?.status === 'failed') &&
        batch.controllerProgress.flow === 'review-correction') {
        const retained = batch.controllerProgress;
        if (!resuming &&
          (retained.sourceSha !== batch.sha ||
            retained.planSha256 !== sha256(JSON.stringify(batch.plan)) ||
            retained.feedbackSha256 !== sha256(JSON.stringify(retained.feedback))))
          throw new Error('Failed correction identity changed');
        await runCorrection(batch, {
          phase: 'review-correction',
          reviewRound: retained.reviewRound ?? retained.round,
          feedback: retained.feedback,
        }, resuming);
'''+s[end:]
start=s.index('        await runImplementationStages({',s.index('      while (batch.reviews.length < attemptLimit'))
end=s.index('        batch.approvedSha = null;',start)
s=s[:start]+'''        await runCorrection(batch, {
          phase: 'review-correction',
          reviewRound: attempt.round,
          feedback: { claude: review, github: after },
        });
'''+s[end:]
p.write_text(s)
print('journal and narrow internal caller accounting written')
