from pathlib import Path
import json,hashlib,datetime,difflib,re
base=Path('/tmp/clinicos-autonomy-activation-20261022');out=base/'author9';root=base/'source9';nonce='306e10be-29ce-4784-b4ff-97db849b5a45'
def bind(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def dump(p,obj):p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def files(r):
 return {str(p.relative_to(r)):bind(p) for p in sorted(r.rglob('*')) if p.is_file() and not p.is_symlink() and not any(x.is_symlink() for x in p.parents if x!=r)}
beforeRaw=json.loads((out/'source-before.json').read_text());before={k:{'sha256':v['sha256'],'bytes':v['bytes']} for k,v in beforeRaw['source9']['files'].items()};after=files(root)
assert len(before)==len(after)==139 and before.keys()==after.keys()
changed=[n for n in after if before[n]!=after[n]];allow=json.loads((out/'effective-allowlist.json').read_text());assert set(changed)<=set(allow)
for label in ['integrated-final','private-final','syntax-command']:
 r=json.loads((out/(label+'.json')).read_text());assert r['exitCode']==0 and r['sourceUnchangedDuringCommand'];assert r['sourceAfter']=={n:v['sha256'] for n,v in after.items()}
dump(out/'source9-final.json',after);finalHash=bind(out/'source9-final.json')['sha256']
manifest={'schemaVersion':1,'nonce':nonce,'sourceFiles':139,'inheritedSourceFiles':139,'newSourceFiles':0,'source9FinalRawSha256':finalHash,'snapshotDigestEncoding':'sha256 of exact raw UTF8 source9-final.json bytes','changedPaths':changed,'effectiveAllowedPaths':allow,'declaredLinks':[{'path':n,'target':str((root/n).readlink())} for n in beforeRaw['source9']['symlinks']],'all139BeforeAfter':{n:{'before':before[n],'after':after[n]} for n in after}}
dump(out/'source-manifest.json',manifest)
patch=''
for n in changed:
 a=(base/'source8'/n).read_text().splitlines(keepends=True);b=(root/n).read_text().splitlines(keepends=True);patch+=''.join(difflib.unified_diff(a,b,fromfile='a/'+n,tofile='b/'+n))
(out/'source.patch').write_text(patch)
# Verify frozen baseline raw bytes and all owned evidence of the immediately previous author/QA/children.
invariants={'baselineFiles':{},'seals':[],'originalReservationUnchanged':False}
for name in ['source8','qa-source8']:
 expected={n:{'sha256':v['sha256'],'bytes':v['bytes']} for n,v in beforeRaw[name]['files'].items()};actual=files(base/name);assert actual==expected;invariants['baselineFiles'][name]={'files':len(actual),'unchanged':True}
for name in ['author8','independent-qa8','Luna-state-transport-docs8','Luna-diagnostics9','author7','independent-qa7','author6','independent-qa6','luna-draftReady7']:
 p=base/name/'seal.json'
 if not p.exists():continue
 seal=json.loads(p.read_text());checked=0
 for n,v in seal.get('files',{}).items():
  if not isinstance(v,dict) or 'sha256'not in v:continue
  f=p.parent/n;assert f.is_file(),str(f);assert bind(f)=={'sha256':v['sha256'],'bytes':v['bytes']},str(f);checked+=1
 invariants['seals'].append({'path':str(p),'sha256':bind(p)['sha256'],'sealedFilesVerified':checked,'unchanged':True})
receipts=json.loads((out/'analysis-read-receipts.json').read_text())
for v in receipts['contractAndEvidence']:
 p=Path(v['path']);assert bind(p)=={'sha256':v['sha256'],'bytes':v['bytes']},str(p)
invariants['originalReservationUnchanged']=True
dump(out/'preservation-verification.json',invariants)
# Preserve command identities and failures without adding repeated tests to the count.
commands=[]
for p in sorted(out.glob('*.json')):
 r=json.loads(p.read_text())
 if isinstance(r,dict) and 'command'in r and 'exitCode'in r:commands.append({'label':p.stem,**r})
dump(out/'command-history.json',commands)
classes={
'causal-source8':'Expected genuine baseline failures: all10 finding assertions fail on unchanged source8.',
'causal-source9-first':'Harness target-selection error: Node --test dropped positional target; this command actually reread source8. Original script/log retained; corrected source9 target changes imports only.',
'focused-first':'750 Node tests;714 passed36 failed. Intended transport/archive expectation changes exposed obsolete assertions: parent no longer downloaded, pre-ref object failures definite, ref5xx uncertain, exact-next success reconciliation, cached metadata read absent, typed wrapping, known merge archives. No old safety assertions waived; pre-adaptation test copies and explicit adaptation script retained.',
'actual-correction-flows-first':'Two of3 passed; the third passed failure/allowance/resume/new-attempt/history assertions but expected waiting-checks. Actual external step queues next review and ends waiting-review. Corrected expected final state plus requested handoff assertion; first test copy retained.',
'focused-second':'792 of795 passed. Three new read-diagnostic fixtures used inherited response() helper which drops arbitrary error metadata, so timeout/output-limit were accidentally unknown. Fixture now preserves actual error property; diagnostic assertions unchanged. Original snippet retained.',
'new-controls':'56 of57 passed. Running negative fixture rewrote an already frozen attempt status after its budget grant; immutable history validation correctly rejected earlier. Fixture now alters journal status only, preserving historical attempts, and actual unknown-flow probes separately cover legitimately running reservations.',
'worktree-causal-source8':'Expected genuine additional baseline failure: seeded bound known-failure record and exact actual dirty owned worktree reaches ordinary prepare and is rejected. Seeded record isolates prepare from the separately reproduced F2 status defect.'}
failures=[]
for r in commands:
 if r['exitCode']!=0:
  assert r['label']in classes,r['label'];failures.append({'label':r['label'],'exitCode':r['exitCode'],'classification':classes[r['label']],'commandReceipt':r['label']+'.json','rawLog':r['label']+'.log'})
dump(out/'failure-history.json',failures)
identities={}
for label in ['integrated-final','private-final']:
 txt=(out/(label+'.log')).read_text();identities[label]={'nodeTests':int(re.search(r'^# tests (\d+)$',txt,re.M).group(1)),'pass':int(re.search(r'^# pass (\d+)$',txt,re.M).group(1)),'fail':int(re.search(r'^# fail (\d+)$',txt,re.M).group(1)),'names':re.findall(r'^\s*# Subtest: (.+)$',txt,re.M)}
dump(out/'test-identities.json',identities)
results={'schemaVersion':1,'status':'IMPLEMENTED_AWAITING_INDEPENDENT_QA','nonce':nonce,'sourceFrozen':True,'sourceFiles':139,'changedPaths':changed,'effectiveAllowedPaths':allow,'source9FinalRawSha256':finalHash,'sourceManifestSha256':bind(out/'source-manifest.json')['sha256'],'distinctFinalFunctionalNodeTests':1009,'counting':{'cumulative15Suites':994,'additionalActualFlowAndInheritedTransportTests':15,'privateFinalRawTests':26,'causalOverlapTestsNotAdded':11,'child233TestsAreSubsetsNotAdded':233,'syntaxChecks':17,'zeroSkips':True,'zeroFailuresFinal':True},'manifestFormat':'source-manifest.json all139BeforeAfter maps relative path to before/after {sha256,bytes}; source9-final.json is exact final plain map.','failureHistory':'failure-history.json','testIdentities':'test-identities.json','finalCommands':['integrated-final.json','private-final.json','syntax-command.json'],'allFinalCommandSourceSnapshotsMatch':True,'preservation':'preservation-verification.json','planAcceptances':['root-plan-acceptance.json','root-pipeline-scope-amendment.json','root-internal-accounting-amendment.json','root-failed-worktree-amendment.json'],'childIntegration':'child-integration-verified.json','noLiveActions':True,'noGitWritesOutsideIsolatedFixtures':True,'nativeHistoryPreserved':{'implementationEntries':8,'actualNativeReviews':1,'attempt9ReservedByRoot':True,'staticClaudeReport':6360608335,'staticReportIsNotNativeClaim':True},'remainingRootGates':['independent QA9','actual native CI','actual frozen source9 module proof','genuine peer review','final review','fresh handback absence proof immediately before eventual merge','finite historical11 cutover','protected source merge and event activation'],'knownLimits':['An uncertain ref still at parent can apply later; no automatic retry.','Missing/changed retained hosted worktrees cannot be reconstructed or replayed.','External force-rewind ABA after final ref read remains outside nonforced ordinary-forward-writer guarantee.','Read cause on personal Windows remains unproven; finite diagnostics do not infer credentials.'],'selfApproval':False,'handoffComplete':False}
dump(out/'results.json',results)
print(json.dumps({'sourceFiles':139,'changedPaths':changed,'source9FinalRawSha256':finalHash,'distinctFunctional':1009,'syntax':17,'priorSealsVerified':len(invariants['seals']),'firstFailuresPreserved':len(failures)},indent=2))
