import ts from '/workspace/ClinicOS/node_modules/typescript/lib/typescript.js';
import {readFile,writeFile} from 'node:fs/promises';
const base='/tmp/clinicos-autonomy-activation-20261022',raw=await readFile(`${base}/source9/agent-team/tests/bug-pipeline/workspace.test.mjs`,'utf8');
const source=ts.createSourceFile('fixture.mjs',raw,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),names=new Set(['tempDir','git','gitFixture','implementationPlan','evidencePlan']);
const pieces=source.statements.filter(n=>ts.isFunctionDeclaration(n)&&names.has(n.name?.text)).map(n=>raw.slice(n.getStart(source),n.end));
await writeFile(`${base}/author9/git-fixture9.mjs`,`import assert from 'node:assert/strict';\nimport {mkdir,writeFile,rm,mkdtemp} from 'node:fs/promises';\nimport path from 'node:path';\nimport os from 'node:os';\nimport {createRunner} from '../source9/agent-team/src/bug-pipeline/process.mjs';\nconst safeGitRunner=createRunner({env:{PATH:process.env.PATH},runtimeRoot:os.tmpdir()});\n${pieces.join('\n')}\nexport {gitFixture,implementationPlan};\n`);
