import test from 'node:test';
import assert from 'node:assert/strict';
import {batchFor} from './pipeline-fixture.mjs';
import {gitDataStateFixture} from './large-repo-fixture.mjs';
import {actualPipeline} from './large-pipeline-loader.mjs';
import {feedbackFingerprint,sha256} from '../source9/agent-team/src/bug-pipeline/contracts.mjs';
const repo='l2v-hub/ClinicOS';
function feedback(b){return{state:'OPEN',head:b.sha,headRef:b.branch,headRepo:repo,headIsFork:false,baseRef:'main',comments:[],unresolved:false,changesRequested:false}}
function batch(n){const b={...batchFor({issues:[n],phase:'waiting-review',reviews:[{round:1,status:'approved',subjectSha:'a'.repeat(40)}]}),pr:{number:n+64,url:`https://github.com/${repo}/pull/${n+64}`}};const raw=JSON.stringify({subject_sha:b.sha,verdict:'approved',summary:'Synthetic approved fixture',findings:[]});b.reviewLedger={rounds:[{round:1,subject_sha:b.sha,verdict:'approved',review_sha256:sha256(raw)}]};b.reviewReports={'claude-review-1.json':raw};b.externalReview={status:'published',subjectSha:b.sha,feedbackFingerprint:feedbackFingerprint(feedback(b))};return b}
for(const race of ['after-commit-before-ref','ref422'])test(`Author8 actual large-state pipeline ownership race ${race} preserves exact A and progresses only B`,async()=>{
 const f=gitDataStateFixture({schemaVersion:1,repository:repo,batches:[batch(17),batch(18)],payload:'x'.repeat(1024*1024)}),store=f.store;
 let pending=false,injected=false,frozenA;const qa=[];
 const inject=()=>{const state=f.readState();state.batches[0].operatorCoordination={active:true,owner:'maintainer'};state.batches[0].remoteNote='Exact remote large-state subject';frozenA=structuredClone(state.batches[0]);f.advance(state);injected=true};
 f.before=req=>{if(req.path.endsWith('/git/blobs')&&req.method==='POST')pending=JSON.parse(Buffer.from(req.body.content,'base64')).batches[0].codexFinalReview?.status==='running';if(race==='ref422'&&pending&&!injected&&req.method==='PATCH')inject()};
 f.after=req=>{if(race==='after-commit-before-ref'&&pending&&!injected&&req.path.endsWith('/git/commits'))inject()};
 const gh={intake:async()=>{},discoverQueue:async()=>[],setIssueStatus:async()=>{},commentIssue:async()=>{},commentPR:async()=>{},viewIssue:async()=>({state:'open'}),reviewFeedback:async n=>feedback(f.readState().batches.find(b=>b.pr.number===n)),requiredChecks:async()=>({ok:true}),draftReady:async()=>{},createStateStore:()=>store};
 const pipeline=await actualPipeline();
 await pipeline({repo,event:{},gh,store,reviewMode:'external',models:{},workspace:{root:'/synthetic',prepare:async()=>{},finalQa:async b=>{qa.push(b.id);return{status:'verified',summary:'Synthetic large transport boundary'}}}});
 assert.equal(injected,true);assert.deepEqual(qa,['bug-batch-18']);assert.deepEqual(f.readState().batches[0],frozenA);assert.equal(f.readState().batches[1].phase,'ready');assert.equal(f.contentsWrites.length,0);assert.ok(f.refWrites.length>0);assert.deepEqual(f.entries().filter(e=>e.path!=='.codex-bug-state.json'),f.sentinels);
});
