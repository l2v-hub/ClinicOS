import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {writeFile} from 'node:fs/promises';
import {gitFixture,implementationPlan} from './git-fixture9.mjs';
import {createWorkspace} from '../source8/agent-team/src/bug-pipeline/workspace.mjs';
import {createRunner} from '../source9/agent-team/src/bug-pipeline/process.mjs';
import {sha256} from '../source9/agent-team/src/bug-pipeline/contracts.mjs';
test('Author9 causal bound known failed correction retains exact dirty owned Git worktree',async t=>{
 const {root}=await gitFixture(t),plan=implementationPlan([17]);const batch={id:'bug-batch-17',branch:'codex/bug-batch-17',issues:[17],plan,implementation:[1,2,3,4].map(round=>({round,status:round===4?'failed':'passed'})),reviews:[]};
 const run=createRunner({env:{PATH:process.env.PATH},runtimeRoot:process.env.TMPDIR});const workspace=createWorkspace({root,repo:'l2v-hub/ClinicOS',run,models:{}});await workspace.prepare(batch);batch.sha=batch.baseSha;
 await writeFile(path.join(root,'agent-team/.worktrees',batch.id,plan.scope[0]),'export const filter="known failed owned output";\n');
 // A seeded synthetic controller record isolates prepare from F2's separate journal defect.
 batch.controllerProgress={schemaVersion:1,status:'failed',flow:'pr-feedback',round:4,implementationRound:4,sourceSha:batch.sha,planSha256:sha256(JSON.stringify(plan)),feedback:{known:'finding'},feedbackSha256:sha256(JSON.stringify({known:'finding'})),failedStep:'verify-before',failureCode:'workspace-verification-failed',checkpoint:await workspace.captureCheckpoint(batch)};
 await workspace.prepare(batch);assert.equal(batch.controllerProgress.status,'failed');
});
