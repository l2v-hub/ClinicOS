import test from 'node:test';
import assert from 'node:assert/strict';
import {createGitHub} from '../qa-source9/agent-team/src/bug-pipeline/github.mjs';
const cases=[['existing-ref','output-limit'],['existing-ref','spawn-failed'],['existing-ref','rate-limit'],['main-ref','spawn-failed'],['main-ref','timeout'],['main-ref','output-limit'],['final-init-ref','spawn-failed'],['final-init-ref','rate-limit'],['final-init-ref','unknown'],['load','spawn-failed'],['load','rate-limit'],['dashboard','timeout'],['dashboard','output-limit'],['dashboard','spawn-failed'],['dashboard','rate-limit'],['dashboard','unknown']];
const response=(value,extra={})=>({ok:true,code:0,stdout:JSON.stringify(value),stderr:'',...extra});
for(const [boundary,diagnostic]of cases)test(`QA9 novel finite diagnostic ${diagnostic} at actual ${boundary} boundary`,async()=>{
 let refReads=0,failures=0;
 const failure=()=>{failures++;return response({}, {ok:false,code:1,stderr:diagnostic==='rate-limit'?'HTTP 403 API rate limit exceeded PRIVATE_SENTINEL patient=synthetic':'PRIVATE_SENTINEL patient=synthetic',...(diagnostic==='unknown'||diagnostic==='rate-limit'?{}:{error:diagnostic})})};
 const gh=createGitHub({repo:'l2v-hub/ClinicOS',run:async({args})=>{
  const endpoint=args[1];
  if(boundary==='dashboard')return failure();
  if(endpoint.endsWith('/git/ref/heads/codex/bug-control')){refReads++;if(boundary==='existing-ref'||boundary==='final-init-ref'&&refReads>1)return failure();if(boundary==='main-ref'||boundary==='final-init-ref')return response({}, {ok:false,code:1,stderr:'HTTP 404'});return response({object:{sha:'a'.repeat(40)}})}
  if(endpoint.endsWith('/git/ref/heads/main'))return boundary==='main-ref'?failure():response({object:{sha:'a'.repeat(40)}});
  if(args.includes('POST'))return response({}, {ok:false,code:1,stderr:'HTTP 422'});
  assert.ok(endpoint.includes('/contents/'));return failure();
 }});
 await assert.rejects(boundary==='dashboard'?gh.readDashboardState():gh.createStateStore().load(),error=>{
  assert.equal(error.diagnostic,diagnostic);assert.equal(error.httpStatus,diagnostic==='rate-limit'?403:null);assert.equal(error.operation,'read');assert.equal(error.code,['timeout','rate-limit'].includes(diagnostic)?'github-read-transient':'github-read-failed');assert.doesNotMatch(JSON.stringify(error),/PRIVATE_SENTINEL|patient=|synthetic/);assert.doesNotMatch(error.message,/PRIVATE_SENTINEL|patient=/);return true;
 });assert.equal(failures,1,'No automatic read retry');
});
