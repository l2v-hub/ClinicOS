import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {SourceTextModule,SyntheticModule,createContext} from 'node:vm';
export async function actualPipeline(){
 const context=createContext({process:{env:{},argv:['node','/synthetic'],cwd:()=>'/synthetic'},console,structuredClone,Buffer,setTimeout,clearTimeout,URL});const cache=new Map();
 const synthetic=exports=>new SyntheticModule(Object.keys(exports),function(){for(const[k,v]of Object.entries(exports))this.setExport(k,v)},{context});
 async function load(url){if(cache.has(url))return cache.get(url);const mod=new SourceTextModule(await readFile(new URL(url),'utf8'),{context,identifier:url,initializeImportMeta:meta=>meta.url=url});cache.set(url,mod);await mod.link(async(spec,parent)=>{
  if(spec==='./external-review.mjs'&&parent.identifier.endsWith('/pipeline.mjs'))return load(new URL(spec,parent.identifier).href);
  if(spec==='./issue-review-communication.mjs')return synthetic({createIssueReviewCommunication:()=>({mirrorFeedback:async()=>{},publishState:async()=>{}})});
  if(spec==='./process.mjs')return synthetic({createRunner:()=>()=>assert.fail('No process/model allowed')});
  return synthetic(await import(spec.startsWith('.')?new URL(spec,parent.identifier).href:spec));});return mod;}
 const mod=await load(new URL('../qa-source9/agent-team/src/bug-pipeline/pipeline.mjs',import.meta.url).href);await mod.evaluate();return mod.namespace.runPipeline;
}
