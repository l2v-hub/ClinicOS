export { gitDataStateFixture } from '../qa-source9/agent-team/tests/bug-pipeline/git-data-state-fixture.mjs';
