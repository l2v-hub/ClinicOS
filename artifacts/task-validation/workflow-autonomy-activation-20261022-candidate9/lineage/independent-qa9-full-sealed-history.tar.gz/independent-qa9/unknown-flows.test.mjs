import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './handoff-fixture9.mjs';
import {actualPipeline} from './actual-pipeline9.mjs';
import {feedbackFingerprint,sha256} from '../qa-source9/agent-team/src/bug-pipeline/contracts.mjs';
import {historyDigest} from '../qa-source9/agent-team/src/bug-pipeline/attempt-budget.mjs';
const repo='l2v-hub/ClinicOS',runPipeline=await actualPipeline();
for(const flow of ['external-review-correction','review-correction','pr-feedback'])for(const outcome of ['model','save'])test(`QA9 inherited actual ${flow} unknown ${outcome} keeps running even with unused audited allowance`,async()=>{
 const f=fixture();f.setPermission('admin');f.batch.implementation=[1,2,3].map(round=>({round,status:'passed'}));delete f.batch.externalReview;
 const findings=[{file:'src/feature.ts',line:1,severity:'medium',problem:'Synthetic finding',requested_change:'Correct behavior',test_expectation:'Verify'}];
 const verdict={subject_sha:f.batch.sha,verdict:'changes-requested',summary:'Synthetic findings',findings};
 if(flow!=='review-correction')f.batch.reviews=[{round:1,status:flow==='pr-feedback'?'approved':'changes-requested',subjectSha:f.batch.sha}];
 f.batch.feedbackFingerprint=feedbackFingerprint(await f.github.reviewFeedback(81));
 if(flow==='pr-feedback')f.feedback.comments.push({id:999,author:'maintainer',body:'Actual new correction feedback'});
 if(flow==='external-review-correction'){const raw=JSON.stringify(verdict);f.batch.reviewReports={'claude-review-1.json':raw};f.batch.reviewLedger={rounds:[{round:1,subject_sha:f.batch.sha,verdict:'changes-requested',review_sha256:sha256(raw)}]};f.batch.externalReview={status:'published',subjectSha:f.batch.sha,feedbackFingerprint:f.batch.feedbackFingerprint};}
 await f.handoff.extendBudget(81,{kind:'implementation',limit:5,authorizationRef:'test:unused',reason:'Existing authorized future allowance'});
 let executions=0,injected=false;
 const workspace={root:'/synthetic',prepare:async()=>{},execute:async()=>{executions++;if(outcome==='model')throw Object.assign(new Error('Unconfirmed model outcome'),{code:'model-execution-failed'});return {status:'implemented'};},review:async b=>({...verdict,subject_sha:b.sha}),reviewBody:()=>'',issueEvidence:async()=>''};
 f.github.intake=async()=>{};f.github.discoverQueue=async()=>[];f.github.setIssueStatus=async()=>{};f.github.commentIssue=async()=>{};f.github.commentPR=async()=>{};const view=f.github.viewIssue;f.github.viewIssue=async n=>({...await view(n),labels:['bug','codex-run']});
 const store=f.github.createStateStore(),save=store.save;store.save=async(s,o)=>{if(outcome==='save'&&!injected&&s.batches[0].controllerProgress?.next===1){injected=true;throw Object.assign(new Error('Unknown persistence outcome'),{code:'state-write-uncertain'});}return save(s,o);};
 const invoke=()=>runPipeline({repo,event:{},gh:f.github,workspace,models:{},store,reviewMode:flow==='external-review-correction'?'external':'internal',triageWindowMs:0});
 if(outcome==='save')await assert.rejects(invoke());else await invoke();
 let b=f.remote.batches[0];assert.equal(executions,1);assert.equal(b.controllerProgress.status,'running');assert.equal(b.implementation.length,4);assert.equal(b.implementation[3].status,'running');assert.equal(b.controllerProgress.failedStep,undefined);
 await invoke();b=f.remote.batches[0];assert.equal(executions,1);assert.equal(b.phase,'blocked');assert.equal(b.implementation[3].status,'running');
 await assert.rejects(f.handoff.extendBudget(81,{kind:'implementation',limit:6,authorizationRef:'test:no-repeat',reason:'Cannot replace unknown work'}),/owned attempt/);
 await assert.rejects(f.handoff.recover(81,{action:'resume',expectedSha:b.sha,token:historyDigest({phase:'blocked',failureCode:b.failureCode??null}),reason:'Cannot resume unknown work as failed'}),/allowances/);
 assert.equal(executions,1);
});
