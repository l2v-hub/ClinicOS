import subprocess,os,json,pathlib,sys,time,hashlib
base=pathlib.Path('/tmp/clinicos-autonomy-activation-20261022');out=base/'independent-qa9';label=sys.argv[1];args=sys.argv[2:]
if (out/(label+'.json')).exists() or (out/(label+'.log')).exists():raise RuntimeError('Evidence labels cannot be overwritten')
(out/'owned-tmp').mkdir(exist_ok=True)
env={'PATH':'/usr/bin:/bin','TMPDIR':str(out/'owned-tmp'),'LANG':'C.UTF-8','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_COUNT':'2','GIT_CONFIG_KEY_0':'core.hooksPath','GIT_CONFIG_VALUE_0':'/dev/null','GIT_CONFIG_KEY_1':'protocol.allow','GIT_CONFIG_VALUE_1':'never'}
def snapshot():
 return {str(p.relative_to(base/'qa-source9')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((base/'qa-source9').rglob('*')) if p.is_file() and not p.is_symlink() and not any(x.is_symlink() for x in p.parents if x!=base/'qa-source9')}
source_before=snapshot()
cmd=['/tmp/clinicos-node22-native12/node_modules/node/bin/node',*args];start=time.time()
try:
 r=subprocess.run(cmd,cwd=base/'qa-source9',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240);code=r.returncode;output=r.stdout
except subprocess.TimeoutExpired as e:code='timeout';output=e.stdout or b''
(out/(label+'.log')).write_bytes(output)
result={'command':cmd,'cwd':str(base/'qa-source9'),'environment':env,'exitCode':code,'seconds':time.time()-start,'logSha256':hashlib.sha256(output).hexdigest(),'sourceBefore':source_before,'sourceAfter':snapshot()}
result['sourceUnchangedDuringCommand']=result['sourceBefore']==result['sourceAfter']
(out/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(output.decode(errors='replace')[-4000:]);print('EXIT',code)
