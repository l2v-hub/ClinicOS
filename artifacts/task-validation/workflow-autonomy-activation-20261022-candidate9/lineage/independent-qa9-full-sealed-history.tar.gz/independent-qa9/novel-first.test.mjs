import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {writeFile,readFile,symlink,mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {gitFixture,implementationPlan} from './git-fixture9.mjs';
import {actualPipeline} from './actual-pipeline9.mjs';
import {fixture as releaseFixture} from './release-fixture8.mjs';
import {createWorkspace,runImplementationStages} from '../qa-source9/agent-team/src/bug-pipeline/workspace.mjs';
import {createCommentReviewHandoff} from '../qa-source9/agent-team/src/bug-pipeline/comment-review-handoff.mjs';
import {releaseBatch} from '../qa-source9/agent-team/src/bug-pipeline/release.mjs';
import {historyDigest} from '../qa-source9/agent-team/src/bug-pipeline/attempt-budget.mjs';
import {feedbackFingerprint} from '../qa-source9/agent-team/src/bug-pipeline/contracts.mjs';
import {gitDataStateFixture} from '../qa-source9/agent-team/tests/bug-pipeline/git-data-state-fixture.mjs';
const repo='l2v-hub/ClinicOS',pipeline=await actualPipeline();
const response=(value,extra={})=>({ok:true,code:0,stdout:JSON.stringify(value),stderr:'',...extra});
const git=(cwd,...args)=>{const r=spawnSync('git',args,{cwd,env:process.env,encoding:'utf8'});assert.equal(r.status,0,r.stderr);return r.stdout.trim()};
for(const alteration of ['exact','symlink-output','changed-head','changed-base','changed-branch'])test(`QA9 novel real Git actual pipeline audited retry boundary ${alteration}`,async t=>{
 const {root}=await gitFixture(t),plan=implementationPlan([17]);plan.fileMap=[{issue:17,files:[...plan.scope]}];plan.separationReason='';plan.verification.push({command:'npm',args:['--prefix','frontend','run','build']});
 const b={id:'bug-batch-17',branch:'codex/bug-batch-17',issues:[17],plan,phase:'waiting-review',implementation:[1,2,3].map(round=>({round,status:'passed'})),reviews:[],pr:{number:81,url:`https://github.com/${repo}/pull/81`}};
 const cwd=path.join(root,'agent-team/.worktrees',b.id),file=path.join(cwd,plan.scope[0]);let executions=0;
 const workspace=createWorkspace({root,repo,models:{execute:async()=>{executions++;await writeFile(file,`export const filter = "QA9 own output ${executions}";\n`);return {status:executions===1?'implemented':'blocked',summary:'Synthetic known outcome'};}},run:async call=>{if(call.command==='codex')return {ok:false,code:1,stdout:'# tests 1\n# fail 1\n',stderr:''};assert.equal(call.command,'git','No model or external CLI may run');return {ok:true,code:0,stdout:git(call.cwd,...call.args),stderr:''}}});
 await workspace.prepare(b);b.sha=await workspace.checkpoint(b);await workspace.publish(b);b.reviews=[{round:1,status:'approved',subjectSha:b.sha}];
 const feedback={number:81,url:b.pr.url,state:'OPEN',isDraft:false,head:b.sha,headRef:b.branch,headRepo:repo,headIsFork:false,baseRef:'main',comments:[],unresolved:false,changesRequested:false};b.feedbackFingerprint=feedbackFingerprint(feedback);feedback.comments.push({id:900,body:'Independent fresh feedback'});
 let canonical={schemaVersion:1,repository:repo,batches:[structuredClone(b)]};const store={load:async()=>structuredClone(canonical),observe:async()=>structuredClone(canonical),save:async(s,o)=>{await o?.guard?.();canonical=structuredClone(s)}};
 const github={createStateStore:()=>store,authorized:async()=>true,authorizedMaintainer:async()=>true,reviewFeedback:async()=>structuredClone(feedback),requiredChecks:async()=>({ok:true}),intake:async()=>{},discoverQueue:async()=>[],setIssueStatus:async()=>{},commentIssue:async()=>{},commentPR:async()=>{},viewIssue:async()=>({state:'open',labels:['bug','codex-run']})};
 const invoke=()=>pipeline({repo,event:{},gh:github,models:{},workspace,store,reviewMode:'internal',triageWindowMs:0});
 await invoke();let failed=canonical.batches[0];assert.equal(executions,1);assert.equal(failed.controllerProgress.status,'failed');assert.equal(failed.controllerProgress.failedStep,'verify-before');assert.equal(failed.implementation.at(-1).round,4);assert.equal(failed.implementation.at(-1).status,'failed');assert.match(git(cwd,'status','--porcelain'),/filter.ts/);
 const retained=structuredClone(failed.controllerProgress),oldReviews=structuredClone(failed.reviews);
 const handoff=createCommentReviewHandoff({github,cwd:root,run:async()=>response({login:'qa-maintainer'}),authorizationVerifier:async({binding})=>({provenance:'user-session',grantId:'qa9:retained',sourceRef:'test:isolated',consumptionNonce:`qa9:${alteration}`,binding})});
 await handoff.extendBudget(81,{kind:'implementation',limit:5,authorizationRef:'test:qa9',reason:'One independently tested correction'});
 await handoff.recover(81,{action:'resume',expectedSha:failed.sha,token:historyDigest({phase:'blocked',failureCode:failed.failureCode}),reason:'Exact retained worktree inspected'});
 if(alteration==='symlink-output'){const target=path.join(root,'same-output.ts');await writeFile(target,await readFile(file));await import('node:fs/promises').then(m=>m.rm(file));await symlink(target,file)}
 if(alteration==='changed-head')git(cwd,'commit','--allow-empty','-m','independent changed head');
 if(alteration==='changed-base')canonical.batches[0].baseSha='1'.repeat(40);
 if(alteration==='changed-branch')git(cwd,'branch','-m','independent-other-owner');
 await invoke();const current=canonical.batches[0];assert.deepEqual(current.reviews,oldReviews);assert.equal(current.phase,'blocked');
 if(alteration==='exact'){assert.equal(executions,2);assert.equal(current.implementation.length,5);assert.equal(current.implementation.at(-1).status,'failed');assert.equal(current.controllerProgress.failedStep,'execute');assert.deepEqual(current.controllerProgressHistory,[retained]);assert.equal(current.controllerProgress.implementationRound,5);assert.match(await readFile(file,'utf8'),/output 2/)}
 else{assert.equal(executions,1);assert.equal(current.implementation.length,4);assert.deepEqual(current.controllerProgress,retained);assert.equal(current.controllerProgressHistory,undefined)}
});
for(const field of ['number','url','headRef','headRepo','headIsFork','baseRef'])test(`QA9 novel authoritative merge rejection with wrong ${field} preserves exact reservation`,async()=>{
 const f=releaseFixture(['docs/release.md']);let reservation;
 f.github.mergePullRequest=async(_p,_s,{guard})=>{await guard();reservation=structuredClone(f.getSaved().batches[0].release);f.feedback[field]=field==='number'?991:field==='headIsFork'?true:'foreign-identity';throw Object.assign(new Error('Definite refusal'),{code:'github-write-rejected',operation:'merge',httpStatus:405})};
 await assert.rejects(releaseBatch({repo,github:f.github,store:f.store,batchId:f.batch.id,reviewedSha:f.batch.sha,configured:{botToken:true},execute:true}));
 const current=f.getSaved().batches[0];assert.deepEqual(current.release,reservation);assert.equal(current.mergeHistory,undefined);
});
for(const effect of ['unknown-return','post-invocation-throw','wrapped-guard'])test(`QA9 novel ${effect} cannot release merge tombstone on OPEN observation`,async()=>{
 const f=releaseFixture(['docs/release.md']);let reservation;
 f.github.mergePullRequest=async(_p,_s,{guard})=>{reservation=structuredClone(f.getSaved().batches[0].release);if(effect==='wrapped-guard'){f.feedback.unresolved=true;try{await guard()}catch(error){throw new Error('Wrapped guard uncertainty',{cause:error})}}await guard();if(effect==='post-invocation-throw')throw new Error('Unknown merge outcome');return null};
 await assert.rejects(releaseBatch({repo,github:f.github,store:f.store,batchId:f.batch.id,reviewedSha:f.batch.sha,configured:{botToken:true},execute:true}));assert.deepEqual(f.getSaved().batches[0].release,reservation);assert.equal(f.getSaved().batches[0].mergeHistory,undefined);
});
for(const step of ['execute','verify-before','simplify','verify-after','qa'])test(`QA9 novel arbitrary finite-code throw at ${step} retains running work`,async()=>{
 const batch={plan:{},implementation:[],reviews:[]},counts={execute:0,simplify:0,qa:0};let verifications=0;
 const forged=Object.assign(new Error('Implementation blocked'),{code:step.startsWith('verify')?'implementation-blocked':'workspace-verification-failed'});
 const workspace={execute:async()=>{counts.execute++;if(step==='execute')throw forged;return {status:'implemented'}},verify:async()=>{verifications++;if(step===(verifications===1?'verify-before':'verify-after'))throw forged},simplify:async()=>{counts.simplify++;if(step==='simplify')throw forged;return {status:'implemented'}},qa:async()=>{counts.qa++;throw forged},checkpoint:async()=>assert.fail('Must not checkpoint'),publish:async()=>assert.fail('Must not publish')};
 const invoke=()=>runImplementationStages({batch,workspace,save:async()=>{},context:{phase:'pr-feedback',round:1}});await assert.rejects(invoke());const before={...counts};assert.equal(batch.controllerProgress.status,'running');assert.equal(batch.controllerProgress.failedStep,undefined);await assert.rejects(invoke(),/Unknown implementation outcome/);assert.deepEqual(counts,before);
});
for(const outcome of ['parent-then-late','next-bad-type','different-next'])test(`QA9 novel uncertain Git ref ${outcome} never rebases or retries`,async()=>{
 const f=gitDataStateFixture({schemaVersion:1,repository:repo,batches:[{id:'a'}],payload:'x'.repeat(1024*1024)}),s=await f.store.load(),parent=f.head;let next,reads=0,validators=0;s.batches[0].local=true;
 f.before=req=>{if(req.method==='PATCH'){next=req.body.sha;return response({}, {ok:false,code:1,error:'timeout'})}if(next&&req.path.includes('/git/ref/')){reads++;if(outcome==='next-bad-type')return response({ref:'refs/heads/codex/bug-control',object:{type:'blob',sha:next}});if(outcome==='different-next')f.advance({...f.readState(),remote:'unrelated'})}};
 await assert.rejects(f.store.save(s,{rebaseIndependentSubjects:()=>validators++}),e=>e.code==='state-write-uncertain');assert.equal(reads,1);assert.equal(validators,1);assert.equal(f.calls.filter(c=>c.method==='PATCH').length,1);assert.equal(f.readState().batches[0].local,undefined);
 if(outcome==='parent-then-late'){assert.equal(f.head,parent);f.head=next;assert.equal(f.readState().batches[0].local,true);assert.equal(f.calls.filter(c=>c.method==='PATCH').length,1)}
});
