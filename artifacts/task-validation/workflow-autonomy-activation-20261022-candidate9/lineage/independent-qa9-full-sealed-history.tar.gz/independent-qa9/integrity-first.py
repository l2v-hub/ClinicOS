import pathlib,json,hashlib,subprocess,os
out=pathlib.Path(__file__).parent;root=out.parent;src=root/'qa-source9'
digest=lambda b:hashlib.sha256(b).hexdigest()
binding=lambda p:{'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size}
manifest=json.loads((root/'source9-frozen-snapshot-manifest.json').read_text());actual={n:binding(src/n) for n in manifest};assert actual==manifest
(out/'source-before.json').write_text(json.dumps(actual,indent=2)+'\n')
repo='/workspace/ClinicOS';sha='9d3bc489885cdf5b3363f510fce59c3be7d4a81d';parent='689425d8836f14dfaa1c1cd1642def0cdbf30745';base='2ee298957c3e1733b01a4b4aca4b48b890032f69'
def git(*args):return subprocess.check_output(['git','-C',repo,*args],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1'})
assert git('rev-parse',sha+'^').decode().strip()==parent
mismatch=[]
for n,b in actual.items():
 raw=git('show',sha+':'+n)
 if digest(raw)!=b['sha256']:
  assert n=='scripts/automation/setup-claude-review-windows.ps1' and (src/n).read_bytes().replace(b'\r\n',b'\n')==raw
  mismatch.append({'path':n,'knownUnchangedCRLF':True,'rawGit':{'sha256':digest(raw),'bytes':len(raw)}})
delta=git('diff','--name-only',parent,sha).decode().splitlines();allowed=json.loads((root/'author9/effective-allowlist.json').read_text());assert set(delta)<=set(allowed) and len(delta)==13 and len(allowed)==15
cumulative=[n for n in git('diff','--name-only',base,sha).decode().splitlines() if not n.startswith('artifacts/')];assert len(cumulative)==27
(out/'source-delta.patch').write_bytes(git('diff',parent,sha,'--',*delta))
def tree(c):return {l.split(b'\t',1)[1].decode():l.split(b'\t',1)[0].split()[2].decode() for l in git('ls-tree','-r',c).splitlines()}
old=tree(parent);new=tree(sha);packets={n:h for n,h in old.items() if n.startswith('artifacts/task-validation/workflow-autonomy-activation-20261022')};assert len(packets)==634 and all(new.get(n)==h for n,h in packets.items())
seals=[]
for p in sorted(root.glob('*/seal.json')):
 if p.parent==out:continue
 data=json.loads(p.read_text())
 if 'files' not in data:continue
 count=0
 for n,b in data['files'].items():
  assert binding(p.parent/n)==b,(str(p.parent),n);count+=1
 seals.append({'directory':p.parent.name,'seal':binding(p),'verifiedFiles':count})
assert binding(root/'author9/seal.json')['sha256']=='b53ba18670ca685012c07a59a947b7567a53002b833b440b7851347b7317624a'
assert binding(root/'Luna-diagnostics9/seal.json')['sha256']=='8d1ca950e6938d40fc6940fceba5ffd3b2b2567c055307f7f8312864e96c9f0e'
for generation in [8]:
 oldmanifest=json.loads((root/f'source{generation}-frozen-snapshot-manifest.json').read_text())
 for dirname in [f'source{generation}',f'qa-source{generation}']:assert {n:binding(root/dirname/n) for n in oldmanifest}==oldmanifest
support=json.loads((root/'source7-readonly-test-support-receipt.json').read_text());assert binding(pathlib.Path(support['privateCopy']))=={'bytes':support['bytes'],'sha256':support['sha256']}
record={'sourceSha':sha,'sourceFiles':len(actual),'rawGitExceptions':mismatch,'delta':delta,'effectiveScope':15,'cumulativeCode':27,'oldPackets':len(packets),'allOldPacketBlobsUnchanged':True,'seals':seals,'baseline8Exact':True,'testSupportExact':True,'gitReadOnly':True}
(out/'integrity-before.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({**record,'seals':len(seals)},indent=2))
