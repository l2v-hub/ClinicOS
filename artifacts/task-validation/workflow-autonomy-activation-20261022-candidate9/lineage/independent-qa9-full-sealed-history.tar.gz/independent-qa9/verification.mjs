import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import ts from '/workspace/ClinicOS/node_modules/typescript/lib/typescript.js';
const out=path.dirname(new URL(import.meta.url).pathname),root=path.dirname(out),src=path.join(root,'qa-source9');
const read=p=>fs.readFileSync(p,'utf8'),hash=x=>createHash('sha256').update(x).digest('hex');
function tests(source){const file=ts.createSourceFile('test.mjs',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),out=[];function shape(n){const children=[];ts.forEachChild(n,c=>{children.push(shape(c))});return [n.kind,n.kind!==ts.SyntaxKind.SourceFile&&typeof n.text==='string'?n.text:null,children]};function visit(n){if(ts.isCallExpression(n)&&ts.isIdentifier(n.expression)&&n.expression.text==='test')out.push({name:n.arguments[0].text??n.arguments[0].getText(file),shape:shape(n)});ts.forEachChild(n,visit)}visit(file);return out}
for(const [a,b] of [['causal.test.mjs','causal-source9.test.mjs'],['worktree-causal8.test.mjs','worktree-causal9.test.mjs']])assert.deepEqual(tests(read(`${root}/author9/${a}`)),tests(read(`${root}/author9/${b}`)),'Original causal assertions must remain exact');
const logs=[];
for(const label of ['causal-source8','causal-source9-first','causal-source9-corrected','focused-first','focused-second','actual-correction-flows-first','new-controls','worktree-causal-source8','worktree-causal-source9','integrated-final','private-final']){
 const receipt=JSON.parse(read(`${root}/author9/${label}.json`)),raw=fs.readFileSync(`${root}/author9/${label}.log`);assert.equal(hash(raw),receipt.logSha256);
 logs.push({label,exitCode:receipt.exitCode,logSha256:hash(raw),counts:Object.fromEntries([...raw.toString().matchAll(/^# (tests|pass|fail|skipped|cancelled|todo) (\d+)$/gm)].map(m=>[m[1],Number(m[2])])),failedNames:[...raw.toString().matchAll(/^not ok \d+ - (.*)$/gm)].map(m=>m[1])});
}
const evolution=[];
for(const suite of ['github','release','workspace','pipeline','comment-review-handoff','external-review']){
 const prior=tests(read(`${root}/source8/agent-team/tests/bug-pipeline/${suite}.test.mjs`)),current=tests(read(`${src}/agent-team/tests/bug-pipeline/${suite}.test.mjs`));
 const currentNames=new Map(current.map(x=>[x.name,x])),renames={'Author8 an unknown ref outcome after an actual effect remains fatal and never triggers a second write or owner skip':'Author9 positive exact-next read confirms formerly unknown ref outcomes without another write or owner skip'};
 const changed=[];
 for(const old of prior){const match=currentNames.get(old.name)??currentNames.get(renames[old.name]);assert.ok(match,`Historical test deleted: ${suite} ${old.name}`);if(JSON.stringify(old.shape)!==JSON.stringify(match.shape))changed.push({oldName:old.name,newName:match.name})}
 evolution.push({suite,priorTestCalls:prior.length,currentTestCalls:current.length,noHistoricalTestDeleted:true,changed});
}
fs.writeFileSync(path.join(out,'verification-results.json'),JSON.stringify({sameOriginalCausalAssertions:true,authorLogAuthentication:logs,evolution,review:'Changed legacy assertions limited to intended cache/phase/reconciliation/archive semantics and typed diagnostics; original failure logs retained. Metadata fixture fixes preserve target assertions; correction flow final phase matches actual requested next review.'},null,2)+'\n');
console.log(JSON.stringify({sameOriginalCausalAssertions:true,authenticatedAuthorLogs:logs.length,evolution:evolution.map(x=>({...x,changed:x.changed.map(c=>c.oldName)}))},null,2));
