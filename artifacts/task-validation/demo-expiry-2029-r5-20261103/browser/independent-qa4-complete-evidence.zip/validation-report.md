# Independent QA4 — READY FOR CODEX QA

Actual independent reviewer /root/auth_expiry_final_qa. Frozen source 45b178b7ea93ade254d5cd0ea68340bd09cdd838; tree 5407582c6022c10d4597e94493f71f97b5c7f69a; current-main base6e3d880921653465ca0527b40f9fc09f6486ada2. Dedicated checkout C:/w-rv/auth-expiry-2029-qa3-20261103 was sequentially reassigned clean by root; all new own evidence is under independent-qa4. This scoped Auth QA is not final protected-release/model approval or online restoration.

## Source projection and findings

No current actionable Auth finding was identified. Full base-to-current projection is66 changed Git paths,8 nonartifact Auth paths. All8 Auth blobs are byte-identical to QA3 source9edcc61f, including the repaired actor/distinct-author revocation order, original regression assertions and sparse Windows policy. Entire frontend/backend/Prisma trees are identical to current main and9ed. All other source is inherited from current main, not silently imported as a new Auth implementation. Shared release/authorization/budget/deployment/GitHub/process/main-verifier imports are unchanged from both comparison sources. Complete Git blob/SHA256/size/local-or-sparse identity inventory and these assertions are in execution-evidence.json.

Main6e3d includes the externally promoted PR527 technical work. Source inheritance is not a claim that its missing genuine technical review, Linux/container/native runtime qualification, activation or release authority exists. None transfers through this Auth verdict. Existing finite Auth gates and genuine Max round3/final-QA requirements remain mandatory. Historical packet reports referencing D2/f583/9ed are historical, not falsely current execution evidence.

## All fresh QA phases

| Phase | Actual independent result |
|---|---|
| Contract | Full frozen118-line current contract reread; AC1–AC7 code/security boundaries reviewed; AC8/AC9 online acceptance pending |
| Diff/source |66-path immutable manifest;8 Auth blobs equal9ed; unchanged app/schema/production/ordinary helper/config/lock |
| Focused tests |158/158 PASS,0 fail/skip/cancel at45b |
| Parent/pure-policy |13/13 PASS using actual newly built backend modules and captured real parent record shape |
| Original revocation repro |1/1 PASS, unchanged assertion, zero mock provider writes |
| Build/typecheck |Actual root production frontend/backend build, Prisma generation and PDF-font packaging PASS; separate frontend tsc --noEmit PASS |
| Synthetic actual App |34/34 PASS at1280/390 with2029 five-profile availability after reload; outbound0/clinicalWrites0 |
| Native Windows reconciliation |Exact45b hosted original command10/10 PASS,0 failed/cancelled/skipped; QA3 local full/sparse9/1 preserved, not called a local pass |
| Security |No actionable new Auth finding; explicit fixed target/capability/source/race/uncertainty/secret/PHI checks below |

All fresh reviewer executions use trusted D2 createRunner verification mode, stripped inherited provider/controller credentials and identical clean HEAD/tree/index before/after. Private fixtures differ from QA3 only by frozen SHA/private output paths; assertions are unchanged. Existing pinned npm ci --ignore-scripts dependencies are reused only after explicit handoff; exact lock and parent install receipt/log hashes are verified, not mislabeled as a fresh independent reinstall. The private build entry explicitly applies intended NODE_ENV=production/fixed public-demo API inside the already credential-free child, with a dummy loopback database URL. Ignored per-call env overrides are not claimed effective. No DB connection, migration, seed, DB suite or real Railpack deployment is claimed. Nonfatal chunk/plugin timing warnings are retained.

## Actual hosted versus local native result

Read-only GitHub connector retrieval independently binds run41713328027, attempt1, repository l2v-hub/ClinicOS, trusted bug-pipeline-tests workflow and head45b178b7. Job126186786689 windows-review-setup is completed SUCCESS. Its actual log contains the exact checkout SHA and unchanged node --test agent-team/tests/bug-pipeline/windows-review.test.mjs command, all10 original test names, tests10/pass10/fail0/cancelled0/skipped0/todo0. The bootstrap dirty/foreign/wrong-branch/diverged/fast-forward case is genuinely ok8 in that hosted run; none was skipped. Sanitized metadata/counts/names are saved in hosted-windows-readonly.json, with raw decoded log SHA256 e15ba3703691f97fe2e8cacfb824959330bb2374654460ee19337dcd60aac2c1. Raw logs were read in memory only, not printed/persisted. At this retrieval the broader Linux workflow was still in progress; no all-CI-green claim is made.

The original QA3 required-command executions remain9PASS/1FAIL/0skip in BOTH full and three-directory sparse checkouts at9ed. Both failed the same unchanged dirty-bootstrap expected-reason assertion at windows-review.test.mjs:434. Source/test imports were D2-identical; no fixture omission was found. Those failures, diagnostic-only null-dereference/GetBytes defects and corrected immediate snapshot (null top/native exit, PS5.1, ConsoleCP65001/OutputCP20127) remain preserved in their original immutable private reports/logs. Hosted exact-source success reconciles the current required native Windows check; it does not repair this machine, prove a specific host root cause, rewrite QA3 BLOCKED or fabricate a local10/10 execution. The pinned checkout,10-minute deadline, command, original tests and strict downstream Windows-success prerequisite remain unchanged. This scheduler Windows check is not technical PR527 native-container qualification.

## Auth/security boundaries

The sole action/key/value is enable-demo-auth-2029 / DEMO_AUTH_EXPIRES_AT /2029-12-31T23:59:59Z, fixed dedicated synthetic demo, skipDeploys=true. No arbitrary date/key/target/allowLong, permanent flag, production credential, SQL, new dependency, PHI fixture or secret-bearing log is added. The ordinary seven-day module, production/exact-deploy workflows, Railway config/ignore and package manifests/lock remain unchanged. Dockerignore excludes generated/evidence archives, not source, migrations, build inputs or fonts; structural tests and actual local build pass.

Tests and static review retain exact actual user-session capability/source/owner/review/history/prior-stage bindings, rejection of old/comment-only/copied/replayed capabilities, merged reviewed source/main checks and distinct-author/actor revocation after awaited reads. Final canonical owner/claim/prior-history observation, finite cutoff, fresh exact target/old public cutoff/failed-source fingerprint, one CAS claim/durable intent/fixed upsert and conservative uncertain-write no-retry remain intact. Actor and distinct-author regressions and permission-await ownership/execution/prior-stage races execute again; no assertion is waived. Finite whitelisted receipts reject arbitrary provider/error fields and credential reflection. No real capability/provider write was exercised.

Captured actual parent523 remains Nov9 STAGED in41524928481; its exact D2 deploy41527190689 subsequently failed. A separately synthetic capability is tested against that captured record shape without parent rewrite; five history/auth/run/source drift denials pass. This is compatibility evidence, not fresh authenticated Railway FAILED metadata. Root's prior production-token read-only denial remains preserved and that operational qualification is still pending. Actual built pure policy permits future2029 only with explicit synthetic/demo opt-ins, retains five server-owned roles and rejects production/missing opt-in/wrong dataset/expired/malformed inputs. No session is provisioned; RBAC/session TTL is unchanged.

## Fresh browser evidence

The actual fresh production App is run via strict loopback5317 and an unchanged private D2-harness adaptation. All non-loopback requests are intercepted; positive future2029 cases assert exact public-demo API origin, five visible profiles after reload, no legacy picker, no actual session POST, no relevant failed HTTP/console errors and no overflow. Original negative/legacy/Entra/late-expiry/error cases preserve expected synthetic failures. Every case asserts no unexpected request/page error, outbound0/clinicalWrites0. Both new desktop/mobile screenshots were visually inspected.34 trace ZIPs,34 WebM videos,12 screenshots and browser.json are sealed; browser/playwright-report/index.html is a custom index of the actual Playwright API output, not an invented official reporter. Port5317 was verified unused before strict binding and available after cleanup. No shared DB/server, patient read or clinical write occurred.

Actual evidence paths: browser/future-2029-1280.png and future-2029-390.png; corresponding -trace.zip files; per-case WebM video directories; browser/browser.json; browser/playwright-report/index.html. Complete receipts/logs/digests and original history report hashes are in execution-evidence.json. Four harmless blank-EOF diagnostics remain in git diff --check (exit2), not described as green; no source edit hides them.

## Remaining gates

QA Gate and its linked evidence/run guidance were fully reread and drove the fresh build/typecheck/security/browser bundle and honest hosted/local reconciliation. Higher-priority scope leaves publication/canonical/provider operations to root, so this reviewer writes only new private evidence. No source edit/commit, push, GitHub/canonical mutation, model/provider call, actual stage/deploy, SQL, real session/clinical access or issue closure occurred. QA1 BLOCKED, QA2 and QA3 BLOCKED artifacts are hash-verified unchanged; no old approval transfers.

Same unpublished fifth Auth implementation, all old attempt/review budgets, old permanent candidate and separate technical history remain intact. Actual all-required exact published-head CI, genuine existing-route Claude Max round3, final independent Codex QA, fresh authenticated failed-deployment qualification and separately authorized stage/deploy remain mandatory. Actual online current source/ready/demo/simulator/temporary/synthetic flags, exact2029 expiry and five-profile desktop/mobile reload acceptance remain pending. Issue must stay open/unverified. No technical527 approval or native activation/qualification is implied.

Final scoped verdict READY FOR CODEX QA; findings[]. Not release-ready, model-approved, deployed or online verified.
