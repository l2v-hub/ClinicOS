import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import * as api from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/scripts/automation/enable-demo-auth-2029.mjs';
import { DEMO_TARGET } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/agent-team/src/bug-pipeline/demo-deployment.mjs';

const selector = { subjectId: 'standalone-pr-525', operationNonce: '11111111-1111-4111-8111-111111111111', reviewedSha: 'a'.repeat(40) };
const activeId = 'a93cffdf-fd91-4a75-bc0d-a97154e0d888', activeSha = 'c'.repeat(40);
const failedId = 'f04e215c-2105-45ca-9b9f-766eabbff925', failedSha = 'd2a08b4850dd954bb790e35f2ed350d5eeacd1c4';
const expiry = '2026-10-31T23:59:59Z', now = () => Date.parse('2026-11-03T18:00:00Z');
const failureQuery = 'query($id:String!){deployment(id:$id){id status projectId environmentId serviceId meta}}';
function fixture() {
  const target = { projectToken: { project: { id: DEMO_TARGET.projectId }, environment: { id: DEMO_TARGET.environmentId, name: 'demo' } },
    deploymentTriggers: { pageInfo: { hasNextPage: false }, edges: [] }, deployments: { pageInfo: { hasNextPage: false }, edges: [] },
    serviceInstance: { serviceId: DEMO_TARGET.serviceId, environmentId: DEMO_TARGET.environmentId, source: { repo: 'l2v-hub/ClinicOS' },
      domains: { serviceDomains: [{ domain: DEMO_TARGET.domain }], customDomains: [] },
      activeDeployments: [{ id: activeId, status: 'SUCCESS', meta: { commitHash: activeSha, arbitraryPrivateField: 'must-not-appear' } }],
      latestDeployment: { id: failedId, status: 'FAILED' } } };
  const failure = { deployment: { id: failedId, status: 'FAILED', projectId: DEMO_TARGET.projectId,
    environmentId: DEMO_TARGET.environmentId, serviceId: DEMO_TARGET.serviceId, meta: { commitHash: failedSha, privateField: 'must-not-appear' } } };
  const status = { mode: 'disabled', simulator: false, temporaryDemo: false, syntheticOnly: true, expiresAt: expiry };
  const ready = { status: 'ready', tier: 'demo', deploymentId: activeId, checks: { database: 'ok', policy: 'ok' } };
  const calls = [], checkpoints = [];
  return { target, failure, status, ready, calls, checkpoints, options: { selector, now,
    assertFreshMain: async () => { checkpoints.push('main'); },
    client: async (query, variables) => { assert.ok(query.startsWith('query')); calls.push({ query, variables });
      if (calls.length === 1) { assert.deepEqual(variables, DEMO_TARGET); return target; }
      assert.equal(calls.length, 2); assert.equal(query, failureQuery); assert.deepEqual(variables, { id: failedId }); return failure; },
    readPublic: async url => { assert.ok([`https://${DEMO_TARGET.domain}/auth/status`, `https://${DEMO_TARGET.domain}/ready`].includes(url));
      checkpoints.push(url); return url.endsWith('/ready') ? ready : status; } } };
}

export {fixture,api,selector,activeId,activeSha,failedId,failedSha};
