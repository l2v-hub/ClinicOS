import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { captureReleaseReviewProof } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/agent-team/src/bug-pipeline/release.mjs';
import { authorizationBinding } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/agent-team/src/bug-pipeline/operator-authorization.mjs';
import { historyDigest } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/agent-team/src/bug-pipeline/attempt-budget.mjs';
import { DEMO_TARGET } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/agent-team/src/bug-pipeline/demo-deployment.mjs';
import { MAX_RENEWAL_MS, validateRenewalRequest } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/scripts/automation/renew-demo-auth-expiry.mjs';
import { createDemo2029Controller, validateDemo2029Request, EXPIRY_2029, KEY, ACTION } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/scripts/automation/demo-2029-controller.mjs';
import { DEMO_2029_MUTATION, inspectDemo2029Target, stageDemo2029, runDemo2029Operation,
  serializeDemo2029Receipt, validateDemo2029Context } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/scripts/automation/enable-demo-auth-2029.mjs';
const clone = structuredClone, now = Date.parse('2026-11-03T18:00:00Z');
const selector = { subjectId: 'standalone-pr-525', operationNonce: '11111111-1111-4111-8111-111111111111', reviewedSha: 'a'.repeat(40) };
const request = { ...selector, owner: 'root-fixture', ownerNonce: '22222222-2222-4222-8222-222222222222',
  activeDeploymentId: 'a93cffdf-fd91-4a75-bc0d-a97154e0d888', activeSourceSha: 'c'.repeat(40),
  previousExpiry: '2026-10-31T23:59:59Z', failedDeploymentId: 'f04e215c-2105-45ca-9b9f-766eabbff925', failedSourceSha: 'e'.repeat(40) };
const fingerprint = 'd'.repeat(64), fresh = async () => ({ fingerprint });
function fixture() {
  const report = JSON.stringify({ subject_sha: 'b'.repeat(40), verdict: 'approved', summary: 'Synthetic fixture only', findings: [] });
  const child = { id: selector.subjectId, pr: { number: 525, url: 'https://github.com/l2v-hub/ClinicOS/pull/525' }, issues: [524],
    sha: 'b'.repeat(40), branch: 'codex/2029-fixture', phase: 'ready', approvedSha: 'b'.repeat(40), implementation: [],
    reviews: [{}, {}, { round: 3, status: 'approved', subjectSha: 'b'.repeat(40) }], recoveryHistory: [],
    reviewLedger: { rounds: [{}, {}, { round: 3, verdict: 'approved', subject_sha: 'b'.repeat(40), review_sha256: historyDigest(JSON.parse(report)) }] },
    reviewReports: { 'claude-review-3.json': report }, feedbackFingerprint: 'same-fixture',
    codexFinalReview: { status: 'verified', subjectSha: 'b'.repeat(40), claudeRound: 3, feedbackFingerprint: 'same-fixture' },
    externalReview: { status: 'published', subjectSha: 'b'.repeat(40), feedbackFingerprint: 'same-fixture', feedbackChanged: false },
    parentSource: { parent: { id: 'standalone-pr-523', mergeSha: 'e'.repeat(40) } },
    operatorCoordination: { active: true, owner: request.owner, nonce: request.ownerNonce },
    release: { status: 'merged', reviewedSha: 'b'.repeat(40), prNumber: 525, mergeSha: selector.reviewedSha,
      sourceTreeProof: { sourceEquivalent: true, reviewedSha: 'b'.repeat(40), mergeSha: selector.reviewedSha, reviewedTree: 'f'.repeat(40), mergeTree: 'f'.repeat(40) } },
    demoAuth2029Stages: [clone(request)] };
  child.release.reviewProof = captureReleaseReviewProof(child, { repository: 'l2v-hub/ClinicOS', collection: 'standaloneReviews' });
  const old = { subjectId: 'standalone-pr-523', operationNonce: '66666666-6666-4666-8666-666666666666', reviewedSha: request.failedSourceSha,
    previousExpiry: request.previousExpiry, newExpiry: '2026-11-09T18:00:00Z', owner: 'old-root', ownerNonce: '77777777-7777-4777-8777-777777777777' };
  const parent = { id: old.subjectId, pr: { number: 523 }, issues: [522], sha: '0'.repeat(40), implementation: [], reviews: [], recoveryHistory: [], demoAuthExpiryRenewals: [old] };
  let remote = { repository: 'l2v-hub/ClinicOS', batches: [], manualBatches: [], standaloneReviews: [child, parent] };
  const binding = authorizationBinding({ state: remote, subject: parent, actor: 'old-root', action: 'renew-demo-auth-expiry', budget: null,
    reservation: { ...old, target: DEMO_TARGET, key: KEY, skipDeploys: true } });
  const auth = { provenance: 'user-session', grantId: 'old-stage-grant', consumptionNonce: 'old-consumption', sourceRef: 'user-session:old-stage', binding, bindingDigest: historyDigest(binding) };
  old.authorization = { authorization: auth, authorizedAt: '2026-11-02T18:00:00.000Z', historyBeforeLength: 0, historyBeforeDigest: historyDigest([]), auditNonce: 'old-audit' };
  parent.recoveryHistory = [{ action: 'renew-demo-auth-expiry', nonce: 'old-audit', authorization: clone(auth) }];
  old.execution = { status: 'staged', runId: '41524928481' };
  const dispatch = { phase: 'observed', operation: 'deploy', sha: old.reviewedSha, dispatchId: '44444444-4444-4444-8444-444444444444', runId: 41527190689 };
  const deployBinding = authorizationBinding({ state: remote, subject: parent, actor: 'old-root', action: 'protected-demo-deploy', budget: null,
    reservation: { operation: 'deploy', sourceSha: old.reviewedSha, target: DEMO_TARGET, key: KEY, newExpiry: old.newExpiry,
      stageRunId: Number(old.execution.runId), operationNonce: old.operationNonce, dispatchId: dispatch.dispatchId,
      stageReceiptSha256: '8'.repeat(64), stageArtifactDigest: 'sha256:' + '9'.repeat(64), stageArtifactId: 123, operatorSQLCleanup: false, issueClosure: false } });
  dispatch.operatorAuthorization = { provenance: 'user-session', grantId: 'old-deploy-grant', consumptionNonce: 'old-deploy-consumption',
    sourceRef: 'user-session:old-deploy', binding: deployBinding, bindingDigest: historyDigest(deployBinding) };
  dispatch.stageProofDigest = '7'.repeat(64); parent.exactDemoDispatches = { deploy: dispatch };
  let revision = 0, loadedRevision, revoked = false, permission = () => {}, sourceCheck = () => {}, main = selector.reviewedSha, clock = now;
  let provenance = 'user-session', consumption = 'new-2029-consumption', runHook = x => x;
  const store = { load: async () => { loadedRevision = revision; return clone(remote); }, observe: async () => clone(remote),
    save: async (s, { guard }) => { const expected = loadedRevision; await guard(); assert.equal(revision, expected, 'CAS conflict'); remote = clone(s); revision++; loadedRevision = revision; } };
  const github = { createStateStore: () => store, authorizedMaintainer: async () => { permission(remote); return !revoked; },
    reviewFeedback: async () => { sourceCheck(remote); const b = remote.standaloneReviews[0]; return { number: 525, state: 'MERGED', url: b.pr.url,
      head: b.sha, headRef: b.branch, headRepo: 'l2v-hub/ClinicOS', headIsFork: false, baseRef: 'main', mergeCommitSha: b.release.mergeSha }; } };
  const verifier = async ({ binding, consume }) => { assert.equal(consume, true); return { provenance, grantId: 'actual-2029-fixture',
    consumptionNonce: consumption, sourceRef: 'user-session:fixed-2029', binding }; };
  const dependencies = { github, now: () => clock,
    assertCurrentMain: async expected => assert.equal(main, expected), nonce: () => '33333333-3333-4333-8333-333333333333',
    readRun: async id => runHook({ id, run_attempt: 1, status: 'completed', conclusion: 'failure', head_sha: request.failedSourceSha,
      repository: { full_name: 'l2v-hub/ClinicOS' }, head_repository: { full_name: 'l2v-hub/ClinicOS' },
      path: '.github/workflows/deploy-demo-exact-commit.yml', event: 'workflow_dispatch', head_branch: 'main',
      display_title: `demo-exact deploy ${request.failedSourceSha} ${dispatch.dispatchId}` }) };
  const controller = createDemo2029Controller({ ...dependencies, authorizationVerifier: verifier });
  return { controller, github, state: () => remote, record: () => remote.standaloneReviews[0].demoAuth2029Stages[0],
    old: () => remote.standaloneReviews[1], mutate: fn => fn(remote), writes: () => revision,
    permission: fn => { permission = fn; }, sourceCheck: fn => { sourceCheck = fn; }, revoke: () => { revoked = true; },
    dependencies, setClock: v => { clock = v; }, setMain: v => { main = v; }, setProvenance: v => { provenance = v; }, setConsumption: v => { consumption = v; }, run: fn => { runHook = fn; } };
}
const authorized = f => f.controller.authorize(selector, { actor: 'root-fixture', reference: 'user-session:fixed-2029' });
const claimed = async f => { await authorized(f); return f.controller.claim(selector, { actor: 'worker-fixture', runId: '77', fingerprint, fresh }); };
function targetData() { return { projectToken: { project: { id: DEMO_TARGET.projectId }, environment: { id: DEMO_TARGET.environmentId, name: 'demo' } },
  deploymentTriggers: { pageInfo: { hasNextPage: false }, edges: [] }, deployments: { pageInfo: { hasNextPage: false }, edges: [] },
  serviceInstance: { serviceId: DEMO_TARGET.serviceId, environmentId: DEMO_TARGET.environmentId, source: { repo: 'l2v-hub/ClinicOS' },
    domains: { serviceDomains: [{ domain: DEMO_TARGET.domain }], customDomains: [] },
    activeDeployments: [{ id: request.activeDeploymentId, status: 'SUCCESS', meta: { commitHash: request.activeSourceSha } }],
    latestDeployment: { id: request.failedDeploymentId, status: 'FAILED' } },
  deployment: { id: request.failedDeploymentId, status: 'FAILED', projectId: DEMO_TARGET.projectId,
    environmentId: DEMO_TARGET.environmentId, serviceId: DEMO_TARGET.serviceId, meta: { commitHash: request.failedSourceSha } } }; }
const publicData = url => url.endsWith('/ready') ? { status: 'ready', tier: 'demo', deploymentId: request.activeDeploymentId,
  checks: { database: 'ok', policy: 'ok' } } : { mode: 'disabled', simulator: false, temporaryDemo: false, syntheticOnly: true, expiresAt: request.previousExpiry + '' };


export { fixture, selector, request, authorized, fresh };
