import assert from 'node:assert/strict';
import {mkdir,writeFile,lstat} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createRunner} from 'file:///C:/w-rv/auth-release-main20261102/agent-team/src/bug-pipeline/process.mjs';
const cwd='C:/w-rv/auth-expiry-2029-qa3-20261103',dir='C:/w-rv/tmp/auth-expiry-2029-20261103/independent-qa5',source='0052ad4780998772ded9c6cde9e52b7400f845cf';
const [label,...args]=process.argv.slice(2);assert.match(label??'',/^[a-z0-9-]+$/);assert.ok(args.length);
const hash=x=>createHash('sha256').update(x).digest('hex'),git=(...a)=>execFileSync('git',a,{cwd,encoding:'utf8',windowsHide:true,maxBuffer:8*1024*1024}).trim();
const identity=()=>{assert.equal(git('rev-parse','HEAD'),source);assert.equal(git('status','--porcelain=v1'),'');return {sourceSha:source,tree:git('rev-parse','HEAD^{tree}'),indexSha256:hash(git('ls-files','--stage'))};};const before=identity();
if(args[0]==='--test')for(const f of args.slice(1)){assert.ok(f.endsWith('.test.mjs')&&!f.includes('*'));assert.equal((await lstat(f.includes(':')?f:cwd+'/'+f)).isFile(),true);}
const out=dir+'/'+label;await mkdir(out,{recursive:false});const startedAt=new Date().toISOString(),run=createRunner({runtimeRoot:out+'/runtime'});
const result=await run({command:process.execPath,args,cwd,envMode:'verification',timeoutMs:15*60*1000,maxOutputBytes:8*1024*1024});const after=identity();assert.deepEqual(after,before);
await writeFile(out+'/stdout.log',result.stdout??'',{flag:'wx'});await writeFile(out+'/stderr.log',result.stderr??'',{flag:'wx'});
const receipt={independent:true,reviewer:'auth_expiry_final_qa',label,cwd,before,after,sourceStable:true,startedAt,finishedAt:new Date().toISOString(),args,envMode:'verification',credentialsInherited:false,realProviderInvoked:false,ok:result.ok,exitCode:result.code,error:result.error??null,stdoutSha256:hash(result.stdout??''),stderrSha256:hash(result.stderr??'')};
await writeFile(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(receipt));console.log((result.stdout??'').slice(-2500));if(!result.ok){console.log((result.stderr??'').slice(-3000));process.exitCode=1;}
