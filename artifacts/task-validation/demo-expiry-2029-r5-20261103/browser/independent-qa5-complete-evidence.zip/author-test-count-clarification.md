# Additive test-count clarification

This corrects the decomposition in the preserved author report/evidence; it does not replace, normalize, or overwrite those files, source commits, logs, receipts or hashes.

On unchanged frozen source `0052ad4780998772ded9c6cde9e52b7400f845cf` / tree `081a71c9fee82b79b1191d257d2788c0379da584`, two fresh exact-source/index-stable executions with credential-stripped trusted verification runner demonstrate:

- `node --test scripts/automation/enable-demo-auth-2029.metadata.test.mjs`: **57 tests, 57 PASS, 0 FAIL, 0 SKIP**. Files: `metadata-only-count-clarification/{stdout.log,stderr.log,receipt.json}`. Receipt SHA256 `6f1f477e486fc45f5f9ea42f5a5518c028dfd83afbc7f74508c054a7c9ca582b`.
- `node --test scripts/automation/enable-demo-auth-2029.test.mjs scripts/automation/renew-demo-auth-expiry.test.mjs`: **155 tests, 155 PASS, 0 FAIL, 0 SKIP**. Files: `original-only-count-clarification/{stdout.log,stderr.log,receipt.json}`. Receipt SHA256 `1333646adf06325fa5c22d7224a55708798376e36f87a63f5398e0b6d4599d49`.

Thus the actual final full run's **212 PASS =155 original +57 new**, not156 original +56 new. The total212 and the actual RED run's156 PASS /56 FAIL remain correct.

Why the original inference was wrong: RED2631's new CLI ordering test initially asserted only `branchIndex < stateClientIndex`. With the branch missing, `-1 < stateClientIndex` falsely passed. Its actual passing line remains in the RED stdout. That means RED156 PASS consisted of155 original tests plus **one false-positive new assertion**, while the other56 new tests failed. Final commit0052 explicitly requires `branch >=0` and `stateClient > branch`, fixing that weakness; no assertion was disabled. Initial GREEN9ada still had the weaker assertion, and that historical result is retained as such. The final frozen code and final212 run include the stronger assertion.

Preserved originals remain byte-identical:

- author-report.md SHA256 `907e9c9a2d7b54d6bb3f58f199e2db831a79ccb331f78478ebeacb29c803d012`.
- author-evidence.json SHA256 `d3ad9f2aa001e238df01409738224e910d666204355b92c0fef820d14d592a44`.

No tracked source edits, extra implementation, model/provider call, canonical/GitHub write, push or release occurred. This remains author evidence, not independent QA or an online verification claim.
