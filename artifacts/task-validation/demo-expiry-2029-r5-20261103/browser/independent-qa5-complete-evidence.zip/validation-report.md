# Independent QA5 — READY FOR CODEX QA

Actual independent reviewer /root/auth_expiry_final_qa. Frozen local source 0052ad4780998772ded9c6cde9e52b7400f845cf; tree 081a71c9fee82b79b1191d257d2788c0379da584; base6e3d880921653465ca0527b40f9fc09f6486ada2. Full/App checkout C:/w-rv/auth-expiry-2029-qa3-20261103; separate protected cone-sparse checkout C:/w-rv/auth-expiry-2029-qa5-protected-sparse-20261103. Both clean and source/index stable. All new own files are private under independent-qa5. This is not post-Claude approval, provider qualification, publication, protected release or online restoration.

## Findings, contract and projection

No actionable current defect was found within this independently executed gate. Actual issue524, its comments (none), PR525 and its four returned comments were read as untrusted task data. The issue body still has older permanent-demo language; the actual user request, complete118-line frozen current contract and PR finite2029 update supersede it. Remote PR head remains0f02f9cc25f14996891e162cabe2789ee89dafed;0052 is local/unadopted/unpublished at handoff, not falsely called the remote reviewed/CI head. The read-only snapshot is remote-task-readonly.json.

Full current-main projection:72 changed Git paths,9 nonartifact Auth paths, all blobs/bytes/SHA256 and materialization flags sealed. Since remote0f02 exactly four nonartifact paths change: helper, new metadata test, protected2029 workflow and bug CI. Controller, original dedicated tests (including actual actor/distinct-author revocation assertions), ordinary seven-day helper/tests, build-context test, Dockerignore, frontend/backend/Prisma, configs, production/exact-deploy workflows, package manifests/lock and all shared agent-team source remain unchanged. Original inspectDemo2029Target and stageDemo2029 function bodies are independently compared byte-for-byte, not inferred from an author claim. No inherited technical PR527 approval or native-profile qualification/activation transfers through main6e3d or this Auth gate.

## Actual command counts — no expected-number substitution

| Fresh execution | Actual result |
|---|---|
| Exact protected workflow TWO files, in exact three-directory sparse checkout |141/141 PASS =84 dedicated +57 metadata |
| Extra author-parity THREE files, same sparse checkout, additionally selecting ordinary renew suite |212/212 PASS =84+57+71 |
| Full FOUR focused suites, additionally build-context tests |215/215 PASS =84+57+71+3 |
| Isolated metadata file |57/57 PASS |
| Isolated original dedicated + ordinary files |155/155 PASS =84+71 |
| Private adversarial metadata/body-parity checks |5/5 PASS |
| Captured actual parent shape / actual built pure policy |13/13 PASS |
| Unchanged original revocation assertion |1/1 PASS, zero mocked provider writes |
| Root production build / frontend tsc --noEmit |PASS / PASS |
| Fresh actual production-App synthetic cases1280/390 |34/34 PASS |
| Separate generated metadata result surface with reload |1/1 PASS |

All listed tests have zero failed/skipped/cancelled assertions. The root handoff initially expected212 from the protected TWO-file command; this reviewer immediately reported actual141, and root acknowledged the arithmetic error. Ordinary71 was never selected by the protected command before or after this change; there is no missing fixture/test assertion or new skip. The separate extra THREE-file run demonstrates212 with that ordinary file explicitly selected. Do not rename it the protected workflow command. Actual original logs and exact arguments are sealed individually.

## Preserved author RED / count correction

Author report907e9c9a and evidence d3ad9f2a remain byte-identical even though their decomposition156 original/56 new is wrong. The actual RED2631 total212 had156 PASS/56 FAIL:155 original cases plus one false-positive new CLI test passed. The missing branch index was -1, and the then-only -1 < stateClientIndex assertion erroneously succeeded. Initial GREEN9ada retained that weak assertion; it is preserved as such. FINAL0052 explicitly requires branch >=0 and stateClient > branch. Private checks independently reject the old missing-branch case and confirm original stage/inspect/body and revocation assertions are unchanged. No assertion was disabled.

The complete additive clarification is copied byte-for-byte as author-test-count-clarification.md, SHA256696d4dbc06696c4ed8d6d7b21edd1311cd03a510440182a9dc8a295854368861. Its independent decomposition57 new +155 original is verified by this reviewer's new isolated executions, not merely accepted. All original RED/initial GREEN/final GREEN/clarification receipts/stdout/stderr hashes are verified and referenced in execution-evidence.json. Historical contract-validator path/materialization failure in the author report is retained, not relabeled a passed check.

## Metadata read-only security and operational gap

readDemo2029Metadata obtains the actual active source from the inspected response, not a guessed SHA/main/failed source or deployment ID. It requires exact fixed target/domain/repo/token-demo environment, complete idle inventory, one SUCCESS active ID with valid40-hex SHA distinct from candidate/failed source, the fixed f04e215c FAILED deployment and D2 source on the same target, old October31 expired synthetic disabled status and healthy matching demo ready metadata. Four awaited reads each have current-main checks before and after (eight fences). It uses only the fixed two public URLs and fixed GraphQL query/target; no variable inventory or raw meta is returned. Existing provider transport bounds1MiB and fixed public reader16KiB/20s/redirect-deny remain; receipts are finite8192-byte whitelists with normalized credential-reflection rejection. Errors collapse to DEMO2029_METADATA_REJECTED, not raw provider/error data.

The dispatcher selects metadata without touching throwing controller/inspect/progress/state getters; CLI branches before creating GitHub/state/controller clients. Private adversarial tests use two distinct mock active SHAs and observe exact returned values, zero state-getter accesses, zero mutation queries, two query calls and eight main fences. Final-main rejection, raw-meta/credential alias refusal and stronger CLI-branch existence assertion all pass. The public metadata function is read-only evidence, not an action capability, authorization receipt, claim or stage. Existing real actual user-session capability/release/main/revocation/CAS/intent/final-owner fences and single fixed2029 upsert remain necessary for staging.

Protected workflow adds metadata choice but retains default inspect, exact main/workflow/source/actor/first-attempt guards, pinned actions, protected dedicated DEMO secret/environment, shared railway-demo queue and10-minute deadline. Exact checkout sparse inputs agent-team/scripts/.github plus cone root files are actually reproduced; exact TWO-file built-in suite runs before secrets and has no missing imports/fixtures. Root manifests are byte-verified; Git packet remains present but skip-worktree/unmaterialized, not absent evidence. Bug CI adds the metadata file without removing existing selectors. No normal stage authority or production flag is broadened.

Root's operational-map.md was read fully: original exact preflight read active metadata internally but discarded it from its receipt, so it could not furnish the unknown active SHA for honest new request registration. This new route addresses that source-level gap, not the actual online gap. Only after genuine Max3/finalQA/protected merge and root's separate authority may the protected DEMO workflow obtain real bounded metadata; this reviewer did not dispatch it or contact Railway. Real active SHA/fixed failed metadata, canonical registration, fresh capability, stage, exact deploy and online acceptance remain pending. Prior token read denial is not target qualification and is not proof the protected secret is invalid. Do not guess or reuse the failed source as active source.

## Fresh build, policy and browser proof

All reviewer executions use trusted D2 createRunner verification mode, stripped inherited credentials, existing exact pinned lock and clean HEAD/tree/index before/after. Parent npm ci --ignore-scripts receipt/lock/stdout/stderr are reverified; no new installation is claimed. The private build entry explicitly sets production/public-demo API inside the credential-free child rather than rely on ignored per-call env, and uses a dummy loopback DB URL. Actual frontend/backend build, Prisma generation and packaged PDF-font copy ran; no DB connection, migration, seed, DB suite or real Railpack deployment is claimed. Nonfatal build chunk/timing warnings and harmless existing blank-EOF diff-check diagnostics (exit2) remain disclosed.

The13-test suite loads the captured actual parent523 shape: Nov9 STAGED in41524928481, later exact D2 deploy41527190689 failed. It tests separately synthetic new capability compatibility and five history/auth/run/source drift denials without parent rewrite. Actual built pure policy accepts finite2029 only with demo/synthetic opt-ins, keeps five server-owned roles and rejects production/missing opt-in/wrong dataset/expired/malformed values without issuing sessions. Parent acknowledged stage is not active runtime or deployment; old public October31 and staged Nov9 are not conflated.

Fresh actual production-App browser evidence runs the same34 cases at1280/390 with all non-loopback traffic intercepted. Future2029 assertions verify five visible profiles after reload, exact public-demo API origin, no legacy picker, no actual session POST, no console/relevant HTTP errors or overflow. Negative legacy/Entra/expiry/error scenarios keep expected synthetic failures. Every case has outbound0/clinicalWrites0 and no unexpected request/page errors. New desktop/mobile screenshots are visually inspected;34 traces,34 WebM videos,12 screenshots, browser.json and custom actual-output HTML index are hashed. Port5317 was verified unused, strictly bound and closed afterwards; no shared DB/stack was started.

The new internal feature has an additional safe generated-file surface, metadata-surface/index.html: actual0052 runDemo2029Operation output from synthetic mocks, not a fabricated JSON claim or app endpoint. It visibly labels itself QA-only/non-live, shows actual returned active SHA=c40, fixed failed ID/D2 source/old expiry and observed zero state accesses/mutations, two query calls/eight fences. Browser asserts those exact values and after reload, zero errors/unexpected network, and captures result.png, trace.zip, WebM, actual-result.json, test-results.json and custom playwright-report/index.html. It cannot enable a production surface. The third new screenshot was visually inspected. This is actual-function synthetic evidence, never provider proof.

## History and remaining gates

QA1 BLOCKED, QA2 PASSED, QA3 BLOCKED-local-native, QA4 PASSED remain hash-verified unchanged. QA4's ambiguous sentence about preserved artifacts was clarified by actual agent message, not by altering its seal; QA2 is not relabeled blocked. Old local native9/1 full=sparse remains a machine limitation. Earlier hosted10/10 proof pins45b (and remote comments mention0f02), NOT0052; no new native localhost run or current hosted qualification is claimed. The original author correction and all previous genuine failures remain in history.

QA Gate and required evidence/run guidance were fully reread and drove every fresh phase and the safe internal screenshot surface. Only private outputs are written; root owns publication. No tracked edit/commit, push, canonical/GitHub mutation, actual provider/model call, real auth session/clinical read/write, SQL, stage/deploy or issue closure occurred. Source0052 is not adopted/reviewed/published at this gate. Same unadopted fifth implementation/old4attempts/2spent reviews/limits remain intact; no allowance or approval transfer.

Exact current published-head CI, genuine existing-route Claude Max round3, distinct post-Claude final independent review, protected merge, real DEMO metadata and capability registration, separately authorized stage/deploy and actual online ready/current-source/demo/simulator/temporary/synthetic2029/five-profile desktop/mobile reload acceptance remain mandatory. Issue stays open/unverified. No PR527 approval/native-profile activation or qualification is implied.

Final scoped verdict READY FOR CODEX QA; findings[]. This is not a release/online approval.
