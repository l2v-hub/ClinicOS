import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const cwd='C:/w-rv/auth-expiry-2029-qa3-20261103',dir='C:/w-rv/tmp/auth-expiry-2029-20261103/independent-qa5',path='scripts/automation/enable-demo-auth-2029.metadata.test.mjs';
const raw=await readFile(cwd+'/'+path,'utf8'),prefix=raw.slice(0,raw.indexOf('const read = options =>'));assert.ok(prefix.endsWith('\n'));
const text=prefix.replace("'./enable-demo-auth-2029.mjs'","'file:///"+cwd+"/scripts/automation/enable-demo-auth-2029.mjs'").replace("'../../agent-team/src/bug-pipeline/demo-deployment.mjs'","'file:///"+cwd+"/agent-team/src/bug-pipeline/demo-deployment.mjs'")+"\nexport {fixture,api,selector,activeId,activeSha,failedId,failedSha};\n";
await writeFile(dir+'/metadata-fixture.mjs',text,{flag:'wx'});const hash=x=>createHash('sha256').update(x).digest('hex');await writeFile(dir+'/metadata-fixture-transform.json',JSON.stringify({sourcePath:path,sourceSha256:hash(raw),prefixSha256:hash(prefix),fixtureSha256:hash(text),transformation:'Exact committed synthetic fixture preamble, only absolute import URLs and exports added. No source or assertion edits.'},null,2)+'\n',{flag:'wx'});
