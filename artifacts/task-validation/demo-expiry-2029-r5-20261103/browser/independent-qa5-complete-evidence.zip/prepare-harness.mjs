import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const old='C:/w-rv/tmp/auth-expiry-2029-20261103/independent-qa4',dir='C:/w-rv/tmp/auth-expiry-2029-20261103/independent-qa5',source='0052ad4780998772ded9c6cde9e52b7400f845cf',oldSha='45b178b7ea93ade254d5cd0ea68340bd09cdd838';
const hash=x=>createHash('sha256').update(x).digest('hex'),records=[];
for(const name of['run-check.mjs','isolated-build-entry.mjs','controller-fixture.mjs','parent-and-policy.test.mjs','final-main-revocation.test.mjs','synthetic-ui-2029.mjs','check-port.mjs']){const raw=await readFile(old+'/'+name,'utf8'),text=raw.replaceAll(old,dir).replaceAll(oldSha,source);assert.equal(text.replaceAll(dir,old).replaceAll(source,oldSha),raw);await writeFile(dir+'/'+name,text,{flag:'wx'});records.push({name,originalSha256:hash(raw),sha256:hash(text),assertionsUnchanged:true,transformation:'Private output directory and frozen SHA only; same sequentially handed-off clean QA checkout.'});if(name==='run-check.mjs')await writeFile(dir+'/run-sparse-check.mjs',text.replaceAll('C:/w-rv/auth-expiry-2029-qa3-20261103','C:/w-rv/auth-expiry-2029-qa5-protected-sparse-20261103'),{flag:'wx'});}
await writeFile(dir+'/fixture-transform-receipt.json',JSON.stringify(records,null,2)+'\n',{flag:'wx'});
