import net from 'node:net';
import {writeFile} from 'node:fs/promises';
const host='127.0.0.1',port=5317,server=net.createServer();
await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);});
await new Promise(resolve=>server.close(resolve));
await writeFile('C:/w-rv/tmp/auth-expiry-2029-20261103/independent-qa5/port-before-ui.json',JSON.stringify({at:new Date().toISOString(),host,port,unusedLoopbackBindVerified:true,closedBeforeStrictPreviewStart:true,sharedStackOrDatabaseStarted:false},null,2)+'\n',{flag:'wx'});
console.log('Loopback5317 unused; temporary availability probe closed. Preview must bind strictPort and will not take over another listener.');
