import { execFileSync } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const cwd = 'C:/w-rv/auth-expiry-2029-metadata-author-20261103';
const dir = 'C:/w-rv/tmp/auth-expiry-2029-20261103/metadata-author-new';
const hash = x => createHash('sha256').update(x).digest('hex');
const git = args => execFileSync('git', args, { cwd, encoding: 'utf8' }).trim();
const sourceSha = git(['rev-parse', 'HEAD']); assert.equal(sourceSha, '0052ad4780998772ded9c6cde9e52b7400f845cf');
assert.equal(git(['status', '--porcelain']), '');
const paths = git(['diff', '--name-only', '0f02f9cc..HEAD']).split('\n');
assert.equal(paths.length, 4);
const sourceManifest = [];
for (const path of paths) { const bytes = await readFile(cwd + '/' + path); sourceManifest.push({ path, bytes: bytes.length, lines: bytes.toString('utf8').split('\n').length,
  blob: git(['rev-parse', `HEAD:${path}`]), sha256: hash(bytes) }); }
const executions = [];
for (const label of ['red-metadata', 'green-metadata-first', 'green-metadata-final']) {
  const raw = await readFile(`${dir}/${label}/receipt.json`); const receipt = JSON.parse(raw);
  const stdout = await readFile(`${dir}/${label}/stdout.log`); const stderr = await readFile(`${dir}/${label}/stderr.log`);
  assert.equal(hash(stdout), receipt.stdoutSha256); assert.equal(hash(stderr), receipt.stderrSha256);
  executions.push({ label, ...receipt, receiptSha256: hash(raw) });
}
const baseline = execFileSync('git', ['show', '0f02f9cc:scripts/automation/enable-demo-auth-2029.mjs'], { cwd, encoding: 'utf8' });
const candidate = await readFile(cwd + '/scripts/automation/enable-demo-auth-2029.mjs', 'utf8');
const body = (text, start, end) => text.slice(text.indexOf(start), text.indexOf(end, text.indexOf(start)));
const originalBodies = {};
for (const [name, start, end] of [['inspect', 'export async function inspectDemo2029Target', 'export async function stageDemo2029'],
  ['stage', 'export async function stageDemo2029', 'export async function runDemo2029Operation']]) {
  const old = body(baseline, start, end), current = body(candidate, start, end); assert.equal(current, old);
  originalBodies[name] = { byteEquivalent: true, sha256: hash(current) };
}
const result = { kind: 'author-handoff-not-independent-qa', sourceSha, tree: git(['rev-parse', 'HEAD^{tree}']), sourceManifest, originalBodies, executions,
  reportSha256: hash(await readFile(dir + '/author-report.md')), clean: true, providerCalls: 0, clinicalCalls: 0, canonicalWrites: 0, pushed: false,
  verdict: 'IMPLEMENTED — NOT VERIFIED', pending: ['root-integration','independent-qa','exact-head-ci','genuine-max-review','final-codex-review','merge','metadata-stage-deploy-online'] };
await writeFile(dir + '/author-evidence.json', JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ sourceSha, tree: result.tree, reportSha256: result.reportSha256, evidenceSha256: hash(await readFile(dir + '/author-evidence.json')) }));
