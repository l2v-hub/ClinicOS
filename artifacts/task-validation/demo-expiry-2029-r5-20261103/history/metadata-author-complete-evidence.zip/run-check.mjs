import assert from 'node:assert/strict';
import { mkdir, writeFile, lstat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { createRunner } from 'file:///C:/w-rv/auth-release-main20261102/agent-team/src/bug-pipeline/process.mjs';
const [label, sha, ...args] = process.argv.slice(2);
const cwd = 'C:/w-rv/auth-expiry-2029-metadata-author-20261103';
const dir = 'C:/w-rv/tmp/auth-expiry-2029-20261103/metadata-author-new/' + label;
assert.match(label, /^[a-z0-9-]+$/); assert.match(sha, /^[a-f0-9]{40}$/);
await mkdir(dir, { recursive: true });
const run = createRunner({ runtimeRoot: dir + '/runtime' });
const hash = x => createHash('sha256').update(x).digest('hex');
const git = async args => {
  const r = await run({ command: 'git', args, cwd, envMode: 'verification', maxOutputBytes: 4 * 1024 * 1024 });
  assert.equal(r.ok, true); return r.stdout.trim();
};
const capture = async () => {
  assert.equal(await git(['rev-parse', 'HEAD']), sha);
  assert.equal(await git(['status', '--porcelain', '--untracked-files=no']), '');
  return { head: sha, index: hash(await git(['ls-files', '--stage'])) };
};
const before = await capture();
if (args[0] === '--test') for (const file of args.slice(1)) assert.equal((await lstat(cwd + '/' + file)).isFile(), true);
const startedAt = new Date().toISOString();
const result = await run({ command: process.execPath, args, cwd, envMode: 'verification', timeoutMs: 15 * 60 * 1000, maxOutputBytes: 8 * 1024 * 1024 });
const after = await capture(); assert.deepEqual(after, before);
await writeFile(dir + '/stdout.log', result.stdout, { flag: 'wx' });
await writeFile(dir + '/stderr.log', result.stderr, { flag: 'wx' });
await writeFile(dir + '/receipt.json', JSON.stringify({ startedAt, finishedAt: new Date().toISOString(), cwd, sha, args, before, after,
  sourceStable: true, credentialsInherited: false, ok: result.ok, exitCode: result.code, stdoutSha256: hash(result.stdout), stderrSha256: hash(result.stderr) }, null, 2), { flag: 'wx' });
console.log(JSON.stringify({ label, sha, ok: result.ok, exitCode: result.code, sourceStable: true }));
if (!result.ok) process.exitCode = 1;
