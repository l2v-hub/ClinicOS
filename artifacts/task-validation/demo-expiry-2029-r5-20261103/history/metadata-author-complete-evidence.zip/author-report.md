# Fixed2029 metadata prerequisite — author handoff

Status: IMPLEMENTED — NOT VERIFIED online. This is an author report, not independent QA, authentic Max review, release approval, a capability, or deployment proof.

## Exact source

- Parent artifact: `0f02f9cc25f14996891e162cabe2789ee89dafed`.
- RED: `2631be9e483cd2361239b098bab9dc6bfa97e4cf`.
- Initial GREEN: `9ada019460f65651bc90ca656f7547db51cc521c`.
- Final, stronger CLI existence assertion: `0052ad4780998772ded9c6cde9e52b7400f845cf`.
- Final tree: `081a71c9fee82b79b1191d257d2788c0379da584`.
- Dedicated branch: `codex/demo-expiry-2029-metadata-author-20261103`.
- Only the four claimed files changed. Worktree clean; no push.

## Implementation / operational read-off

`readDemo2029Metadata` is a fixed read-only projection without any canonical request, controller, claim, intent or action capability. It validates the same fixed child selector, uses existing `inspectDemo(..., native-exact-commit-v1)` and fixed target, verifies complete idle inventory and a unique SUCCESS active deployment with an actual 40-hex `meta.commitHash`, then validates the fixed prior FAILED deployment and D2 source. Active source is not inferred from main/failed source or deployment ID. Active source equal to main/failed source is refused, consistent with the registered-stage contract.

It reads only the fixed auth/status and ready URLs, requires the exact expired October31 synthetic disabled state and healthy demo ready identity, and checks current main before and after each of its four awaited metadata reads (eight checkpoints). Errors become a fixed sanitized code; no raw provider error, meta, variables or secret is returned. Scalar receipt fields include actual active ID/source, fixed failed ID/source and canonical previous expiry; existing 8192-byte whitelist/credential-reflection protection remains. Metadata receipts require mutationAttempted=false and deploymentTriggered=false.

`runDemo2029Operation` branches metadata without even accessing controller/inspect/onProgress getters. CLI validates its unchanged trusted Actions context/selector, then metadata branches before construction of GitHub/state/controller clients. Existing inspect/stage bodies, durable action authorization and revocation/CAS code are unchanged. No stage action is implied by metadata success.

Existing protected workflow now accepts `[inspect, stage, metadata]`, still defaulting to inspect and keeping all actor/main/attempt/environment/deadline guards. Pinned checkout uses exact source ref, persist-credentials=false and sparse cone directories agent-team/scripts/.github plus root files, avoiding materialization of historical QA archives. Both workflow and bug CI explicitly run original and new metadata suites before protected credentials are loaded.

After actual review/merge, a root-authorized metadata workflow can yield the missing real active SHA before registering the separately authorized stage. Neither that workflow nor any provider operation was run by this author.

## Actual executions retained

Trusted D2 createRunner, `envMode:'verification'`, credentials stripped, source/index checked before and after every test command. Exact requested paths were checked to exist. Synthetic mock providers only; no app install, provider/identity/clinical network, model, SQL, deploy or canonical write.

Command for each source-bound run:

`node --test scripts/automation/enable-demo-auth-2029.test.mjs scripts/automation/enable-demo-auth-2029.metadata.test.mjs scripts/automation/renew-demo-auth-expiry.test.mjs`

| Commit | Evidence directory | Actual result |
|---|---|---|
| RED2631 | red-metadata | 212 total; 156 PASS / 56 FAIL / 0 SKIP; absent metadata export/mode and missing workflow choice/test wiring |
| GREEN9ada | green-metadata-first | 212 PASS / 0 FAIL / 0 SKIP |
| FINAL0052 | green-metadata-final | 212 PASS / 0 FAIL / 0 SKIP |

Each directory preserves stdout.log, stderr.log and receipt.json. Original two suites actually contribute 156 tests in this source, not an assumed158. New suite contributes56 enabled tests. No assertion was disabled or weakened. The final assertion additionally requires CLI metadata branch existence before state client construction.

Negative cases include wrong project/service/token environment/domain/repository, incomplete/inflight/absent/duplicate active inventory, invalid/missing active SHA/ID, active already main or failed source, latest not the fixed FAILED deployment, wrong failed target/source/status, wrong public tier/ID/readiness/checks/auth/expiry/synthetic status, missing/foreign selector, each current-main await boundary, private provider body/error rejection, unknown receipt fields and credential aliases. Metadata mode never accesses throwing controller/stage getters or performs mutation requests.

`git diff --check 0f02f9cc..HEAD` passed; all changed files are below500 lines. No backend/frontend/normal seven-day module/controller paths changed.

## Planning failure preserved

The first validator command used slug `demo-expiry-2029-r5-20261103/current`; the validator normalized it to `demo-expiry-2029-r5-20261103-current` and reported a missing contract in the sparse checkout. This was a planning/tool-path error, not a passing validation result. Root then explicitly permitted read-only materialization of the exact tracked packet. `validate-task-contract.js demo-expiry-2029-r5-20261103` reported CONTRACT VALIDO. Disk and immutable Git blob agree: `6cdfc1e4ddbee786fa59035e79875ce3a90e0aec`. No contract was edited or committed here.

## Pending gates / limits

Root integration, independent source/security QA, actual exact-head CI, genuine Max review, final Codex review, protected merge and all operational metadata/stage/deploy/online checks remain separate. This author consumed no new allowance, invoked no provider and did not reset any history, attempt or review counter. Existing historical artifacts and primary worktree were untouched.
