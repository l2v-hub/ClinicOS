import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture,selector,authorized,fresh} from './controller-fixture.mjs';
import {createDemo2029Controller} from 'file:///C:/w-rv/auth-expiry-2029-qa-20261103/scripts/automation/demo-2029-controller.mjs';
import {stageDemo2029} from 'file:///C:/w-rv/auth-expiry-2029-qa-20261103/scripts/automation/enable-demo-auth-2029.mjs';
test('revocation during final awaited current-main verifier prevents provider mutation',async()=>{
 const f=fixture();await authorized(f);let armed=false,revoked=false,writes=0;
 const controller=createDemo2029Controller({...f.dependencies,assertCurrentMain:async expected=>{
  await f.dependencies.assertCurrentMain(expected);
  if(armed&&!revoked){revoked=true;f.revoke();}
 }});
 const result=await stageDemo2029({selector,actor:'worker-fixture',runId:'77',controller,
  inspect:async()=>{if(f.record().execution?.status==='write-intent')armed=true;return fresh();},
  client:async()=>{writes++;return{variableUpsert:true};}});
 assert.equal(revoked,true,'the actor was revoked before final current-main await returned');
 assert.equal(writes,0,'revocation before the final authorization path completes must prevent the write');
 assert.equal(result.mutationAttempted,false);
});
