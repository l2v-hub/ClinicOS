# Independent QA — BLOCKED at 8a8d5a50

Reviewer: actual independent agent `/root/auth_expiry_final_qa`.
Source: `8a8d5a50be8197b95605567d7b3cfd7815f266a8`.
Tree: `d7b89a913d429b7ca3aee1b8cab6f7682044bd51`.
Dedicated checkout: `C:/w-rv/auth-expiry-2029-qa-20261103`.

## Security finding — revocation can precede the provider write

Priority P1. Location: `scripts/automation/demo-2029-controller.mjs:162` (allowed/owned), with final mutation boundary `scripts/automation/enable-demo-auth-2029.mjs:74`.

allowed rechecks the actor/author's maintainer permission, then awaits assertCurrentMain. owned subsequently checks canonical identity but does not refresh permission after that awaited source check. If permission is revoked while the final main verifier is pending, the last authorization path returns successfully and stageDemo2029 invokes its provider mutation once. A later failed finish conservatively leaves uncertainty but cannot undo that unauthorized write.

Actual private test `final-main-revocation.test.mjs`: authorize through the existing fully synthetic capability fixture; arm revocation only in the last inspect after durable write-intent; await the real fixture main verifier and revoke before it returns. Expected provider calls0; actual1. The callback returns `{variableUpsert:true}` only in memory; no live provider was contacted. This is a demonstrated missing post-await revocation fence, not a claim of a real live2029 mutation, secret exposure or clinical write. The negative assertion is preserved unchanged in final-main-revocation/receipt.json and stdout.log (exit1, one genuine failure, source/index stable).

Required repair: check revocation after asynchronous main/source/run verification, while retaining the caller's final canonical owner/prior-history/claim observation and finite cutoff. Do not waive the assertion, replay uncertainty or rewrite old stages. Root accepted the finding and will assign any source repair to the original author under the same unpublished fifth attempt. This reviewer changed no source.

## QA Gate phases and actual independent evidence

| Phase | Result | Evidence |
|---|---|---|
| Contract | Read full frozen118-line contract, AC1–AC9; live acceptance not claimed | current/task-contract.md Git blob/hash in execution-evidence.json |
| Diff | Eight nonartifact paths reviewed; no unrelated app/schema/production changes | Complete25-path immutable manifest and unchanged-blob proof |
| Tests |155/155 focused PASS;13/13 new parent-shape/pure-policy PASS; new revocation regression FAIL | focused-155, actual-parent-and-policy, final-main-revocation receipts/logs |
| Build/typecheck | Full production frontend+backend/Prisma/fonts PASS; standalone frontend tsc noEmit PASS | full-isolated-build and frontend-typecheck receipts/logs |
| Synthetic browser |34/34 actual-built-App cases PASS at1280/390, five future2029 roles persist after reload | browser/browser.json, future2029 PNGs, per-case trace.zip and WebM |
| Security | BLOCKED by concrete revocation defect above | unchanged failing private fixture; no real external side effects |

All runs used trusted D2 createRunner in verification mode, with no inherited provider/controller credentials and exact HEAD/index checked before/after. The private build entry asserts the QA checkout, explicitly sets NODE_ENV=production, synthetic loopback DATABASE_URL and fixed public-demo VITE_API_URL inside that credential-free process, and invokes the actual root build. It does not reuse the author's hardcoded ROOT entry. Prisma generation and backend/frontend compilation actually ran; no migration/seed/DB suite was claimed. Build warnings about chunk/plugin timing are retained; exit was0. The standalone frontend noEmit check produced no errors.

Parent supplied npm ci --ignore-scripts against the exact lock; its receipt/log and unchanged lock hashes are verified. This installation is not falsely called an independent rerun. Original exploratory ordinary-route red, missing-module red, actual candidate1 failures, and subsequent author greens remain in unique directories with verified log hashes; none were relabeled independent executions.

## Synthetic/parent proof boundaries

The parent compatibility fixture uses the actual captured parent523 record shape: Nov9 was STAGED in run41524928481; its authorized exact D2 deploy41527190689 subsequently failed. A separately synthetic new capability can bind that captured history without changing the parent. Five history/run/auth/source drift cases deny it. This is schema/compatibility evidence, not fresh authenticated Railway failure qualification.

Pure policy tests execute actual freshly built backend modules: future2029 works with explicit synthetic/demo opt-ins; production, missing opt-in, wrong dataset, expired and malformed values are denied; five server-owned roles are unchanged. No session token is issued or identity provisioned. The normal seven-day helper is byte-identical to D2 and its added2029-negative assertion passes. Backend/frontend/Prisma and production/exact-deploy workflows, railway.json, .railwayignore, manifests/lock remain unchanged. Dockerignore excludes evidence/generated archives, not required code/migrations/fonts; structural context tests and local build pass, not a claimed real Railpack deployment.

The browser uses a private adaptation of the committed D2 harness, the actual production build and expiry2029, not a substitute UI. Every non-loopback request is intercepted; positive cases assert the actual API origin is the public demo URL, all five profiles visible, reload persistence, zero console errors/relevant failed HTTP responses, no horizontal overflow and no session POST. Original negative cases preserve expected synthetic errors, including a mocked failed simulator request; no actual session is provisioned. All34 cases assert no unexpected request/page error, outbound0 and clinicalWrites0. Desktop/mobile screenshots were visually inspected. Trace/video cover the same isolated runs. Port5317 was verified unused, bound with strictPort, and closed in finally; no shared database/server was started.

Browser evidence paths (relative to this report): `browser/future-2029-1280.png`, `browser/future-2029-390.png`, `browser/future-2029-1280-trace.zip`, `browser/future-2029-390-trace.zip`, per-case video directories and browser.json. Every file/hash is in execution-evidence.json. These show synthetic future availability only; no live login, public deployment restoration or clinical data was accessed.

## Scope, instructions and remaining gates

Used the repository QA Gate skill and fully read its linked evidence/run guidance. Its objective-evidence/security requirements drove the independent build/typecheck, synthetic browser traces/video/result screenshots and explicit BLOCKED verdict. Higher-priority task boundaries prohibit source edits, public evidence attachment, source commits, provider dispatch or shared DB/session provisioning; all reports/generated artifacts therefore stay in this private independent-qa directory for root integration. The initially supplied root contract path was sparse-missing; frozen Git contained it, and the QA checkout physical contract is verified byte-equal. Sparse omissions are not called absent Git evidence.

Security inspection found no new package, token/credential/PHI fixture, SQL, generic variable/target/date input, permanent-mode or production-secret path. New logs/receipts use finite whitelisted metadata and synthetic evidence. Fresh user-session capability, exact source/owner/history binding, prior staged/deploy proof, one CAS claim/intent, skipDeploys=true and no uncertain-write retry remain intended boundaries, but the reproduced revocation defect blocks approval.

No new authenticated Railway failed-deployment metadata was available to this reviewer: root's read-only production-token attempt was denied. Do not invent proof or rewrite the acknowledged Nov9 stage. No source edit/commit/push, provider/model call, GitHub/canonical mutation, deployment, issue closure or real clinical write occurred. All prior implementation/review budgets, parent state and old permanent/profile candidates remain intact. Exact repaired-source CI, genuine Max round3, final independent QA, actual authorized stage/deploy and online five-profile desktop/mobile acceptance remain mandatory. AC8/AC9 resolution is pending; issue must remain open/unverified.

Final verdict: **BLOCKED**. Codex must now re-run the QA Gate after a separately frozen author repair. No old approval transfers to that future source.
