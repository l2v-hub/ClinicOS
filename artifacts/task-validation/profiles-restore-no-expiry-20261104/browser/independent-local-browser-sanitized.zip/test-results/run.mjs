import { startPo05Postgres } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/tests/fixtures/po05-postgres.mjs';
import { chromium } from 'file:///C:/w-rv/auth-expiry-2029-qa3-20261103/node_modules/playwright/index.mjs';
import { spawn, spawnSync } from 'node:child_process';
import { createServer } from 'node:net';
import { writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';

const root='C:/w-rv/profiles-no-expiry-qa-20261104';
const out='C:/w-rv/tmp/profiles-restore-20261104/independent-qa';
const node=process.execPath;
let db, backend, frontend;
const log=(name,content)=>writeFileSync(`${out}/${name}`,content);
async function port(){const s=createServer(); await new Promise((resolve,reject)=>s.once('error',reject).listen(0,'127.0.0.1',resolve));const p=s.address().port;await new Promise(resolve=>s.close(resolve));return p;}
function run(name,args,env){const r=spawnSync(node,args,{cwd:root,env,encoding:'utf8',maxBuffer:30_000_000,windowsHide:true});log(`${name}.log`,`${r.stdout||''}\n${r.stderr||''}`);console.log(name,r.status);if(r.status!==0) throw new Error(`${name} failed, see log`);}
async function ready(url,child){for(let i=0;i<160;i++){if(child.exitCode!==null)throw new Error(`server exited ${child.exitCode}`);try{let r=await fetch(url);if(r.ok)return;}catch{} await new Promise(r=>setTimeout(r,250));}throw new Error(`server not ready ${url}`);}
try {
  db=await startPo05Postgres({artifactRoot:out,bin:'C:/w-rv/tmp/profiles-restore-20261104/postgres-bin-18/package/native/bin',repositoryRoot:root});
  console.log('fresh synthetic PostgreSQL, migrations:',db.applied.length);
  const apiPort=await port(), frontPort=await port();
  const env={...process.env,DATABASE_URL:db.url,NODE_ENV:'production',CLINICOS_ENV:'demo',AUTH_MODE:'demo',DEMO_DATASET_ID:'synthetic-v1',DEMO_AUTH_NO_EXPIRY:'true',ALLOW_PRODUCTION_DEMO_AUTH:'true',ROLE_SIMULATOR_ENABLED:'true',ROLE_SIMULATOR_ALLOW_PRODUCTION:'true',ROLE_SIMULATOR_SECRET:'qa-synthetic-only-signing-secret-32-plus-characters',DEMO_AUTH_EXPIRES_AT:'2000-01-01T00:00:00Z',PORT:String(apiPort),FRONTEND_URL:`http://127.0.0.1:${frontPort}`,AI_WORKER_INLINE:'false',VITE_API_URL:`http://127.0.0.1:${apiPort}`};
  if (!process.env.QA_BROWSER_ONLY) {
    run('auth-policy-tests',['--import','tsx','--test','backend/src/ai/__tests__/security.test.ts','backend/src/ai/__tests__/no-expiry-http.test.ts','backend/src/__tests__/phase9-production.test.ts','backend/src/authz/__tests__/policy-model.test.ts'],{...process.env,DATABASE_URL:db.url,NODE_ENV:'test'});
    run('backend-build-tsc',['node_modules/typescript/bin/tsc','-p','backend/tsconfig.json'],env);
    run('backend-build-assets',['scripts/build/copy-assessment-fonts.mjs'],env);
    run('frontend-typecheck',['node_modules/typescript/bin/tsc','-b','frontend'],env);
  }
  run('frontend-build',['node_modules/vite/bin/vite.js','build','frontend','--config','frontend/vite.config.ts'],env);
  const start=(args)=>spawn(node,args,{cwd:root,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
  backend=start(['backend/dist/server.js']);let backendLog='';backend.stdout.on('data',d=>backendLog+=d);backend.stderr.on('data',d=>backendLog+=d);
  const api=`http://127.0.0.1:${apiPort}`;
  await ready(`${api}/auth/status`,backend);
  frontend=start(['node_modules/vite/bin/vite.js','preview','frontend','--config','frontend/vite.config.ts','--host','127.0.0.1','--port',String(frontPort),'--strictPort']);let frontLog='';frontend.stdout.on('data',d=>frontLog+=d);frontend.stderr.on('data',d=>frontLog+=d);
  const front=`http://127.0.0.1:${frontPort}`; await ready(front,frontend);
  const request=async(path,opts={})=>fetch(api+path,opts);
  const status=await (await request('/auth/status')).json();assert.deepEqual(status,{mode:'demo',simulator:true,temporaryDemo:false,syntheticOnly:true,expiresAt:null});
  const entries=[['SIM-ADMIN','Amministratore','administrator'],['SIM-SUPERVISOR-1','Supervisore 1','supervisor'],['SIM-DOCTOR-1','Medico 1','doctor'],['SIM-NURSE-1','Infermiere 1','nurse'],['SIM-OSS-1','OSS 1','oss']];
  const identities=await (await request('/auth/simulator/identities')).json();assert.equal(identities.identities.length,5);
  const {buildBaselinePolicy}=await import('file:///C:/w-rv/profiles-no-expiry-qa-20261104/backend/dist/authz/baseline.js');
  const {effectiveCapabilities}=await import('file:///C:/w-rv/profiles-no-expiry-qa-20261104/backend/dist/authz/decision.js');
  for(const [id,,role] of entries){
    assert.equal(identities.identities.find(i=>i.id===id)?.roleId,role);
    const session=await request('/auth/simulator/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({identityId:id})});assert.equal(session.status,201);const {token}=await session.json();
    const me=await request('/auth/me',{headers:{Authorization:`Bearer ${token}`,'X-Operator-Id':'SIM-ADMIN','X-Operator-Role':'admin'}});assert.equal(me.status,200);const info=await me.json();assert.equal(info.id,id);assert.equal(info.appRole,role);assert.equal(info.identitySource,'simulator');assert.equal(info.expiresAt,null);const expected=Object.fromEntries(effectiveCapabilities(buildBaselinePolicy(),role).map(c=>[c.id,{effect:c.effect,allowed:c.allowed,requiresConfirmation:c.requiresConfirmation}]));assert.deepEqual(info.capabilities,expected);
    if(role==='oss'){assert.equal((await request('/authz/policy',{headers:{Authorization:`Bearer ${token}`}})).status,403);}
    assert.equal((await request('/auth/simulator/logout',{method:'POST',headers:{Authorization:`Bearer ${token}`}})).status,204);assert.equal((await request('/auth/me',{headers:{Authorization:`Bearer ${token}`}})).status,401);
  }
  assert.equal((await request('/auth/me',{headers:{'X-Operator-Id':'SIM-ADMIN','X-Operator-Role':'admin'}})).status,401);
  console.log('HTTP five identities, policy, spoof, logout: passed');
  const browser=await chromium.launch();
  try {for(const [view,viewport] of [['desktop',{width:1280,height:860}],['mobile',{width:390,height:844}]]){
    for(const [,label,role] of entries){
      const context=await browser.newContext({viewport,recordVideo:{dir:out}});await context.tracing.start({screenshots:true,snapshots:true});const page=await context.newPage();const errors=[];
      page.on('pageerror',e=>errors.push(`pageerror ${e.message}`));page.on('console',m=>{if(m.type()==='error')errors.push(`console ${m.text()}`)});page.on('response',r=>{if(r.status()>=400)errors.push(`HTTP ${r.status()} ${new URL(r.url()).pathname}`)});
      await page.goto(front);for(const [,name] of entries)await page.getByRole('button',{name:new RegExp(name)}).first().waitFor();
      await page.getByRole('button',{name:new RegExp(label)}).first().click();await page.waitForSelector('.teams-sidebar',{timeout:30000});
      await page.waitForFunction(()=>Array.from(document.querySelectorAll('.page-loading')).every(el=>el.getClientRects().length===0),null,{timeout:30000});await page.waitForLoadState('networkidle',{timeout:30000});
      assert.ok(!/Qualcosa è andato storto|Errore imprevisto|demo.*scadut/i.test(await page.locator('body').innerText()));
      const avatar=page.locator('.topbar-avatar');const roleLabel=identities.identities.find(i=>i.id===entries.find(e=>e[2]===role)[0]).roleLabel;assert.match(await avatar.getAttribute('aria-label'),new RegExp(`${label}, ${roleLabel}:`));
      const nav=page.locator('.teams-sidebar');const admin=['administrator','supervisor'].includes(role);assert.equal(await nav.getByRole('button',{name:admin?'Dashboard':'Turno',exact:true}).count(),1);assert.equal(await nav.getByRole('button',{name:admin?'Operatori':'Pazienti',exact:true}).count(),1);
      await page.screenshot({path:`${out}/${view}-${role}-settled.png`});
      for(const target of (admin?['Agenda','Consegne']:['Pazienti','Agenda','Consegne'])){
        const button=nav.getByRole('button',{name:target==='Consegne'?/^Consegne/:new RegExp(`^${target}$`)});if(await button.count()===0)continue;
        if(view==='mobile')await page.getByRole('button',{name:'Apri menu'}).click();await button.click();await page.waitForFunction(({target,admin})=>{const b=document.body.innerText;return !b.includes('Caricamento modulo…')&&(target==='Pazienti'?b.includes('Nessun paziente presente'):target==='Agenda'?b.includes(admin?'Agenda Globale':'Agenda di oggi'):b.includes('Consegne'));},{target,admin},{timeout:30000});await page.waitForLoadState('networkidle',{timeout:30000});
        const body=await page.locator('body').innerText();assert.ok(!/Qualcosa è andato storto|Errore imprevisto/.test(body));if(target==='Pazienti')assert.match(body,/Nessun paziente presente/);if(target==='Agenda')assert.match(body,admin?/Agenda Globale/:/Agenda/);if(target==='Consegne')assert.match(body,/Consegne/);await page.screenshot({path:`${out}/${view}-${role}-${target}-verified.png`});
      }
      await page.reload();await page.getByRole('button',{name:new RegExp(label)}).first().waitFor({timeout:30000});
      await page.getByRole('button',{name:new RegExp(label)}).first().click();await page.locator('.topbar-avatar').waitFor();await page.locator('.topbar-avatar').click();await page.getByRole('button',{name:'Cambia profilo'}).click();await page.getByRole('button',{name:new RegExp(label)}).first().waitFor({timeout:30000});
      await context.tracing.stop({path:`${out}/${view}-${role}-verified-trace.zip`});await context.close();assert.deepEqual(errors,[],`${view} ${role}: ${errors.join('; ')}`);console.log('browser verified',view,role,'passed');
    }
  }} finally {await browser.close();}
  log('servers.log',`backend:\n${backendLog}\nfrontend:\n${frontLog}`);
} catch(e){log('failure.txt',String(e.stack||e));console.error(e);process.exitCode=1;} finally {if(frontend)frontend.kill();if(backend)backend.kill();if(db)await db.close();}
