from pathlib import Path
import json,hashlib,difflib,stat,re,subprocess,datetime
D=Path('/tmp/clinicos-autonomy-activation-20261022');A=D/'author7';S=D/'source7';B=D/'source6'
def meta(p):
 b=p.read_bytes();return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def write(n,v): (A/n).write_text(json.dumps(v,indent=2)+'\n')
r=json.loads((A/'reservation.json').read_text());before=json.loads((D/'source7-before.json').read_text());allowed=json.loads((A/'allowlist.json').read_text());frozen=json.loads((A/'final-source-freeze.json').read_text())
assert r['nonce']=='c0dd45a8-235f-4774-aa7c-fceab1eaab38' and r['attempt']==7
assert meta(A/'task-contract.md')['sha256']==r['contractSha256']
assert meta(D/'source7-before.json')['sha256']==r['snapshotSha256']
assert len(before)==138 and len(allowed)==28
current={};changes=[];patch=[]
for n,m in before.items():
 p=S/n;bp=B/n;assert meta(bp)==m,('baseline changed',n)
 assert p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
 assert (p.lstat().st_mode&0o111)==(bp.lstat().st_mode&0o111),n
 current[n]=meta(p);assert current[n]==frozen[n],('source changed after final freeze',n)
 if current[n]!=m:
  assert n in allowed,n;changes.append(n)
  patch.extend(difflib.unified_diff(bp.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/'+n,tofile='b/'+n))
assert len(changes)==18
(A/'source.patch').write_text(''.join(patch))
previous=json.loads((D/'author6/source-manifest.json').read_text());cumulative=sorted(set(changes)|{x['path'] for x in previous['files']});assert len(cumulative)==26
manifest={'source':str(S),'attempt':7,'baseline':str(B),'gitParent':r['gitParent'],'publishedSourceHead':r['sourceHead'],
 'allowedPaths':allowed,'attemptDeltaPaths':changes,'actualDeltaCount':len(changes),'cumulativePaths':len(cumulative),
 'cumulativeCodeAndTests':24,'docs':2,'baselineFiles':138,'beforeManifestRawSha256':r['snapshotSha256'],
 'finalFreezeManifestRawSha256':meta(A/'final-source-freeze.json')['sha256'],'outsideAttemptScopeUnchanged':True,
 'baselineSource6Immutable':True,'regularFilesAndGitExecutableBitsVerified':True,
 'dependencySymlink':r['dependencyLink'],'testDataSymlinkReceiptSha256':meta(D/'source7-readonly-test-support-receipt.json')['sha256'],
 'files':[{'path':n,**current[n],'source6Sha256':before[n]['sha256'],'changedInAttempt7':n in changes,
  'physicalMode':oct((S/n).lstat().st_mode&0o777),'gitExecutable':bool((S/n).lstat().st_mode&0o111)} for n in cumulative],
 'all138BeforeAfter':{n:{'before':before[n],'after':current[n]} for n in before}}
write('source-manifest.json',manifest)
# Only syntax validation of current changed modules; no source mutations.
node='/tmp/clinicos-node22-native12/node_modules/node/bin/node';syntax=[]
for n in changes:
 if n.endswith('.mjs'):
  proc=subprocess.run([node,'--check',str(S/n)],capture_output=True,text=True)
  syntax.append({'path':n,'command':[node,'--check',str(S/n)],'exitCode':proc.returncode,
   'stdout':proc.stdout,'stderr':proc.stderr,'sourceSha256':current[n]['sha256']});assert proc.returncode==0,n
assert len(syntax)==16;write('syntax-final.json',{'status':'PASS','checked':16,'results':syntax})
# Verify every prior seal without rewriting any old packet.
seals={}
for name in ['author6','independent-qa6','luna-draftReady7','release-proof7-child']:
 directory=D/name;seal=json.loads((directory/'seal.json').read_text())
 for n,m in seal['files'].items():assert meta(directory/n)==m,(name,n)
 seals[name]={'sealSha256':meta(directory/'seal.json')['sha256'],'filesVerified':len(seal['files'])}
inputs=['author7/task-contract.md','author7/reservation.json','author7/allowlist.json','author7/plan-acceptance-and-scope-amendment.md','author7/root-plan-acceptance.json','source7-before.json','source7-readonly-test-support-receipt.json','peer-static-review2/actual-comment.json','peer-static-review2/actual-source-bound-report-metadata.json','actual-pre-source7-rollout-compatibility-inventory.json','historical-cutover7/actual-readonly-historical-merge-inventory.json','historical-cutover7/draft-finite-cutover-not-yet-authorized-or-written.json','independent-qa6/historical-subject-integrity.json','release-proof7-child/report.md','release-proof7-child/results.json','luna-draftReady7/report.md','luna-draftReady7/results.json']
write('read-receipts.json',{'inputs':{n:meta(D/n) for n in inputs},'nonce':r['nonce'],'canonicalAmendment':'261e0b7520569a1c57a9e8c683fabc5516ab4d4d',
 'sealedHistoricalEvidence':seals,'baseline138ByteVerified':True,'F6RecordedInventory':{'stateSha':'590fd02900a8b5f410d3486966e0cc0bf6a14542','globalTakeoverHasAutomation':False,'freshPremergeReverificationOwnedByRoot':True},
 'qa6Adaptation':'Original assertions unchanged; source prefix qa-source6 -> source7. The release stub alone now executes supplied native merge guard and reflects actual simulated MERGED after success, required by new postmerge identity gate. First stale-OPEN failure retained.',
 'historicalProofScope':'Old430 published artifacts and protected subjects inherit sealed QA6/root proof; no live or Git write/audit was repeated. No author canonical mutation occurred.'})
def runInfo(label):
 info=json.loads((A/(label+'.json')).read_text());log=(A/(label+'.log')).read_text();counts={}
 for key in ['tests','pass','fail','cancelled','skipped']:
  matches=re.findall(r'^# '+key+r' (\d+)$',log,re.M);counts[key]=int(matches[-1]) if matches else None
 return {**info,**counts,'log':label+'.log','logSha256':meta(A/(label+'.log'))['sha256']}
full=runInfo('final-integrated-781');bound=runInfo('final-boundaries-781');historical=runInfo('final-historical-replay')
assert full['exitCode']==0 and full['tests']==781 and full['pass']==781 and full['fail']==0
assert bound['exitCode']==0 and bound['tests']==15 and bound['pass']==15 and bound['fail']==0
assert historical['exitCode']==0
classifications={
 'initial-causal':'Three genuine causal pre-change failures (legacy4field, pre-execute read burn, failure-to-block ownership race).',
 'core-first':'202PASS6FAIL: one genuine integration regression (pre-model informational ownership guard removed; restored), one expected new finite diagnostic fixture value, four missing historical trace fixtures. Root later supplied exact read-only main2ee fixture; no source workaround.',
 'recovery-new':'5PASS2FAIL: author fixture errors (block callback omitted batch argument causing circular reason, and test expected inference while explicitly blocked / hashed undefined pointer). Both retained and corrected at synthetic boundaries.',
 'retained-progress':'Author integration fixture lacked required frontend-build verification in plan; corrected local test plan, no policy relaxation.',
 'lost-worktree':'Genuine negative caught resumed-loop nontermination on lost output. Author-owned Node test leaf terminated SIGTERM after55.6s; no replayed inference. Resumed failures now exit to block; subsequent retained/lost cases2PASS.',
 'integrated-full':'778PASS1FAIL: pending backend test seeded legacy already-deployed receipt without finite cutover/new immutable proof. Updated only that modern-delivery fixture using actual exported captureReleaseReviewProof; legacy terminal fixtures unchanged.',
 'final-boundaries':'14PASS1FAIL: reused QA6 native merge stub left PR OPEN after simulated success and ignored callback. Boundary now executes guard and reports MERGED; original assertions unchanged.',
 'completed-internal':'Genuine same-F3 completed internal feedback boundary initially blocked on resumed source feedback identity; fixed finite completed-phase interruption and bound prior feedback context.',
 'completed-internal-diagnostic':'Same retained source failure with explicit sanitized synthetic diagnostic; no additional finding or budget reset.'}
failures=[]
for p in sorted(A.glob('*.json')):
 try:info=json.loads(p.read_text())
 except Exception:continue
 if isinstance(info,dict) and 'command' in info and info.get('exitCode',0)!=0:
  label=p.stem;entry=runInfo(label);entry['classification']=classifications.get(label,'Retained failed run; see original log and report.');failures.append(entry)
write('failure-history.json',{'runs':failures,'allNonzeroAuthorNodeRunsPreserved':True,
 'bookkeeping':[{'receipt':'four-path-formatting-correction.json','classification':'Formatting selector included pre-child carryfield file; exact child baseline restored before serial integration. No semantic edit retained.'},
 {'classification':'Two read-only inspection commands initially used parent rather than source cwd and returned ENOENT; rerun with source7 prefix. No source/state mutation or test claim.'}],
 'childFailures':'All Luna and F2 first causal/fixture failures remain under verified original child seals; not flattened into a fabricated clean history.'})
results={'status':'IMPLEMENTED_AWAITING_INDEPENDENT_QA','attempt':7,'nonce':r['nonce'],'sourceHead':r['sourceHead'],'gitParent':r['gitParent'],
 'sourceFiles':138,'attemptDeltaPaths':18,'allowedPaths':28,'cumulativePaths':26,
 'finalIntegrated':full,'finalPrivateBoundaries':bound,'distinctFinalNodeTests':796,'syntaxFiles':16,
 'historicalOfflineReplay':{'command':historical,'entries':11,'standaloneTerminalChecks':10,'liveAuthorityClaimed':False},
 'sourceManifestSha256':meta(A/'source-manifest.json')['sha256'],'priorSealsVerified':seals,
 'sourceFrozen':True,'selfQaApproval':False,'sourcePublished':False,'canonicalWritten':False,'modelsInvoked':False,
 'liveApiProviderClinicalEffects':False,'findingsImplemented':['F1','F2','F3','F4','F5'],
 'F6':'Recorded actual absence plus strict schema retained; root must refresh authenticated absence immediately before merge/rollout.',
 'limitations':['No persistent remote worktree artifact service: a lost Actions VM worktree fails closed without replay.',
  'Standalone CLI has no default authorization verifier; trusted exact host grants remain required for each recovery/one-unit extension.',
  'No remote cause inferred from peer local github-read-failed: root actual 5.17MB read succeeded; limits unchanged.',
  'Historical cutover draft/replay is not authorization: root must freshly reverify real MERGED/head/merge/ancestry and preserve exact old subject JSON before rollout.',
  'Native6 implementation prefix and actualClaude1 remain unchanged. Static report2 was never a native claimed review.',
  'Fresh independent QA, actual peer/final/native/protected merge/provider/activation gates remain root responsibilities.']}
write('results.json',results)
(A/'report.md').write_text('''# Implementation7 report

Status: IMPLEMENTED_AWAITING_INDEPENDENT_QA. This author does not approve, publish, merge, activate workflows, deploy, close issues or write canonical state.

The original author nonce c0dd45a8-235f-4774-aa7c-fceab1eaab38 preceded this session. Root accepted the causal plan and amended scope to28 paths under canonical261e0b7520569a1c57a9e8c683fabc5516ab4d4d. All138 starting bytes matched immutable source6; the current source has18 actual deltas (9production,7tests,2docs), all allowed. Cumulative current scope is26 paths. Git parent remains publishedc172b1341e6f10d13c2407fd60fd9e92c1f93d74, with430 historical public artifacts preserved by the parent. No new attempt/reset/PR/native review was fabricated. Actual native implementation history6 and claimed Claude1 remain unchanged; static peer comment6355322575 is explicitly non-native.

F1: shared final-QA accounting recognizes only the exact completed four-field original legacy shape, counts it once, preserves its original bytes and separate deterministic legacyOrigins without invented nonce/time/fingerprint. Malformed modern spends remain ambiguous. recover-final-qa and extend-final-qa use existing trusted-host authorization and exact identity/history bindings. Ambiguous history is sealed as spent through the current allowance, never refunded; a separately consumed grant adds exactly one session. Actual native-store recovery tests progress to real synthetic inference/readiness while retaining all prior sessions; unavailable verifier, stale token and malformed history cannot create free retries. Modern completed verified proof matching current SHA/round/fingerprint survives post-inference publication recovery, even at an exhausted allowance, without another inference. Running/unknown leases retain prior safeguards.

F2: senior reviewed and serially integrated root-reserved6.1 child four-path patch after verifying all30 sealed files and exact baseline bytes. New merges freeze the source-bound QA/Claude proof in release.reviewProof and durably reserve merging before the native effect. Exact native callback guards recheck current feedback, checks, proof and owner; uncertain OPEN reservations are not replayed. Pipeline now skips merging tombstones during implementation. Postmerge completion uses the frozen review receipt and exact native MERGED identity rather than the mutable QA pointer. Finite root-owned historical cutover uses originalRelease digests, actual exact MERGED identity and ancestry pinned to source constant2ee298957c3e1733b01a4b4aca4b48b890032f69. No OPEN/new merge can use cutover metadata. Source/human/native/hold/provider controls remain separate. Original QA gate remains verified/SHA/round/current fingerprint; nonce/time are cloned when present, without new mandatory historical fields. The operational Actions path uses external review. Internal readiness without final Codex proof cannot independently authorize a new automatic merge. Root-recorded offline replay accepts all11 entries;10 already-merged standalone terminal subjects perform zero QA/save. This is not fresh live authority.

F3: observe now performs authenticated Contents reads directly, never branch creation or writer CAS-base promotion. Only freshly unchanged authenticated blob identity permits cached decoding; changed SHA decodes and validates hash/size/UTF8/metadata again. Output/state limits stay16MiB/8MiB; finite unknown/spawn/outputlimit diagnostics do not assert a remote cause or become transient retries. Before-invocation transport interruptions retain their original code/finite diagnostic and same running operation. Auth/schema/hash/integrity/uncertain-CAS errors remain fatal and cannot loop four implementation rounds. The seven-stage implementation journal records execute, verify, simplify, verify, QA, checkpoint and push. Completed steps are skipped only after an exact trusted recovery and verification of the retained registered worktree/branch/HEAD/base/frozen plan+packet/scope/all output digests. No generic dirty acceptance, reset, reinstall or paid model replay occurs. Export authorizeObservationResume supports trusted canonical host recovery before a PR exists; existing recover --pr action resume-observation supports later work, token controllerInterruption.progressSha256. No default CLI verifier is introduced. Actual retained real-Git output recovers ready with execute1/simplify1; lost/changed/foreign/frozen output fails closed. A lost VM is not remote persistence. Before and after actual finalQa, total inference remains1 across interruption/recovery. Pending external push and completed internal feedback stages resume only the unstarted effect, without redoing execute/simplify/checkpoint. Unknown or potentially completed effects keep their genuine reservations; persistent write failure cannot be claimed durably diagnosed.

F4: both generic failure-to-block catches narrowly recover typed ownership loss, reload canonical state and preserve remote A byte-for-byte before B proceeds. Both original pipeline and real external path are tested, plus the prior actual native409 reconciliation probe. Genuine unowned CAS/integrity/uncertain-write failures are not converted to ownership skips.

F5: root-reserved Luna supplied the minimal draftReady Proxy guard patch on a private shadow. Its exact two-file hunks were reviewed/applied serially; child causal/fixture history remains sealed. Additional actual original externalReviewStep callsite probe demonstrates owned A makes0 draftReady calls while eligible B makes1 and gets its review request. Explicit/manual caller authority is unchanged.

F6: actual recorded inventory590fd02900a8b5f410d3486966e0cc0bf6a14542 had no operatorTakeover.automation. No hypothetical legacy-handback migration was added; strict nonce-bound handback and malformed-active fail-closed regressions remain. Root must refresh and bind this authenticated absence immediately before merge/rollout. The author did not make that live claim or write a cutover.

Final frozen validation: 781/781 tests across13 affected suites, plus15/15 private actual-function boundary/original QA6 probes (796 distinct final tests), no skips/cancellations;16 changed mjs syntax checks PASS. A separate offline script replayed11 root-recorded historical entries and10 terminal identities. Source hashes were captured before final execution and verified unchanged afterward. Child481 successes overlap the final suites and are not added again. Previous qualified QA6/CI successes remain historical scope evidence only. No application/clinical E2E/browser/model/provider/network session was run by this author.

All first failures remain. Three initial causal tests failed before fixes. Intermediate logs include the genuine informational guard integration regression, missing read-only trace fixture, new diagnostic fixture expectation, new fixture callback/nil-pointer errors, a plan fixture missing required frontend build, a genuine lost-worktree resume-loop nontermination terminated only in the known author-owned test leaf after55.6s, the old backend fixture lacking a modern receipt, stale OPEN simulated native merge metadata, and the completed internal-feedback identity edge. Each correction has retained subsequent passing evidence; failure-history.json lists every nonzero author Node run. Root supplied the exact historical trace fixture read-only, separately excluded from138 source files. Formatting bookkeeping restoration of child baseline is recorded. Original source6, author6, QA6 and both child seals verify unchanged. owned-tmp/dependency trees are excluded from the evidence seal, with no deletion or concealment of logs.

Remaining gates belong to root: independent QA7, truthful actual peer/native/final review and protected merge, freshly authenticated finite historical cutover/absence proof, then existing provider/deployment/activation controls. No approval, all-issues-resolution or online deployment is claimed here.
''')
write('STOP.json',{'status':'STOP_SOURCE_FROZEN_AWAITING_INDEPENDENT_QA','nonce':r['nonce'],'attempt':7,'sourceManifestSha256':meta(A/'source-manifest.json')['sha256'],'resultsSha256':meta(A/'results.json')['sha256'],'sourceEditsAfterStop':False,'approvalClaimed':False})
# Source never changes during artifacts or syntax validation.
assert all(meta(S/n)==m for n,m in frozen.items())
seal={'status':'IMPLEMENTED_AWAITING_INDEPENDENT_QA','nonce':r['nonce'],'files':{p.name:meta(p) for p in sorted(A.iterdir()) if p.is_file() and p.name!='seal.json'},
 'excluded':['owned-tmp/ temporary isolated synthetic fixture repositories and runtime directories'],'sourceManifestSha256':meta(A/'source-manifest.json')['sha256']}
write('seal.json',seal)
assert len(seal['files'])<200
print(json.dumps({'status':results['status'],'sourceManifestSha256':meta(A/'source-manifest.json')['sha256'],'sealSha256':meta(A/'seal.json')['sha256'],'sealedFiles':len(seal['files']),'tests':796,'syntax':16,'sourceFiles':138,'actualDeltaPaths':18,'cumulativePaths':26},indent=2))
