from pathlib import Path
D=Path('/tmp/clinicos-autonomy-activation-20261022/source7/agent-team/src/bug-pipeline')
p=D/'operator-authorization.mjs';s=p.read_text()
s=s.replace("    assert.equal(collection, 'manualBatches', 'Issue-only authorization needs a manual owner');", "    assert.ok(collection==='manualBatches' || (collection==='batches' && action==='resume-observation' &&\n      subject.controllerProgress?.status==='interrupted'),'Issue-only authorization needs a manual owner or exact interrupted initial work');")
s=s.replace("const reviewIssue = pr === null ? subject.reviewIssue : null;", "const reviewIssue = pr === null ? (subject.reviewIssue??(action==='resume-observation'?subject.issues?.[0]:undefined)) : null;")
s+='''
export function observationProgressDigest(progress) {
  const copy=structuredClone(progress);delete copy.resumeAuthorization;return historyDigest(copy);
}
export function validateObservationResume(subject) {
  const progress=subject.controllerProgress, receipt=progress?.resumeAuthorization;
  assert.ok(progress?.status==='interrupted' && progress.schemaVersion===1 &&
    Number.isSafeInteger(progress.next)&&progress.next>=0&&progress.next<=7&&
    progress.completed?.length===progress.next && progress.checkpoint,
    'Exact retained implementation checkpoint required');
  assert.ok(receipt && ['user-session','distinct-maintainer-comment'].includes(receipt.provenance) &&
    receipt.bindingDigest===historyDigest(receipt.binding),'Trusted observation recovery receipt required');
  const binding=receipt.binding;
  assert.ok(binding.repository==='l2v-hub/ClinicOS' && binding.entityId===subject.id &&
    binding.action==='resume-observation' && binding.subjectSha===(subject.sha??null) &&
    binding.pr===(subject.pr?.number??null) && binding.budget?.kind==='controller-observation' &&
    binding.budget.progressSha256===observationProgressDigest(progress),
    'Observation recovery receipt identity changed');
  return progress;
}
// Trusted canonical hosts can also recover an initial batch before a PR exists.
// The ordinary CLI still has no default authorization verifier.
export async function authorizeObservationResume({state,subject,actor,reference,verifier,reason,now=()=>new Date()}) {
  const progress=subject.controllerProgress, interruption=subject.controllerInterruption;
  assert.ok(progress?.status==='interrupted' && interruption?.beforeInvocation===true &&
    interruption.code==='ownership-observation-failed' && progress.checkpoint &&
    interruption.progressSha256===observationProgressDigest(progress),
    'Only a proven pre-invocation observation interruption can resume');
  assert.ok(!progress.resumeAuthorization,'Observation recovery already authorized');
  assert.ok(typeof reason==='string' && reason.trim() && reason.length<=1000);
  const budget={kind:'controller-observation',progressSha256:observationProgressDigest(progress),
    interruptionSha256:historyDigest(interruption)};
  const binding=authorizationBinding({state,subject,actor,action:'resume-observation',budget});
  const authorization=await consumeOperatorAuthorization({verifier,reference,binding,state});
  progress.resumeAuthorization=authorization;
  validateObservationResume(subject);
  subject.recoveryHistory??=[];
  subject.recoveryHistory.push({action:'resume-observation',actor,at:now().toISOString(),reason,
    subjectSha:subject.sha??null,previous:structuredClone(interruption),authorization});
  subject.phase='planned';delete subject.failureCode;
  return authorization;
}
'''
p.write_text(s)
p=D/'workspace.mjs';s=p.read_text().replace("import { MAX_EVIDENCE_BYTES }", "import { validateObservationResume } from './operator-authorization.mjs';\nimport { MAX_EVIDENCE_BYTES }")
s=s.replace("    if(!progress.resumeAuthorization || progress.flow", "    validateObservationResume(batch);\n    if(!progress.resumeAuthorization || progress.flow")
p.write_text(s)
p=D/'comment-review-handoff.mjs';s=p.read_text().replace('authorizationBinding, consumeOperatorAuthorization','authorizationBinding, consumeOperatorAuthorization, authorizeObservationResume')
s=s.replace("    } else if (['recover-final-qa', 'extend-final-qa'].includes(action)) {", """    } else if(action==='resume-observation') {
      assert.equal(token,batch.controllerInterruption?.progressSha256,'Observation checkpoint changed');
      previous=clone(batch.controllerInterruption);
      recoveryAuthorization=await authorizeObservationResume({state,subject:batch,actor:login,
        reference:authorizationRef,verifier:authorizationVerifier,reason,now});
      // The shared authorizer records the durable exact-history receipt once.
      batch.recoveryHistory.pop();
    } else if (['recover-final-qa', 'extend-final-qa'].includes(action)) {""")
p.write_text(s)
# external correction progressive helper and finalQA not-started boundary
p=D/'external-review.mjs';s=p.read_text().replace("import { feedbackFingerprint", "import { runImplementationStages } from './workspace.mjs';\nimport { feedbackFingerprint")
s=s.replace("    ['implementing', 'validating', 'simplifying', 'publishing'].includes(batch.phase) ||\n    activeImplementation(batch)\n  )", "    !batch.controllerProgress?.resumeAuthorization && (\n    ['implementing', 'validating', 'simplifying', 'publishing'].includes(batch.phase) ||\n    activeImplementation(batch))\n  )")
s=s.replace("if (spentAttempts(batch, 'implementation') >= attemptLimit(batch, 'implementation'))", "if (!batch.controllerProgress?.resumeAuthorization && spentAttempts(batch, 'implementation') >= attemptLimit(batch, 'implementation'))")
s=s.replace("    await workspace.prepare(batch);\n    const attempt = reserveImplementation(batch);", "    if(!batch.controllerProgress?.resumeAuthorization)await workspace.prepare(batch);\n    const attempt = (batch.controllerProgress?.resumeAuthorization && activeImplementation(batch)) || reserveImplementation(batch);")
# remove pre-stage implementing save+notify; journal owns firstreserve save
s=s.replace("    batch.phase = 'implementing';\n    batch.approvedSha = null;\n    batch.issueFeedbackSince ??= observedAt;\n    await save();\n    await notify();\n    try {", "    batch.approvedSha = null;\n    batch.issueFeedbackSince ??= observedAt;\n    try {")
start=s.index('      if (\n        (\n          await workspace.execute(batch,');end=s.index("      attempt.status = 'passed';",start)
s=s[:start]+'''      const previous=batch.sha;
      await runImplementationStages({batch,workspace,save,context:{phase:'external-review-correction',
        round:attempt.round,feedback:{claude:verdict,github:feedback,
          ...(batch.codexFinalReview?{codex:batch.codexFinalReview}:{})}}});
      if(batch.sha===previous)throw new Error('Correction did not produce a new reviewed revision');
'''+s[end:]
s=s.replace("if (error?.code !== 'review-operator-owned') attempt.status = 'failed';", "if (!['review-operator-owned','ownership-observation-failed'].includes(error?.code)) attempt.status = 'failed';")
s=s.replace("          if (error?.code === 'review-operator-owned') throw error;\n          inference.status = 'failed';", """          if (error?.code === 'review-operator-owned') throw error;
          if(error?.code==='ownership-observation-failed' && error.beforeInvocation===true){
            inference.status='not-started';inference.invocation={status:'not-started',boundary:'ownership-observation',nonce:inference.nonce};
            batch.codexFinalReview.status='blocked';batch.codexFinalReview.invocation=structuredClone(inference.invocation);
            await save();throw error;
          }
          inference.status = 'failed';""")
p.write_text(s)
