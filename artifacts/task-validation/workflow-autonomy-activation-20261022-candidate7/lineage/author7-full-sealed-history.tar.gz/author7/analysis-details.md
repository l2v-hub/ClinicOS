# Continuation7 — causal plan for root decision

Status: **ANALYSIS ONLY — STOP before source edits/new tests.** Exact contract/reservation/snapshot bindings and all138 source7 bytes versus immutable source6 verified. Static comment6355322575 body SHA6faf10fc… verified. It is actual peer feedback, **not** a claimed native review2; native review count remains1. No native claim or protocol change is proposed.

## Decisions requiring acceptance

### F1 — strict original legacy QA, bounded progressive recovery

Main2ee29895 `external-review.mjs` really writes exactly `{subjectSha,claudeRound,status,summary}` after QA. Recognize **only that exact completed original shape**, valid SHA/round, supported terminal verdict and nonempty summary, with all modern identity fields absent. Preserve its original JSON; count it conservatively as one spent session for that SHA/round, independent of unknown old feedback. A separate deterministic legacy-origin digest/provenance deduplicates archived copies; never invent an original nonce, fingerprint or time. A partially present modern record remains malformed/ambiguous, not free. New inference must produce a fully modern proof.

Add separate final-QA allowance receipts (default3) rather than change implementation/review default4. Use the existing generic `recover --action … --sha … --token … --authorization …` dispatch; no CLI/default verifier change is necessary. Recommended actions:

- `recover-final-qa`: authenticate exact current blocked/pre-QA identity failure with the injected trusted host; archive the current pointer, retain every history and spent intent, re-check live SHA/round/fingerprint/checks and return to waiting-review only when another existing allowance is usable. Running leases keep existing release/expiry/force-live safeguards.
- `extend-final-qa`: one once-consumed grant adds **one** exact-identity unit. Bind previous/new limit, raw QA/history/allowance digest, entity/PR, SHA, Claude round and fingerprint; include the receipt in global replay detection and validation. Archive blocked pointers as part of the authorized action so the following invocation actually progresses. Never charge implementation attempts.
- Malformed modern history is never silently exempted. A trusted recovery must explicitly bind/resolve its original digest as spent. Where exact attribution cannot be proved, seal the existing allowance as exhausted/unknown (no fabricated historical sessions); only a separately authorized next unit permits one new inference. Keep unresolved originals immutable and require authoritative evidence, not an input JSON claim. No zero-debit/free retry resolution.

Probes: strict old verified QA counts1 then at most2 new sessions; archive duplicates count once; partial modern records still block; blocked identity recovery progresses; exhausted3 + one exact grant allows one additional call then stops; replay/wrong SHA/round/fingerprint/history/no-verifier all reject. Recovery must not merely clear a pointer and hit the same permanent block.

### F2 — merge-time proof receipt and finite historical cutover

Keep modern final-QA proof mandatory for **every new** normal/standalone merge. Persist an immutable full proof binding in the merge reservation/receipt: verified subjectSha, Claude round, approved/live fingerprint, QA nonce where modern, and digest of original proof/review identity. Post-merge deployment/publication validates that receipt and the actual exact reviewed/merge SHA, rather than a mutable current QA pointer or another inference on a closed PR. Preserve all current source/native/human/provider/hold gates.

Recommended compatibility authority is a **finite state-level cutover**, written only by root after actual read verification, outside old subject JSON. Per entry record repository, collection/id, PR, exact reviewedSha/mergeSha, original release digest, stable issue/scope/review identity digest, native GitHub merged receipt hash and normal ancestry proof. Root also records actor, actual time, authorization/source receipt, observed state commit and a fixed already-existing main commit. Each legacy merge must be an ancestor of that fixed cutover main. No status-only exception; no arbitrary missing-proof exemption; no new OPEN PR merge may use the cutover. Root refreshes the finite list immediately before rollout.

Inventory is real: old merges492(manual),491/494/495/496/498/499/500/501/502/503(standalone) exist. Current clinical batches are not yet merged. Do not convert those manual/standalone records into automatic batches to manufacture eligibility. Preserve their existing terminal/receipt paths and old JSON, test their actual collection adapters, and add the historical branch only where an existing post-merge delivery gate would newly require modern proof. Standalone already returns immediately on a merged release; keep it free of new QA/merge. Tests also exercise a synthetic old merged/deployed normal batch with publication pending and exact cutover proof. Unknown historical identity/changed merge/wrong ancestry fail. New merges without modern proof still make0 merge calls.

### F3 — typed observation failure, no fictitious work, real resumability

`observe()` currently calls another `load()` which calls `ensureBranch()`. Replace only the observer with genuinely read-only Contents reads, strict metadata/blob/hash checks, no branch creation and no writer base/fileSHA promotion. Optional validated-state cache is usable **only after a fresh authenticated unchanged Contents SHA and matching metadata**; changed SHA always decodes and validates the new blob. Keep existing16MiB output/8MiB durable-state limits.

Classify only evidenced transport failures as transient; preserve auth/rejected-read/identity/hash/schema/CAS failures as fatal. Retain finite sanitized causes (timeout/output-limit/spawn/nonzero/HTTP/rate-limit/unknown) without raw stderr or tokens. Actual peer local cause remains unknown: root CLI status0 on5.17MB contradicts diagnosing size alone. No blind retry loop, new provider or credential change.

At each guarded operation, distinguish a typed **before-invocation** observation error from failure after work started. Do not mark a code attempt failed. Preserve completed work, current round and durable running/unknown tombstones. A final-QA reservation prevented before actual invocation is retained as a strictly typed not-started observation interruption, not charged as an invoked session; unknown/started invocation stays spent/owned. This is a controller-produced boundary receipt, never a free-form caller assertion.

Use a bounded per-round operation checkpoint/interruption journal and a trusted `resume-observation` recovery bound to the exact interruption, plan, SHA, attempt/nonce and checkpoint. Resume the existing round at the unstarted operation, never replay execute/simplify/finalQa already completed. A single guard failure before verify resumes verification, not another implementation session. Failure before execute can invoke that same reserved session once after recovery. If the state transport remains unavailable, stop without claiming a durable diagnostic; preserve the last genuine reservation. Unknown process/side-effect outcome cannot be auto-resumed without the existing stopped-worker/expiry/force safeguards.

**Concrete scope dependency:** real `workspace.prepare` rejects any occupied dirty worktree (`workspace.mjs:174–188`), including valid executor output waiting for verification. Merely clearing phase/running flags cannot progress safely. I recommend authorizing **two additional paths**, `agent-team/src/bug-pipeline/workspace.mjs` and `agent-team/tests/bug-pipeline/workspace.test.mjs`, for a narrow resumed-worktree check that verifies exact registered branch/HEAD/base, frozen packet/plan and accepted scope before continuing that paused stage. No fresh installation or re-execution during resume. If worktree/checkpoint evidence is absent, remain blocked; do not guess or silently start a new model. This avoids an apparently recoverable state that immediately hits dirty-worktree failure. No models.mjs/role/protocol change is needed.

Probes use actual store observe and owned actual worktree fixtures: transient once at execute/verify/simplify/QA guards, no extra failed round or inference call; authenticated recovery reaches progress on the same round with no duplicate model; actual completed work remains spent; wrong worktree/plan/nonce fails; unknown writes remain fatal; same-SHA observation is fresh/read-only and changed-SHA ownership still stops A.

### F4 — block failure inside catch must still recover ownership

In both pipeline batch failure handlers, wrap only the diagnostic block boundary so an observed `review-operator-owned` still reaches `recoverOwnership`, reloads canonical A and continues B. Preserve the genuine failure in the author/controller evidence, not by overwriting the new owner's subject. All other block/save failures propagate. Probes: genuine failure → takeover immediately before block, A bytes/status/comments unchanged, B progresses; unowned CAS/uncertain-write/auth/integrity still abort.

### F5 — bounded guard-list fix, suitable for Luna

Add only `draftReady` to the existing automatic GitHub mutation guard list. Keep explicit/manual adapter calls unchanged. Tests: takeover immediately before draftReady means0 calls and canonical reload; ordinary unowned draft becomes ready exactly once.

**Luna is appropriate** for this small isolated change. Root can reserve a child session on a separate private source copy, with only pipeline.mjs guard-list hunk and a focused pipeline test, then receive a patch. The child must never edit source7/shared core concurrently. Apply/review its patch serially (prefer before the core pipeline refactor), then run integrated tests under this continuation. I will not spawn that child. This delegation does not block senior core analysis/implementation.

### F6 — use actual absence proof, retain strict schema

Inventory590fd029… at01:59:39Z proves global automation property **absent**, active takeover true with nonce. Use the review's explicit evidence alternative: root refreshes authenticated canonical state and records exact commit/hash and own-property absence immediately before merge/rollout. No speculative schema relaxation/migration. Tests retain strict old-shape rejection/automatic pause and valid new-bound handback, inactive/audit cases. A future real legacy shape would require a separately authorized migration, not automatic acceptance.

## Minimal implementation scope and verification

Core likely changes external-review, pipeline, release, comment-review-handoff, github, contracts, attempt-budget, operator-authorization and narrow standalone merge receipt/QA binding. Existing process error enums can be consumed without changing process.mjs unless an actual finite diagnostic needs it. Keep operator-ownership schema unchanged forF6; issue communication only if a real binding dependency appears.26 paths are a maximum, not a requirement to touch all.

**Requested decision:** approve these authority/recovery/cutover choices, and amend the allowlist with the two workspace paths for real progressive operation recovery. Root owns cutover creation/live proofs; author only implements/tests offline APIs. No source edit/new test is authorized by this analysis alone.

After acceptance: preserve before138 hashes; record causal failures first at the actual exported/native boundaries (recovery/store/workspace/release, not copied controller logic). Use fixedNode22 and existing isolated runner. Run affected suites once on final code, with additional regression reruns only for failures/new changes; relevant set is external-review/pipeline/release/comment-review-handoff/github/contracts/attempt-budget/operator-authorization/standalone-review/workspace and model/process-boundary tests only if those boundaries change. Reuse relevant exact QA6 ownership/CAS/nonce-dedup probes. No clinical E2E, live API, paid inference, native claim or installation. Seal final source/report/results/failure history and STOP for independent QA7 before publication.
