from pathlib import Path
p=Path('/tmp/clinicos-autonomy-activation-20261022/source7/agent-team/src/bug-pipeline')
f=p/'github.mjs';t=f.read_text();t=t.replace("        : rateLimited\n          ? 'rate-limit'", "        : result?.error === 'output-limit'\n          ? 'output-limit'\n          : result?.error === 'spawn-failed'\n            ? 'spawn-failed'\n            : rateLimited\n          ? 'rate-limit'",1)
t=t.replace('''    // Fresh ownership observations never promote this writer's expected Contents
    // SHA or base snapshot. A later save must still reconcile a real remote CAS.
    return { load, save, observe: () => createStateStore().load() };''','''    let observed;
    async function observe() {
      // No ensureBranch here: a supposedly read-only guard may never initialize it.
      const response=await api(`repos/${repo}/contents/${STATE_PATH}?ref=${encodeURIComponent(STATE_BRANCH)}`,
        {allowFailure:true,maxOutputBytes:STATE_OUTPUT_BYTES});
      if(!response.ok) {
        if(notFound(response)&&fileSHA===null)return null;
        throw githubOperationError(response.result,'read');
      }
      const value=response.value;
      if(value?.type!=='file'||value.target!==undefined||value.submodule_git_url!==undefined||
          typeof value.sha!=='string'||!/^[a-f0-9]{40}$/i.test(value.sha)||!Number.isSafeInteger(value.size)||value.size<=0||value.size>MAX_DURABLE_STATE_BYTES||
          !['base64','none'].includes(value.encoding)||(value.encoding==='none'&&value.content!==''))
        throw new Error('Durable observation metadata is invalid');
      if(observed?.sha===value.sha && observed.size===value.size) return structuredClone(observed.state);
      const state=await decodeDurableState(value);
      observed={sha:value.sha,size:value.size,state:structuredClone(state)};
      return state;
    }
    // Observations never alter the writer's remembered CAS SHA/base.
    return { load, save, observe };''');f.write_text(t)
f=p/'pipeline.mjs';t=f.read_text();t=t.replace('''          await block(
            batch,
            'External review consistency or correction failed; inspect the existing batch',
          );''','''          try {
            await block(batch, 'External review consistency or correction failed; inspect the existing batch');
          } catch (blockingError) {
            if(await recoverOwnership(blockingError))continue;
            throw blockingError;
          }''',1).replace('''      await block(
        batch,
        'Execution, evidence, authentication or remote consistency check failed; inspect sanitized controller diagnostics',
      );''','''      try {
        await block(batch, 'Execution, evidence, authentication or remote consistency check failed; inspect sanitized controller diagnostics');
      } catch (blockingError) {
        if(await recoverOwnership(blockingError))continue;
        throw blockingError;
      }''',1);f.write_text(t)
f=p/'standalone-review.mjs';t=f.read_text();start=t.index("    for(const key of ['finalQaAllowances'");end=t.index('    const subject = {',start);t=t[:start]+t[end:];t=t.replace("        'qaHistory',\n        'mergeHistory',", "        'qaHistory',\n        'codexFinalReviewHistory',\n        'codexFinalQaInfrastructure',\n        'finalQaAllowances',\n        'finalQaHistoryResolutions',\n        'mergeHistory',",1);t=t.replace('''      if (previous.release) {''','''      if(previous.codexFinalReview) {
        subject.qaHistory??=[];subject.qaHistory.push(clone(previous.codexFinalReview));
      }
      if (previous.release) {''',1);f.write_text(t)
