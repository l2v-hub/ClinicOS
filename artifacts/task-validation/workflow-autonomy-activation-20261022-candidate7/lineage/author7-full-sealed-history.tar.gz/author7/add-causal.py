from pathlib import Path
p=Path('/tmp/clinicos-autonomy-activation-20261022');s=p/'source7';a=p/'author7'
def append(name,code):
 f=s/'agent-team/tests/bug-pipeline'/name;f.write_text(f.read_text()+code)
append('external-review.test.mjs',r'''
test('Author7 F1 exact original legacy verified QA is one spent session, not an unrecoverable ambiguity', async () => {
  const {args,batch,log}=approvedExternalArgs();
  const old={subjectSha:batch.sha,claudeRound:1,status:'verified',summary:'Original main independent QA'};
  batch.codexFinalReview=structuredClone(old);
  await externalReviewStep(args);
  assert.equal(batch.phase,'ready');assert.equal(log.filter(x=>x==='qa').length,1);
  assert.deepEqual(batch.codexFinalReviewHistory[0],old);
  assert.equal(batch.codexFinalQaInfrastructure.legacyOrigins.length,1);
  assert.deepEqual(batch.codexFinalQaInfrastructure.legacyOrigins[0].original,old);
});
''')
append('pipeline.test.mjs',r'''
test('Author7 F3 observation failure before execute pauses the same unstarted attempt without model work', async () => {
  const h=harness({issues:[17]});let failed=false;
  h.store.observe=async()=>{if(!failed&&h.stateRef.value?.batches[0]?.phase==='implementing'){failed=true;throw Object.assign(new Error('synthetic timeout'),{code:'github-read-transient',operation:'read',retryable:true,diagnostic:'timeout'});}return clone(h.stateRef.value);};
  await h.run();
  assert.equal(failed,true);assert.equal(h.counts.execute,0);
  assert.equal(h.stateRef.value.batches[0].implementation.length,1);
  assert.equal(h.stateRef.value.batches[0].implementation[0].status,'running');
  assert.equal(h.stateRef.value.batches[0].failureCode,'github-read-transient');
});

test('Author7 F4 ownership acquired while diagnosing a real failure preserves A and still reviews B', async () => {
  const a=batchFor({issues:[17],phase:'waiting-checks'}),b=batchFor({issues:[18],phase:'waiting-checks'});
  b.pr={number:82,url:'https://github.com/l2v-hub/ClinicOS/pull/82'};
  for(const batch of [a,b])batch.feedbackFingerprint=feedbackFingerprint(openFeedback(batch));
  const h=harness({issues:[17,18],queue:[],initialState:{...blankState(),batches:[a,b]}});
  let failed=false,frozen;
  h.workspace.prepare=async batch=>{if(batch.id===a.id){failed=true;throw new Error('genuine preparation failure');}};
  h.store.observe=async()=>{if(failed&&!frozen){h.stateRef.value.batches[0].operatorCoordination={active:true};h.stateRef.value.batches[0].remoteNote='owner';h.stateRef.value.operatorTakeover=takeoverHandback([{collection:'batches',id:a.id}]);frozen=clone(h.stateRef.value.batches[0]);}return clone(h.stateRef.value);};
  h.gh.reviewFeedback=async n=>openFeedback(h.stateRef.value.batches.find(x=>x.pr.number===n));
  h.gh.commentPR=async()=>{};h.gh.requiredChecks=async()=>({ok:true});
  const reviewed=[];h.workspace.review=async batch=>{reviewed.push(batch.id);return {subject_sha:batch.sha,verdict:'approved',summary:'fixture',findings:[]};};
  const result=await h.run();assert.deepEqual(result.batches[0],frozen);assert.deepEqual(h.stateRef.value.batches[0],frozen);assert.deepEqual(reviewed,[b.id]);assert.equal(result.batches[1].phase,'ready');
});
''')
