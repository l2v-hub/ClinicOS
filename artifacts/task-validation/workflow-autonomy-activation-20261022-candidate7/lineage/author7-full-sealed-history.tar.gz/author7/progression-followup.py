from pathlib import Path
D=Path('/tmp/clinicos-autonomy-activation-20261022/source7/agent-team/src/bug-pipeline')
p=D/'workspace.mjs';s=p.read_text().replace("feedbackSha256:sha256(JSON.stringify(context.feedback??null)),status:'running'", "feedbackSha256:sha256(JSON.stringify(context.feedback??null)),feedback:structuredClone(context.feedback??null),status:'running'")
p.write_text(s)
p=D/'pipeline.mjs';s=p.read_text().replace("if(progress?.status==='running')progress.status='interrupted';", "if(['running','completed'].includes(progress?.status))progress.status='interrupted';")
s=s.replace("while ((resuming && activeImplementation(batch)) || spentAttempts", "while ((resuming && batch.controllerProgress.flow==='implementation') || spentAttempts")
s=s.replace("const attempt=(resuming&&activeImplementation(batch))||reserveImplementation", "const attempt=(resuming&&batch.controllerProgress.flow==='implementation'&&implementationAttempts(batch)[batch.controllerProgress.round-1])||reserveImplementation")
needle="      while (batch.reviews.length < attemptLimit(batch, 'reviews')) {"
s=s.replace(needle,"""      if(resuming && batch.controllerProgress.flow==='review-correction') {
        await runImplementationStages({batch,workspace,save,context:{phase:'review-correction',
          round:batch.controllerProgress.round,feedback:batch.controllerProgress.feedback}});
        batch.approvedSha=null;batch.phase='waiting-checks';await save();
        await report(batch,await workspace.issueEvidence(batch));
      }
"""+needle)
p.write_text(s)
