from pathlib import Path
p=Path('/tmp/clinicos-autonomy-activation-20261022/source7/agent-team/src/bug-pipeline')
f=p/'comment-review-handoff.mjs';t=f.read_text().replace('  attemptLimit,','  attemptLimit,\n  finalQaIdentity, finalQaAccounting, finalQaLimit, finalQaHistoryDigest,',1).replace('''    let previous;
    if (action''','''    let previous;
    let nextFailureCode;
    if (action''',1);marker="    } else if (action === 'release-qa-reservation') {";branch='''    } else if (['recover-final-qa', 'extend-final-qa'].includes(action)) {
      previous=clone(batch.codexFinalReview??null);
      assert.equal(token,previous?.nonce??historyDigest(previous),'Final QA recovery identity changed');
      assert.ok(previous?.status!=='running','Release an owned QA lease through its existing safeguarded recovery first');
      const feedback=await live(batch), identity=finalQaIdentity(batch,feedbackFingerprint(feedback));
      const accounting=finalQaAccounting(batch,previous,identity), limit=finalQaLimit(batch,identity);
      const digest=finalQaHistoryDigest(batch);
      if(action==='extend-final-qa') {
        assert.ok(!accounting.ambiguous,'Recover ambiguous QA history first');
        assert.ok(accounting.spent>=limit,'Final QA allowance is not exhausted');
        assert.ok(limit<32,'Explicit storage policy required beyond 32 final-QA sessions');
        const budget={kind:'final-qa',identity,previousLimit:limit,limit:limit+1,historyDigest:digest};
        recoveryAuthorization=await authorization(state,batch,login,action,authorizationRef,{budget});
        batch.finalQaAllowances??=[];
        batch.finalQaAllowances.push({identity,previousLimit:limit,limit:limit+1,historyDigest:digest,
          actor:login,at:now().toISOString(),reason,nonce:nonce(),authorizationRef,budget,authorization:recoveryAuthorization});
        batch.phase='waiting-review';
      } else if(accounting.ambiguous) {
        const budget={kind:'final-qa-history',identity,limit,historyDigest:digest,
          ambiguousDigests:accounting.ambiguousDigests,knownKeys:accounting.keys};
        recoveryAuthorization=await authorization(state,batch,login,action,authorizationRef,{budget});
        batch.finalQaHistoryResolutions??=[];
        batch.finalQaHistoryResolutions.push({identity,sealedLimit:limit,historyDigest:digest,
          ambiguousDigests:accounting.ambiguousDigests,knownKeys:accounting.keys,
          actor:login,at:now().toISOString(),reason,nonce:nonce(),authorizationRef,budget,authorization:recoveryAuthorization});
        batch.phase='blocked';nextFailureCode='final-qa-infrastructure-exhausted';
      } else {
        assert.ok(accounting.spent<limit,'Final QA allowance exhausted; extend exactly one unit');
        recoveryAuthorization=await authorization(state,batch,login,action,authorizationRef,
          {budget:{kind:'final-qa-recovery',identity,historyDigest:digest}});
        batch.phase='waiting-review';
      }
      if(previous){batch.qaHistory??=[];batch.qaHistory.push(previous);}
      delete batch.codexFinalReview;
''';assert marker in t;t=t.replace(marker,branch+marker,1);t=t.replace('''    delete batch.failureOperation;
    if (action === 'resume')''','''    delete batch.failureOperation;
    if(nextFailureCode)batch.failureCode=nextFailureCode;
    if (action === 'resume')''',1);f.write_text(t)
f=p/'attempt-budget.mjs';t=f.read_text().replace("      for (const kind of ['implementation', 'reviews']) attemptLimit(subject, kind, key);", "      for (const kind of ['implementation', 'reviews']) attemptLimit(subject, kind, key);\n      if(subject.finalQaAllowances||subject.finalQaHistoryResolutions) {\n        finalQaLimit(subject,finalQaIdentity(subject));\n        finalQaAccounting(subject,subject.codexFinalReview,finalQaIdentity(subject));\n      }",1);f.write_text(t)
f=p/'standalone-review.mjs';t=f.read_text().replace('''    const previous = state.standaloneReviews?.find((s) => s.pr.number === manifest.pr.number);''','''    const previous = state.standaloneReviews?.find((s) => s.pr.number === manifest.pr.number);
    for(const key of ['finalQaAllowances','finalQaHistoryResolutions'])
      if(manifest.subject?.[key]!==undefined) equal(manifest.subject[key],previous?.[key],'Adoption cannot supply final-QA authorization');''',1);f.write_text(t)
