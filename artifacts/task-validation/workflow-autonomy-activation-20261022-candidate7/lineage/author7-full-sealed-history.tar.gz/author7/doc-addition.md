
Il vecchio record finale composto esattamente da `subjectSha`, `claudeRound`, `status` e
`summary`, con verdetto completato valido, conta una sessione già spesa per quel SHA/round.
Il contenuto originale resta identico; `legacyOrigins` registra separatamente la provenienza,
senza inventare nonce, timestamp o fingerprint. Record moderni incompleti restano ambigui.
`recover --action recover-final-qa` richiede un grant esterno consumato sull'identità e sulla
cronologia esatte. Se lo storico è ambiguo, lo sigilla come allowance già esaurita; non concede
un tentativo gratuito. `extend-final-qa` aggiunge una sola sessione per grant verificato in
`finalQaAllowances`, separatamente dai budget implementazione/review. Una QA moderna già
`verified` sull'attuale SHA/round/fingerprint viene riutilizzata se è fallita solo la pubblicazione:
non si ripete l'inferenza completata. Le sessioni vive o con esito incerto mantengono le protezioni
di lease e recupero esplicito esistenti.

Un errore di osservazione GitHub prima dell'effetto può sospendere l'operazione corrente senza
trasformarla in un fallimento del codice. Il journal `controllerProgress` conserva i sette passi
execute, verifica, semplificazione, verifica, QA, checkpoint e push; il passo completato non viene
rieseguito. `controllerInterruption` conserva il codice/diagnostico finito originale, senza stderr
privato. Anche un errore di trasporto non classificato può essere sospeso, ma non viene chiamato
transitorio né ritentato automaticamente. Autenticazione rifiutata, stato/hash/schema invalidi e
scritture incerte restano errori fatali; non aprono quattro nuovi tentativi implementativi.

`recover --action resume-observation` per una PR esistente richiede il token
`controllerInterruption.progressSha256` e un'autorizzazione verificata dall'host. Prima della PR,
lo stesso host canonico può usare `authorizeObservationResume` con il soggetto iniziale esatto
e salvare tramite CAS. Nessun verifier è configurato automaticamente dalla CLI. La ripresa
verifica il worktree registrato, branch, HEAD, baseline, piano/packet congelati, scope e digest
esatto di ogni output del controller. Non accetta file sporchi generici e non reinstalla o resetta.
Se un nuovo runner Actions ha perso il worktree, la ripresa si ferma: questa funzione non rende
persistenti i worktree remoti e non ripete modelli già eseguiti o dal risultato incerto.

Ogni nuovo merge deve conservare la prova Codex finale legata a SHA/round/fingerprint nella
ricevuta di rilascio. Dopo il merge, il completamento usa la ricevuta congelata e l'identità
GitHub `MERGED`, senza dipendere dal puntatore mutabile della QA. I soli merge storici già
appartenenti al main fisso `2ee298957c3e1733b01a4b4aca4b48b890032f69` possono usare un
cutover finito registrato dal writer fidato dopo verifica dei veri merge e dell'ancestry.
Quel cutover non autorizza nuovi merge, non inventa QA storiche e non rimuove hold, native
review, controlli provider o protezioni della sorgente. Prima del rollout il coordinatore deve
registrare una prova fresca dell'assenza di vecchi handback globali: non viene migrata una
struttura ipotetica né allentata la validazione stretta del takeover.
