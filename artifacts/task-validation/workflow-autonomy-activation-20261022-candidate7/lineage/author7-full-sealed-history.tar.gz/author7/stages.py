from pathlib import Path
D=Path('/tmp/clinicos-autonomy-activation-20261022/source7/agent-team/src/bug-pipeline')
p=D/'workspace.mjs';s=p.read_text();s=s.replace("import { mkdir, readFile, writeFile, lstat, realpath, rm }", "import { mkdir, readFile, writeFile, lstat, realpath, rm }")
needle='  return {\n    root,\n'
methods='''  async function captureCheckpoint(batch) {
    const {cwd}=coordinates(batch);
    const entries=(await git(['worktree','list','--porcelain'])).split('\\n\\n');
    const registered=entries.find(e=>e.split('\\n').includes(`worktree ${cwd}`));
    if(!registered?.split('\\n').includes(`branch refs/heads/${batch.branch}`))
      throw new Error('Controller checkpoint requires the registered owned worktree');
    if((await realpath(cwd))!==cwd || (await lstat(cwd)).isSymbolicLink())
      throw new Error('Controller worktree identity changed');
    await assertScope(batch);
    const files=[...new Set([...(await git(['diff','--name-only',batch.baseSha],cwd)).split('\\n'),
      ...(await git(['ls-files','--others','--exclude-standard'],cwd)).split('\\n')].filter(Boolean))].sort();
    const output={};
    for(const file of files){
      relativeFile(file);
      const info=await lstat(path.join(cwd,file)).catch(e=>e.code==='ENOENT'?null:Promise.reject(e));
      if(!info){output[file]=null;continue;}
      const {target}=await regularFile(cwd,file);
      output[file]={sha256:sha256(await readFile(target)),bytes:info.size,executable:Boolean(info.mode&0o111)};
    }
    return {schemaVersion:1,cwd,branch:batch.branch,head:await git(['rev-parse','HEAD'],cwd),
      baseSha:batch.baseSha,planSha256:sha256(JSON.stringify(batch.plan)),
      packetHashes:structuredClone(batch.packetHashes),output};
  }
  return {
    root,
    captureCheckpoint,
    async resume(batch, checkpoint) {
      if(!checkpoint || checkpoint.schemaVersion!==1 ||
        JSON.stringify(await captureCheckpoint(batch))!==JSON.stringify(checkpoint))
        throw new Error('Exact retained controller checkpoint is missing or changed; no model replay');
    },
'''
assert needle in s;s=s.replace(needle,methods,1)
s+='''
// A finite implementation journal records completed operations, never their replay.
// Only a trusted explicit recovery can re-enter an interrupted attempt, and only
// while its exact registered worktree/output checkpoint remains available.
export async function runImplementationStages({batch,workspace,save,context}) {
  const steps=['execute','verify-before','simplify','verify-after','qa','checkpoint','publish'];
  let progress=batch.controllerProgress;
  if(progress?.status==='interrupted') {
    if(!progress.resumeAuthorization || progress.flow!==context.phase || progress.round!==context.round ||
      progress.feedbackSha256!==sha256(JSON.stringify(context.feedback??null)) ||
      progress.planSha256!==sha256(JSON.stringify(batch.plan)))
      throw new Error('Implementation recovery identity changed');
    if(typeof workspace.resume!=='function')throw new Error('Retained controller worktree verifier unavailable');
    await workspace.resume(batch,progress.checkpoint);
    progress.status='running';
  } else {
    if(progress?.status==='running')throw new Error('Unknown implementation outcome requires explicit recovery');
    progress=batch.controllerProgress={schemaVersion:1,flow:context.phase,round:context.round,
      sourceSha:batch.sha??null,planSha256:sha256(JSON.stringify(batch.plan)),
      feedbackSha256:sha256(JSON.stringify(context.feedback??null)),status:'running',next:0,completed:[]};
    if(typeof workspace.captureCheckpoint==='function')progress.checkpoint=await workspace.captureCheckpoint(batch);
  }
  for(let index=progress.next;index<steps.length;index++) {
    const step=steps[index];
    batch.phase=step==='execute'?'implementing':step==='simplify'?'simplifying':
      ['checkpoint','publish'].includes(step)?'publishing':'validating';
    progress.pending=step;
    await save();
    let result;
    if(step==='execute') {
      result=await workspace.execute(batch,context);
      if(result?.status!=='implemented')throw new Error('Executor blocked');
    } else if(step==='simplify') {
      result=await workspace.simplify(batch);
      if(result?.status!=='implemented')throw new Error('Simplification blocked');
    } else if(step==='qa') {
      result=await workspace.qa(batch);
      if(result?.status!=='verified')throw new Error('Independent QA blocked');
    } else if(step==='checkpoint') {
      result=await workspace.checkpoint(batch);batch.sha=result;
    } else if(step==='publish') await workspace.publish(batch);
    else await workspace.verify(batch);
    progress.completed.push({step,...(step==='checkpoint'?{sha:result}:{})});
    progress.next=index+1;delete progress.pending;
    if(typeof workspace.captureCheckpoint==='function')progress.checkpoint=await workspace.captureCheckpoint(batch);
    await save();
  }
  progress.status='completed';delete progress.resumeAuthorization;
  await save();
}
'''
p.write_text(s)
# pipeline boundaries and sequence reuse
p=D/'pipeline.mjs';s=p.read_text();s=s.replace("import { externalReviewStep }", "import { runImplementationStages } from './workspace.mjs';\nimport { externalReviewStep }")
old='''    const observed = validateState(
      (await (store.observe ? store.observe() : store.load())) ?? {
        schemaVersion: 1,
        repository: repo,
        batches: [],
      },
      repo,
    );'''
new='''    let raw;
    try { raw=await(store.observe?store.observe():store.load()); }
    catch(error){
      if(isRetryableGitHubFailure(error))throw Object.assign(new Error('Fresh ownership observation unavailable before operation'),
        {code:'ownership-observation-failed',beforeInvocation:true,cause:error});
      throw error;
    }
    const observed=validateState(raw??{schemaVersion:1,repository:repo,batches:[]},repo);'''
assert old in s;s=s.replace(old,new)
s=s.replace("if (error?.code !== 'review-operator-owned') persistenceFailed = true;", "if (!['review-operator-owned','ownership-observation-failed'].includes(error?.code)) persistenceFailed = true;")
s=s.replace("    'prepare',", "    'prepare',\n    'resume',",1)
needle='''  const guarded = (target, methods) =>'''
pause='''  const pauseObservation = async(batch,error)=>{
    if(persistenceFailed || error?.code!=='ownership-observation-failed')return false;
    const progress=batch.controllerProgress;
    if(progress?.status==='running')progress.status='interrupted';
    batch.controllerInterruption={schemaVersion:1,code:'ownership-observation-failed',
      beforeInvocation:true,subjectSha:batch.sha??null,
      progressSha256:sha256(JSON.stringify(progress??null)),at:new Date(now()).toISOString()};
    batch.failureCode='github-read-transient';batch.phase='blocked';delete batch.approvedSha;
    // If persistence remains unavailable this throws, retaining the last genuine
    // reservation. No durable diagnostic or completed operation is fabricated.
    await save();return true;
  };
'''
s=s.replace(needle,pause+needle)
s=s.replace("validateState, feedbackFingerprint }", "validateState, feedbackFingerprint, sha256 }")
# catch external typed pause before block
s=s.replace("          if (await recoverOwnership(error)) continue;\n          if (persistenceFailed)","          if (await recoverOwnership(error)) continue;\n          if (await pauseObservation(batch,error)) continue;\n          if (persistenceFailed)",1)
# runningprogress explicit permission
s=s.replace("      if (\n        activeImplementation(batch) ||", "      const resuming=batch.controllerProgress?.status==='interrupted' && Boolean(batch.controllerProgress.resumeAuthorization);\n      if (!resuming && (\n        activeImplementation(batch) ||",1)
s=s.replace("          batch.phase,\n        )\n      ) {", "          batch.phase,\n        )\n      )) {",1)
s=s.replace("      await workspace.prepare(batch);", "      if(!resuming)await workspace.prepare(batch);",1)
# initial block replace
start=s.index('      if (!batch.sha) {'); end=s.index("        batch.pr = await gh.createDraft",start)
s=s[:start]+'''      if (!batch.sha || (resuming && batch.controllerProgress.flow==='implementation')) {
        let passed = false;
        while ((resuming && activeImplementation(batch)) || spentAttempts(batch, 'implementation') < attemptLimit(batch, 'implementation')) {
          const attempt=(resuming&&activeImplementation(batch))||reserveImplementation(batch,()=>new Date(now()));
          try {
            await runImplementationStages({batch,workspace,save,context:{phase:'implementation',
              round:attempt.round,feedback:batch.lastFailure??null}});
            attempt.status='passed';passed=true;break;
          } catch(error) {
            if(persistenceFailed || ['review-operator-owned','ownership-observation-failed'].includes(error?.code))throw error;
            attempt.status='failed';
            if(batch.controllerProgress)batch.controllerProgress.status='failed';
            batch.lastFailure='Implementation or required verification failed; inspect current local test-results.';
            batch.phase='planned';await save();
          }
        }
        if(!passed){await block(batch,'Implementation allowance exhausted');continue;}
''' +s[end:]
# feedback block replace inline stages
start=s.index("        batch.phase = 'implementing';",s.index('// New PR feedback'))
end=s.index('        await report(batch, await workspace.issueEvidence(batch));',start)
s=s[:start]+'''        await runImplementationStages({batch,workspace,save,context:{phase:'pr-feedback',
          round:batch.reviews.length+1,feedback}});
'''+s[end:]
# reviewcorrection replace
start=s.index("        batch.phase = 'implementing';",s.index("Claude review remains blocked"))
end=s.index('        batch.approvedSha = null;',start)
s=s[:start]+'''        await runImplementationStages({batch,workspace,save,context:{phase:'review-correction',
          round:attempt.round,feedback:{claude:review,github:after}}});
'''+s[end:]
# outerpause beforemarkfail
s=s.replace("      if (await recoverOwnership(error)) continue;\n      if (persistenceFailed) throw error;", "      if (await recoverOwnership(error)) continue;\n      if (await pauseObservation(batch,error)) continue;\n      if (persistenceFailed) throw error;",1)
p.write_text(s)
# add progress to auth binding
p=D/'operator-authorization.mjs';s=p.read_text().replace('controllerInterruption:subject.controllerInterruption??null,','controllerInterruption:subject.controllerInterruption??null, controllerProgress:subject.controllerProgress??null,');p.write_text(s)
