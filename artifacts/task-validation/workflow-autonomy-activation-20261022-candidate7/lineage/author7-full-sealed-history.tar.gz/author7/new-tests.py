from pathlib import Path
T=Path('/tmp/clinicos-autonomy-activation-20261022/source7/agent-team/tests/bug-pipeline')
p=T/'github.test.mjs';s=p.read_text().replace("{ ok: false, code: 1, stderr: refusal, error: 'spawn-failed' },\n      'github-write-uncertain',\n      'unknown',", "{ ok: false, code: 1, stderr: refusal, error: 'spawn-failed' },\n      'github-write-uncertain',\n      'spawn-failed',")
s+='''
test('Author7 F3 observer reads authenticated Contents without branch creation and caches only unchanged identity',async()=>{
  let state={schemaVersion:1,repository:'l2v-hub/ClinicOS',batches:[],retained:'x'.repeat(1024*1024+1)}, blobs=0;
  const calls=[];
  const gh=createGitHub({repo:'l2v-hub/ClinicOS',cwd:'/synthetic',run:async call=>{
    calls.push(call);const endpoint=call.args[1];
    assert.ok(!endpoint.includes('/git/ref/')&&!call.args.includes('POST'),'Read-only observation never ensures/creates the branch');
    const contents=stateContents(state);
    if(endpoint.includes('/git/blobs/')){blobs++;return response({...contents,encoding:'base64'});}
    return response({...contents,encoding:'none',content:''});
  }});
  const store=gh.createStateStore();
  assert.deepEqual(await store.observe(),state);assert.equal(blobs,1);
  const copy=await store.observe();copy.retained='local-only';assert.equal(blobs,1);
  assert.equal((await store.observe()).retained,state.retained);
  state.note='fresh owner';assert.equal((await store.observe()).note,'fresh owner');assert.equal(blobs,2);
  assert.equal(calls.filter(c=>c.args[1].includes('/contents/')).length,4);
});
'''
p.write_text(s)
p=T/'workspace.test.mjs';s=p.read_text();s+='''
test('Author7 F3 retained controller checkpoint accepts exact dirty output and rejects changed, unknown, frozen or lost output',async t=>{
  const {root}=await gitFixture(t), plan=implementationPlan([17]);
  const batch={id:'bug-batch-17',branch:'codex/bug-batch-17',issues:[17],plan,implementation:[],reviews:[],sha:null};
  const workspace=createWorkspace({root,repo:'l2v-hub/ClinicOS',run:safeGitRunner,models:{}});
  await workspace.prepare(batch);
  const cwd=path.join(root,'agent-team/.worktrees',batch.id), file=path.join(cwd,plan.scope[0]);
  await writeFile(file,'export const filter="controller output";\\n');
  const checkpoint=await workspace.captureCheckpoint(batch);
  await workspace.resume(batch,checkpoint);
  await assert.rejects(workspace.prepare(batch),/clean expected batch/,'Ordinary prepare still rejects dirty output');
  await writeFile(file,'export const filter="foreign dirt";\\n');
  await assert.rejects(workspace.resume(batch,checkpoint),/missing or changed/);
  await writeFile(file,'export const filter="controller output";\\n');
  const unknown=path.join(cwd,'foreign.ts');await writeFile(unknown,'foreign');
  await assert.rejects(workspace.resume(batch,checkpoint),/outside accepted/);await rm(unknown);
  const frozen=path.join(cwd,'artifacts/task-validation',batch.id,'implementation-plan.md');
  await writeFile(frozen,'changed frozen plan');
  await assert.rejects(workspace.resume(batch,checkpoint),/frozen contract or plan/);
  await rm(cwd,{recursive:true,force:true});
  await assert.rejects(workspace.resume(batch,checkpoint));
});
''';p.write_text(s)
p=T/'comment-review-handoff.test.mjs';s=p.read_text();s+='''
async function author7ApprovedFixture(options={}){
  const f=fixture(options);f.setPermission('maintain');const b=f.remote.batches[0];
  const fingerprint=feedbackFingerprint(await f.github.reviewFeedback(81));
  const report=JSON.stringify({subject_sha:b.sha,verdict:'approved',summary:'Synthetic approved',findings:[]});
  b.reviews=[{round:1,status:'approved',subjectSha:b.sha}];
  b.reviewLedger={rounds:[{round:1,verdict:'approved',subject_sha:b.sha,review_sha256:createHash('sha256').update(report).digest('hex')}]};
  b.reviewReports={'claude-review-1.json':report};
  b.phase='blocked';b.externalReview={status:'published',subjectSha:b.sha,feedbackFingerprint:fingerprint};
  return {f,b,fingerprint};
}
function author7QaArgs(f,model){
  const batch=clone(f.remote.batches[0]);
  return {repo,batch,gh:f.github,communication:{mirrorFeedback:async()=>{},publishState:async()=>{}},
    workspace:{prepare:async()=>{},finalQa:model,execute:async()=>assert.fail('No implementation')},
    save:async()=>{const store=f.github.createStateStore(),state=await store.load();state.batches[0]=clone(batch);await store.save(state);},
    block:async reason=>{batch.phase='blocked';batch.reason=reason;const store=f.github.createStateStore(),state=await store.load();state.batches[0]=clone(batch);await store.save(state);},report:async()=>{}};
}
test('Author7 F1 exhausted allowance requires exact trusted one-unit grant and actually runs only one additional QA',async()=>{
  const {f,b,fingerprint}=await author7ApprovedFixture();
  const original=Array.from({length:3},(_,i)=>({status:'failed',subjectSha:b.sha,claudeRound:1,feedbackFingerprint:fingerprint,
    nonce:`spent-${i}`,reservedAt:'2026-10-17T00:00:00.000Z'}));
  b.qaHistory=clone(original);b.codexFinalReview={subjectSha:b.sha,claudeRound:1,feedbackFingerprint:fingerprint,status:'blocked',failureCode:'final-qa-infrastructure-exhausted'};
  const opts={action:'extend-final-qa',expectedSha:b.sha,token:undefined,reason:'One actual trusted recovery unit',authorizationRef:'test:qa-grant'};
  const {historyDigest}=await import('../../src/bug-pipeline/attempt-budget.mjs');opts.token=historyDigest(b.codexFinalReview);
  await assert.rejects(f.handoff.recover(81,{...opts,expectedSha:'b'.repeat(40)}),/durable subject SHA/);
  await f.handoff.recover(81,opts);
  assert.equal(f.remote.batches[0].finalQaAllowances.length,1);assert.equal(f.remote.batches[0].finalQaAllowances[0].limit,4);
  assert.deepEqual(f.remote.batches[0].qaHistory.slice(0,3),original);
  let qa=0;await assert.rejects(externalReviewStep(author7QaArgs(f,async()=>{qa++;throw Error('synthetic inference outage');})),/synthetic inference outage/);
  let current=f.remote.batches[0];
  await f.handoff.recover(81,{action:'release-qa-reservation',expectedSha:b.sha,token:current.codexFinalReview.nonce,
    reason:'Preserve actual failed unit',authorizationRef:'test:release-unit'});
  await externalReviewStep(author7QaArgs(f,async()=>{qa++;return {status:'verified',summary:'must not run'};}));
  assert.equal(qa,1);assert.equal(f.remote.batches[0].codexFinalReview.failureCode,'final-qa-infrastructure-exhausted');
  assert.equal(f.remote.batches[0].implementation.length,1);
  await assert.rejects(f.handoff.recover(81,opts),/identity changed/);
});
test('Author7 F1 malformed modern history is not legacy; trusted recovery seals spent allowance before one-unit extension',async()=>{
  const {f,b,fingerprint}=await author7ApprovedFixture();
  const malformed={subjectSha:b.sha,claudeRound:1,status:'failed',summary:'Modern missing nonce',feedbackFingerprint:fingerprint};
  b.qaHistory=[clone(malformed)];b.codexFinalReview={subjectSha:b.sha,claudeRound:1,feedbackFingerprint:fingerprint,status:'blocked'};
  const {historyDigest}=await import('../../src/bug-pipeline/attempt-budget.mjs');
  const recover=()=>f.handoff.recover(81,{action:'recover-final-qa',expectedSha:b.sha,
    token:historyDigest(f.remote.batches[0].codexFinalReview??null),reason:'Actual trusted exact ambiguous history recovery',authorizationRef:'test:seal-ambiguous'});
  await recover();assert.equal(f.remote.batches[0].finalQaHistoryResolutions[0].sealedLimit,3);
  let qa=0;await externalReviewStep(author7QaArgs(f,async()=>{qa++;return {status:'verified',summary:'No free retry'};}));
  assert.equal(qa,0);assert.deepEqual(f.remote.batches[0].qaHistory[0],malformed);
  const current=f.remote.batches[0];
  await f.handoff.recover(81,{action:'extend-final-qa',expectedSha:b.sha,token:historyDigest(current.codexFinalReview),
    reason:'One new unit after honest history seal',authorizationRef:'test:new-unit'});
  await externalReviewStep(author7QaArgs(f,async()=>{qa++;return {status:'verified',summary:'New authorized exact unit'};}));
  assert.equal(qa,1);assert.equal(f.remote.batches[0].phase,'ready');
});
test('Author7 F1 blocked pre-QA recovery actually progresses and no default verifier grants it',async()=>{
  for(const allowed of[false,true]){
    const {f,b,fingerprint}=await author7ApprovedFixture({authorizationVerifier:allowed});
    b.codexFinalReview={subjectSha:b.sha,claudeRound:1,feedbackFingerprint:fingerprint,status:'blocked'};
    const {historyDigest}=await import('../../src/bug-pipeline/attempt-budget.mjs');
    const op=f.handoff.recover(81,{action:'recover-final-qa',expectedSha:b.sha,token:historyDigest(b.codexFinalReview),
      reason:'Pre-inference identity recovered',authorizationRef:'test:preqa'});
    if(!allowed){await assert.rejects(op,/verifier unavailable/);continue;}
    await op;let calls=0;await externalReviewStep(author7QaArgs(f,async()=>{calls++;return {status:'verified',summary:'Actual recovered QA'};}));
    assert.equal(calls,1);assert.equal(f.remote.batches[0].phase,'ready');
  }
});
''';p.write_text(s)
