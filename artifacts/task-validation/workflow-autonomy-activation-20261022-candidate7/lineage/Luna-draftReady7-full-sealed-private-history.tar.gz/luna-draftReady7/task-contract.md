# Task Contract

## Impact Classification
Small delegated implementation7 child, gpt6-luna, actual user requested smaller executors when scoped. Fix ONLY peerF5 draftReady ownershipguard. Parent senior6.1 reviews/applies privatepatch later; you never edit shared source7. Root reserves this session before invocation, one parent implementation7 allowance, no native review/approval.

## Current Behaviour
Frozen source6 code992496727d31761bbece1262603d20e8cda447d7 equals publishedc172 outsideartifacts. Fullsource/tmp/clinicos-autonomy-activation-20261022/source6, manifest/tmp/clinicos-autonomy-activation-20261022/source6-frozen-snapshot-manifest.json. Actualpeercomment6355322575 F5: external-review.mjs invokes gh.draftReady after correction, but pipeline.mjs guarded mutator list omits it. A takeover before that call permits the actual PRwrite, with only later save noticing ownership. Parent main source7 identicalinitial snapshot and must remain untouched by you. Currentnativebudget7alreadyverified after6 prioractualnativeimplementations; same attempt7 contains this child.

## Expected Behaviour
Add draftReady to existing fresh automatic GitHub mutation guard list, preserving non-automatic explicit/manualbehavior and everyothergate/context. Create narrow negative+positive regression using ACTUAL exported runPipeline/realProxy path with injected boundary effects: Avalidtakeover observed beforedraftReady means real underlyingdraftReady calls0, Aremoteowneddata unchanged; aneligibleunowned case calls1. Do not copy controllerdecisionlogic as the test. Reusing actualpipeline harness/nativecases is preferred. If a fake externalstep triggers the true Proxy method, clearly state that seam and parentmustverify actualexternalcallsite too. No global monkeypatch/guard weakening, no sharedsourceedits.

## Acceptance Criteria
Causal pre-fix failure of the safety assertion beforeprivatefix (preservefirstlog), fixed narrow testsPASS and meaningful positiveunowned progress. Fix should be minimal (usually one guarded-methodname). Only2allowedshadowpaths differ, report allfailures/harnesscorrections, no assertionweakenings or tests thatpassbecauseallpaused. Senior—notyou—approves/applies. Other5peerfindings outofscope.

## Scope
Write ONLY/tmp/clinicos-autonomy-activation-20261022/luna-draftReady7. Make shadow fixturecopy of all138source6regularfiles within ownoutput (verifyhashes), declare node_modules symlink to/workspace/ClinicOS/node_modules; modifyONLYshadow copies ofagent-team/src/bug-pipeline/pipeline.mjs andagent-team/tests/bug-pipeline/pipeline.test.mjs. You may write own temporaryprobe/log/report/patch files under/tmp/clinicos-autonomy-activation-20261022/luna-draftReady7. Read immutable source6, relevantsealedQA6 and actualpeerreport. DO NOT edit source7/source6/author7, no Gitwrites/fetch/network/API/credentials/models/subagents/install/DB/browser/canonical/labels/deploy/issueclosure or HOME/home/CODEX_HOME repurpose. FixedNode22/tmp/clinicos-node22-native12/node_modules/node/bin/node. Tests synthetic/ownedTMPDIR perexistingfixtures.

## Test Plan
Baselinehash beforecopy; focusedcausalnewregression beforefix, then minimumaffectedpipeline tests afterfix (avoidfullunchangedclinical suites); exactcommands/exits/testcounts/harnessissues preserved. Check actualexternal-review draftReadycallsite read-only, but do not change it. Parent willcombine/test and rootindependentQA7/nativeCI/Claude/finalCodexremainfuture.

## Evidence Plan
Canonicalchildnonce beforethissession, rootreservation.json+thiscontracthash. patch.diff relativeto frozen source6ONLY2paths, results.json/report.md describing seam/firstfail/finalcounts, sourcebefore/sourceafter delta, STOP.json/seal.json files:{name:{sha256,bytes}} excludingownseal. statusimplemented-awaiting-senior-integration orblocked with actionablefinding. Do not selfapprove/publish/apply to source7. Freeze onceSTOP.

## Gate Status
READY FOR PRIVATE SHADOW IMPLEMENTATION ONLY
