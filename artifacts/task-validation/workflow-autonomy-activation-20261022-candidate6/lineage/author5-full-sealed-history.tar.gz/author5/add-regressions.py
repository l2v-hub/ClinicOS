from pathlib import Path
import re
p=Path('/tmp/clinicos-autonomy-activation-20261022');a=p/'author5';s=p/'source5'
chunks={}
chunks['operator-ownership']=r'''
test('Claude1 F1 stale nonce and missing audit cannot replay an old handback', () => {
  const takeover = { active: true, nonce: 'new-nonce', automation: {
    enabled: true, mode: 'new-unclaimed-only', protectedSubjects: [],
    takeoverNonce: 'old-nonce', authorizedActor: 'maintainer', handedBackAt: '2026-10-22T00:00:00Z',
  }};
  assert.equal(automationPaused({operatorTakeover: takeover}), true);
  takeover.automation.takeoverNonce = takeover.nonce;
  assert.equal(automationPaused({operatorTakeover: takeover}), false);
  for (const field of ['takeoverNonce', 'authorizedActor', 'handedBackAt']) {
    const invalid = structuredClone(takeover); delete invalid.automation[field];
    assert.equal(automationPaused({operatorTakeover: invalid}), true);
  }
});
'''
chunks['release']=r'''
test('Claude1 F2 external release requires exact final Codex proof at selection and execution', async () => {
  for (const channel of ['github-comments', 'legacy-worker']) {
    for (const mismatch of ['missing', 'failed', 'subjectSha', 'reviewedSha', 'claudeRound', 'feedbackFingerprint']) {
      const f = fixture();
      f.batch.externalReview = {channel, status:'published', subjectSha:sha, feedbackFingerprint:f.batch.feedbackFingerprint};
      const proof = {status:'verified', subjectSha:sha, reviewedSha:sha, claudeRound:1, feedbackFingerprint:f.batch.feedbackFingerprint};
      if (mismatch !== 'missing') f.batch.codexFinalReview = {...proof, [mismatch === 'failed' ? 'status' : mismatch]: mismatch === 'claudeRound' ? 0 : 'stale'};
      assert.equal(selectAutoReleaseBatch(f.state), null, `${channel}:${mismatch}`);
      await assert.rejects(releaseBatch({repo:f.state.repository, github:f.github, store:f.store, batchId:f.batch.id, reviewedSha:sha, configured, execute:true}), /final Codex/i);
      assert.equal(f.calls.filter(([name]) => ['merge','ready','save'].includes(name)).length,0);
    }
  }
});
'''
chunks['external-review']=r'''
test('Claude1 F3 recovered infrastructure failure retries only final QA and preserves code budget', async () => {
  const {args,batch,log} = approvedExternalArgs();
  const prior = {status:'failed', subjectSha:batch.sha, claudeRound:1, feedbackFingerprint:batch.externalReview.feedbackFingerprint, nonce:'prior-failed', reservedAt:'2026-10-22T00:00:00Z'};
  batch.codexFinalReview = structuredClone(prior);
  args.workspace.execute = async () => assert.fail('infrastructure retry must not implement');
  await externalReviewStep(args);
  assert.equal(log.filter(x=>x==='qa').length,1);
  assert.equal(batch.phase,'ready');
  assert.equal(batch.implementation.length,1);
  assert.deepEqual(batch.codexFinalReviewHistory,[prior]);
});
'''
chunks['pipeline']=r'''
test('Claude1 F4 takeover during QA prevents every later internal publication path', async () => {
  for (const mode of ['initial', 'pr-feedback', 'review-correction']) {
    const b = batchFor({issues:[17], phase:'waiting-checks'});
    b.feedbackFingerprint = feedbackFingerprint(openFeedback(b));
    const h = harness({issues:[17], queue:[], initialState:mode==='initial'?blankState():{...blankState(),batches:[b]},
      reviews:mode==='review-correction'?[{verdict:'changes-requested',summary:'fix',findings:[{}]}]:[]});
    if(mode==='initial') h.gh.discoverQueue=async()=>[17];
    if(mode==='pr-feedback') h.gh.reviewFeedback=async()=>openFeedback(b,{comments:[{id:1,body:'Fix state',user:{login:'human'}}]});
    let observed=false, frozen, after=[];
    h.workspace.qa=async()=>{
      frozen=clone(h.stateRef.value.batches[0]);
      h.stateRef.value.operatorTakeover={active:true,nonce:'new-takeover'};
      observed=true;return {status:'verified'};
    };
    for(const name of ['publish','checkpoint']) h.workspace[name]=async()=>{if(observed)after.push(name);return sha('b');};
    for(const name of ['commentIssue','commentPR','setIssueStatus','createDraft']) {
      const old=h.gh[name];h.gh[name]=async(...args)=>{if(observed)after.push(name);return old(...args);};
    }
    const result=await h.run();
    assert.equal(observed,true,mode);
    assert.deepEqual(after,[],mode);
    assert.deepEqual(result.batches[0],frozen,mode);
    assert.deepEqual(h.stateRef.value.batches[0],frozen,mode);
  }
});

test('Claude1 F5 actual native409 partial handback skips A and completes B without overwriting A', async () => {
  const a=batchFor({issues:[17],phase:'waiting-checks'}), b=batchFor({issues:[18],phase:'waiting-checks'});
  for(const batch of [a,b]) batch.feedbackFingerprint=feedbackFingerprint(openFeedback(batch));
  const h=harness({issues:[17,18],queue:[],initialState:{...blankState(),batches:[a,b]}});
  let canonical=clone(h.stateRef.value), injected=false, frozenA, puts=0;
  const {createHash}=await import('node:crypto');
  const metadata=()=>{const bytes=Buffer.from(JSON.stringify(canonical));return {type:'file',encoding:'base64',size:bytes.length,content:bytes.toString('base64'),sha:createHash('sha1').update(`blob ${bytes.length}\0`).update(bytes).digest('hex')};};
  const response=(value,extra={})=>({ok:true,code:0,stdout:JSON.stringify(value),stderr:'',...extra});
  const native=createGitHub({cwd:'/tmp',repo,run:async({args,input})=>{
    if(args[1].includes('/git/ref/heads/'))return response({object:{sha:sha('a')}});
    if(args.includes('PUT')){
      puts++;const body=JSON.parse(input);const intended=JSON.parse(Buffer.from(body.content,'base64'));
      if(!injected && intended.batches[0].reviews.some(r=>r.status==='running')){
        injected=true;frozenA=clone(canonical.batches[0]);
        canonical.operatorTakeover={active:true,nonce:'takeover-1',automation:{enabled:true,mode:'new-unclaimed-only',takeoverNonce:'takeover-1',authorizedActor:'maintainer',handedBackAt:'2026-10-22T00:00:00Z',protectedSubjects:[{collection:'batches',id:a.id}]}};
      }
      if(body.sha!==metadata().sha)return response({}, {ok:false,code:1,stderr:'HTTP 409 conflict'});
      canonical=intended;return response({content:{sha:metadata().sha}});
    }
    if(args[1].includes('/contents/.codex-bug-state.json'))return response(metadata());
    assert.fail('unexpected native fixture request '+args[1]);
  }}).createStateStore();
  h.store.load=()=>native.load();h.store.save=(...args)=>native.save(...args);
  h.gh.reviewFeedback=async()=>openFeedback(canonical.batches.find(x=>x.id===h.currentId)??b);
  h.workspace.prepare=async(batch)=>{h.currentId=batch.id;};
  h.gh.reviewFeedback=async()=>openFeedback(canonical.batches.find(x=>x.id===h.currentId)??a);
  const reviewed=[];h.workspace.review=async(batch)=>{reviewed.push(batch.id);return {subject_sha:batch.sha,verdict:'approved',summary:'Synthetic approval',findings:[]};};
  const result=await h.run();
  assert.equal(injected,true);assert.ok(puts>=2);
  assert.deepEqual(canonical.batches[0],frozenA);
  assert.deepEqual(result.batches[0],frozenA);
  assert.deepEqual(reviewed,[b.id]);assert.equal(result.batches[1].phase,'ready');
  assert.equal(h.log.some(x=>x==='gh.setIssueStatus:17:Bloccato'),false);
});
'''
for name,chunk in chunks.items():
 (a/f'regression-{name}.txt').write_text(chunk)
 original=(s/f'agent-team/tests/bug-pipeline/{name}.test.mjs').read_text()
 # Keep all original fixtures and test definitions; invoke only Claude1 test names.
 original=re.sub(r"(['\"])\.\./\.\./src/",lambda m:m.group(1)+str(p/'source4/agent-team/src')+'/',original)
 original=re.sub(r"(['\"])\.\./\.\./\.\./scripts/",lambda m:m.group(1)+str(p/'source4/scripts')+'/',original)
 (a/f'prechange-{name}.test.mjs').write_text(original+chunk)
