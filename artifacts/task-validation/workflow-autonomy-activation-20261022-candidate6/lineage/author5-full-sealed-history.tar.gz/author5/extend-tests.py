from pathlib import Path
s=Path('/tmp/clinicos-autonomy-activation-20261022/source5');prod=s/'agent-team/src/bug-pipeline';tests=s/'agent-team/tests/bug-pipeline'
f=prod/'release.mjs';t=f.read_text().replace("    proof.reviewedSha === sha && sha === batch.sha &&", "    sha === batch.sha &&");f.write_text(t)
f=prod/'external-review.mjs';t=f.read_text().replace('        prior.reviewedSha !== batch.sha ||\n','').replace('          reviewedSha: batch.sha,\n','');f.write_text(t)
f=tests/'release.test.mjs';t=f.read_text().replace("'subjectSha', 'reviewedSha', 'claudeRound'", "'subjectSha', 'claudeRound'").replace("subjectSha:sha, reviewedSha:sha, claudeRound", "subjectSha:sha, claudeRound");f.write_text(t)
f=tests/'pipeline.test.mjs';t=f.read_text();start=t.index("test('CAS ownership acquired on the current batch");end=t.index("test('successful triage CAS",start);old=t[start:end];old=old.replace("  await assert.rejects(h.run(), /Automatic ownership changed/);", "  const result = await h.run();\n  assert.deepEqual(result, remoteOwned);");t=t[:start]+old+t[end:];f.write_text(t)
f=tests/'issue-review-sync.test.mjs';t=f.read_text();start=t.index("test('malformed or disabled automation");end=t.index("test('released subjects",start);t=t[:start]+'''test('malformed handback is schema-rejected; absent and valid disabled grants remain paused', async () => {
  for (const automation of [undefined, {...newOnly().automation, enabled:false}, {},
    {enabled:true,mode:'all',protectedSubjects:[]}]) {
    const state={schemaVersion:1,repository:repo,batches:[syncBatch()],
      operatorTakeover:{active:true,nonce:'test-takeover',automation}};
    if (automation !== undefined && (!automation.takeoverNonce || automation.mode !== 'new-unclaimed-only'))
      await assert.rejects(observedSync(state), /invalid operator automation handback/);
    else {
      const {result,calls}=await observedSync(state);
      assert.deepEqual(calls,[]);assert.equal(result.status,'skipped');
    }
  }
});

'''+t[end:];f.write_text(t)
def append(name,text):
 f=tests/(name+'.test.mjs');f.write_text(f.read_text()+text)
append('contracts',r'''
test('Claude1 F1 canonical handback schema preserves legacy/stale grants but rejects malformed audit', () => {
  const state = {schemaVersion:1, repository:'l2v-hub/ClinicOS', batches:[], operatorTakeover:{active:true,nonce:'new'}};
  assert.equal(validateState(state,state.repository),state);
  const valid = {enabled:true,mode:'new-unclaimed-only',takeoverNonce:'old',authorizedActor:'maintainer',handedBackAt:'2026-10-22T00:00:00Z',protectedSubjects:[]};
  state.operatorTakeover.automation=valid;
  assert.equal(validateState(state,state.repository),state,'stale identity is valid data, but never grants authority');
  for (const patch of [{takeoverNonce:''},{authorizedActor:' '},{handedBackAt:'2026-02-30T00:00:00Z'},{handedBackAt:'yesterday'},{protectedSubjects:[{collection:'unknown',id:'x'}]},{enabled:'true'}]) {
    state.operatorTakeover.automation={...valid,...patch};
    assert.throws(()=>validateState(state,state.repository),/invalid operator automation handback/);
  }
});
''')
append('pipeline',r'''
test('Claude1 F1 stale canonical handback pauses before intake, selection or any mutation', async () => {
  const state={...blankState(),operatorTakeover:takeoverHandback()};
  state.operatorTakeover.nonce='next-takeover';
  const h=harness({initialState:state});
  assert.deepEqual(await h.run(),state);
  assert.deepEqual(h.log,['store.load']);assert.equal(h.counts.plan,0);
});
''')
append('github',r'''
test('Claude1 F5 read-only observation never promotes a writer base or bypasses native409', async () => {
  const f=stateBlobFixture(entityState());
  const ours=await f.store.load();ours.batches[0].local='pending';
  const remote=entityState();remote.batches[1].remote='preserved';f.setRaw(Buffer.from(JSON.stringify(remote)));
  assert.equal((await f.store.observe()).batches[1].remote,'preserved');
  await f.store.save(ours,{rebaseIndependentSubjects:entityValidator});
  assert.equal(f.writes.length,2,'old writer SHA must receive native409 before rebase');
  assert.notEqual(f.writes[0].sha,f.writes[1].sha);
  const actual=await f.store.load();assert.equal(actual.batches[1].remote,'preserved');assert.equal(actual.batches[0].local,'pending');
});

test('Claude1 F5 native state store preserves finite ownership code instead of generic rebase error', async () => {
  const f=stateBlobFixture(entityState());const ours=await f.store.load();ours.batches[0].local=true;
  const remote=entityState();remote.operatorTakeover={active:true};f.setRaw(Buffer.from(JSON.stringify(remote)));
  await assert.rejects(f.store.save(ours,{rebaseIndependentSubjects:state=>{
    if(state.operatorTakeover)throw Object.assign(new Error('observed ownership'),{code:'review-operator-owned'});
  }}),error=>error.code==='review-operator-owned');
  assert.equal(f.writes.length,1);assert.deepEqual(await f.store.load(),remote);
});
''')
append('release',r'''
function bindExternalFinalProof(f) {
  f.batch.externalReview={status:'published',subjectSha:sha,feedbackFingerprint:f.batch.feedbackFingerprint};
  f.batch.codexFinalReview={status:'verified',subjectSha:sha,claudeRound:f.batch.reviews.length,feedbackFingerprint:f.batch.feedbackFingerprint};
}
test('Claude1 F2 matching existing final proof merges with all prior gates; fresh proof drift refuses', async () => {
  const f=fixture();bindExternalFinalProof(f);
  assert.equal(selectAutoReleaseBatch(f.state),f.batch);
  const result=await releaseBatch({repo:f.state.repository,github:f.github,store:f.store,batchId:f.batch.id,reviewedSha:sha,configured,execute:true});
  assert.equal(result.status,'merged');assert.equal(f.calls.filter(([n])=>n==='merge').length,1);
  const stale=fixture();bindExternalFinalProof(stale);const load=stale.store.load;let reads=0;
  stale.store.load=async()=>{const state=await load();if(++reads>=2)state.batches[0].codexFinalReview.feedbackFingerprint='stale';return state;};
  await assert.rejects(releaseBatch({repo:stale.state.repository,github:stale.github,store:stale.store,batchId:stale.batch.id,reviewedSha:sha,configured,execute:true}),/final Codex/i);
  assert.equal(stale.calls.filter(([n])=>['merge','ready','save'].includes(n)).length,0);
});
test('Claude1 F2 deployment recording cannot bypass missing final proof on an external candidate', async () => {
  const f=fixture();bindExternalFinalProof(f);delete f.batch.codexFinalReview;
  f.batch.release={status:'merged',mergeSha,reviewedSha:sha};
  await assert.rejects(recordDeployment({repo:f.state.repository,github:f.github,store:f.store,batchId:f.batch.id,mergeSha,configured}),/final Codex/i);
  assert.equal(f.calls.length,0);
});
''')
append('external-review',r'''
test('Claude1 F3 final-QA inference retries are durably bounded independently of implementation', async () => {
  const {args,batch,log}=approvedExternalArgs();
  const before=structuredClone(batch.implementation);
  let calls=0;args.workspace.finalQa=async()=>{calls++;throw new Error('bounded infrastructure outage');};
  args.workspace.execute=async()=>assert.fail('infrastructure never implements');
  for(let n=0;n<3;n++) {
    batch.phase='waiting-review'; // Explicit operator recovery, never an automatic unblock.
    await assert.rejects(externalReviewStep(args),/bounded infrastructure outage/);
    assert.equal(batch.codexFinalQaInfrastructure.attempts.length,n+1);
    assert.ok(batch.codexFinalQaInfrastructure.attempts.every(x=>x.status==='failed'));
  }
  batch.phase='waiting-review';await externalReviewStep(args);
  assert.equal(calls,3);assert.equal(batch.codexFinalReview.failureCode,'final-qa-infrastructure-exhausted');
  assert.equal(batch.phase,'blocked');assert.deepEqual(batch.implementation,before);
  const history=structuredClone(batch.codexFinalReviewHistory);
  await externalReviewStep(args);assert.equal(calls,3);assert.deepEqual(batch.codexFinalReviewHistory,history);
  assert.equal(log.includes('correction'),false);
});
test('Claude1 F3 waiting checks and pre-inference identity polling spend no infrastructure inference slots', async () => {
  const {args,batch,log}=approvedExternalArgs();let waiting=true;
  args.workspace.prepare=async()=>{};
  let checks=0;args.gh.requiredChecks=async()=>({ok:++checks%2===1 || !waiting});
  for(let n=0;n<5;n++) {await externalReviewStep(args);assert.equal(batch.codexFinalReview.status,'waiting-checks');}
  assert.equal(batch.codexFinalQaInfrastructure,undefined);assert.equal(log.includes('qa'),false);
  waiting=false;await externalReviewStep(args);
  assert.equal(batch.phase,'ready');assert.equal(batch.codexFinalQaInfrastructure.attempts.length,1);
});
test('Claude1 F3 unusable final QA verdict is infrastructure failure and never a code correction', async () => {
  const {args,batch}=approvedExternalArgs();args.workspace.finalQa=async()=>({status:'unavailable'});
  args.workspace.execute=async()=>assert.fail('unavailable verdict must not implement');
  await assert.rejects(externalReviewStep(args),/no usable verdict/);
  assert.equal(batch.codexFinalReview.status,'failed');assert.equal(batch.implementation.length,1);
});
''')
