from pathlib import Path
p=Path('/tmp/clinicos-autonomy-activation-20261022/source5/agent-team/src/bug-pipeline')
f=p/'github.mjs';t=f.read_text().replace('return { load, save };', '''// Fresh ownership observations never promote this writer's expected Contents
    // SHA or base snapshot. A later save must still reconcile a real remote CAS.
    return { load, save, observe: () => createStateStore().load() };''',1);f.write_text(t)
f=p/'pipeline.mjs';t=f.read_text();t=t.replace('''  let persistenceFailed = false;
  const save''','''  let persistenceFailed = false;
  const ownershipLost = () => Object.assign(
    new Error('Automatic ownership changed during state reconciliation'),
    { code: 'review-operator-owned' },
  );
  const assertOwnership = (observed) => {
    if (automationPaused(observed) || (processingSubject && operatorOwns(
      observed, processingSubject.collection,
      observed[processingSubject.collection]?.find(item => item.id === processingSubject.id) ?? processingSubject,
    ))) throw ownershipLost();
  };
  const freshOwnership = async () => {
    const observed = validateState(
      (await (store.observe ? store.observe() : store.load())) ??
        { schemaVersion: 1, repository: repo, batches: [] }, repo,
    );
    if (observed.standaloneReviews) validateStandaloneState(observed);
    assertOwnership(observed);
  };
  const recoverOwnership = async (error) => {
    if (persistenceFailed || error?.code !== 'review-operator-owned') return false;
    // Discard unsaved work only for the finite, observed ownership-loss code.
    // Uncertain writes and genuine CAS/integrity failures still halt the pass.
    state = validateState(await store.load(), repo);
    if (state.standaloneReviews) validateStandaloneState(state);
    return true;
  };
  const guarded = (target, methods) => new Proxy(target, {
    get(object, key) {
      const value = object[key];
      if (!methods.includes(key) || typeof value !== 'function') return value;
      return async (...args) => { await freshOwnership(); return value.apply(object, args); };
    },
  });
  // Every asynchronous model/effect boundary re-reads ownership, including internal
  // feedback/review correction paths and prebuilt workspace implementations.
  workspace = guarded(workspace, ['prepare', 'execute', 'verify', 'simplify', 'qa', 'finalQa',
    'checkpoint', 'publish', 'review', 'issueEvidence']);
  gh = guarded(gh, ['intake', 'discoverQueue', 'setIssueStatus', 'commentIssue', 'commentPR', 'createDraft']);
  const save''');start=t.index('''          if (
            automationPaused(merged)''');end=t.index("throw new Error('Automatic ownership changed during state reconciliation');",start)+len("throw new Error('Automatic ownership changed during state reconciliation');");t=t[:start]+'          assertOwnership(merged);'+t[end:]
t=t.replace('''    try {
      if (state.standaloneReviews)''','''    try {
      await freshOwnership();
      if (state.standaloneReviews)''',1).replace('''    } catch (error) {
      persistenceFailed = true;
      throw error;
    }
  };''','''    } catch (error) {
      if (error?.code !== 'review-operator-owned') persistenceFailed = true;
      throw error;
    }
  };''',1)
t=t.replace('''  const report = async (batch, text) => {
    for''','''  const report = async (batch, text) => {
    await freshOwnership();
    for''',1).replace('''  const block = async (batch, reason) => {
    batch.phase''','''  const block = async (batch, reason) => {
    await freshOwnership();
    batch.phase''',1)
t=t.replace('''  for (const batch of state.batches) {
    if (operatorOwns(state, 'batches', batch) || batch.release?.status === 'deployed') continue;
    const status''','''  for (const id of state.batches.map(batch => batch.id)) {
    const batch = state.batches.find(batch => batch.id === id);
    if (operatorOwns(state, 'batches', batch) || batch.release?.status === 'deployed') continue;
    processingSubject = { collection: 'batches', id };
    const status''',1).replace('''    for (const number of batch.issues) await gh.setIssueStatus(number, status);
  }
  const queue''','''    try { for (const number of batch.issues) await gh.setIssueStatus(number, status); }
    catch (error) { if (!(await recoverOwnership(error))) throw error; }
  }
  processingSubject = null;
  if (automationPaused(state)) return state;
  const queue''',1)
t=t.replace('''  for (const batch of state.batches) {
    if (operatorOwns(state, 'batches', batch)) continue;''','''  for (const id of state.batches.map(batch => batch.id)) {
    const batch = state.batches.find(batch => batch.id === id);
    if (!batch || operatorOwns(state, 'batches', batch)) continue;''',1)
t=t.replace("    processingSubject = { collection: 'batches', id: batch.id };\n    if (['merged'", "    processingSubject = { collection: 'batches', id: batch.id };\n    try {\n    if (['merged'",1)
t=t.replace('''      } catch (error) {
        if (persistenceFailed)
          throw new Error('External review''','''      } catch (error) {
        if (await recoverOwnership(error)) continue;
        if (persistenceFailed)
          throw new Error('External review''',1)
t=t.replace('''    try {
      // Recheck every issue''','''      // Recheck every issue''',1)
t=t.replace('''            if (persistenceFailed) throw error;
            attempt.status''','''            if (persistenceFailed || error?.code === 'review-operator-owned') throw error;
            attempt.status''',1)
t=t.replace('''    } catch (error) {
      if (persistenceFailed) throw error;
      batch.failureCode''','''    } catch (error) {
      if (await recoverOwnership(error)) continue;
      if (persistenceFailed) throw error;
      batch.failureCode''',1)
# Ensure planner inference is covered even after lengthy intake reads.
t=t.replace('''    const plan = validatePlan(''','''    await freshOwnership();
    const plan = validatePlan(''',1)
f.write_text(t)
