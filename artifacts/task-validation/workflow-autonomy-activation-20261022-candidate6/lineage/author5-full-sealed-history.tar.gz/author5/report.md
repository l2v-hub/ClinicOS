# Source continuation5 — implemented, awaiting independent QA

All five authentic Claude1 findings on PR504 have source fixes and causal regressions. This is author evidence, not QA approval, model review approval, native adoption, merge, activation or deployment.

## Scope and lineage

The reserved source5 snapshot contains exactly138 files, initially byte-identical to immutable source4. All15 allowed paths changed; no other source bytes or Git executable modes differ and no extra source files appeared. Root-created source5 physical permissions0644 differ from source4 permissions0664, also on untouched files; no author chmod occurred. The initial full-mode equality bookkeeping assertion is preserved and was corrected to Git executable-mode comparison. Cumulative current code/test/docs scope is 22 paths. Parent source head remains ce7993a781bd2d378a1ca3ad2956b2c3606b4fe2 and code4 cb2d095926282918777b9dd73a37ef7d90bb7b2f; only root may create the descendant commit. The fourth native implementation passed result and actual Claude1 changes-requested remain historical facts. Root performed typed budget4→5 and the actual fifth reservation before this author session; no attempt, review ledger or grant was reset or invented here.

The first preflight found a mislabeled manifest digest. All138 source bytes matched source4; no source edit preceded correction. Root durably corrected raw versus semantic digest labels under the same attempt/nonce, preserving the original reservation. Both preflight receipts are retained.

## F1 — bound canonical handback

`operator-ownership.validAutomationHandback` checks the complete audit/schema; `automationPaused` also requires exact nonempty takeover nonce equality. The trusted canonical writer records authorizedActor after actual permission verification; this string does not itself authenticate anyone. UTC ISO timestamp validity rejects invalid calendar dates. `contracts.validateState` rejects malformed handbacks; legacy takeover without a handback and a well-formed stale grant remain readable, paused data. All former valid handback fixtures were bound explicitly. Tests cover stale nonce before intake/selection and zero mutation, valid grant unowned work, malformed audit, legacy pause and preserved claims.

## F2 — release final Codex gate

`release.hasFinalCodexProof` recognizes every external channel by the durable externalReview object and checks verified status, proof.subjectSha equal to supplied release reviewedSha and batch.sha, latest Claude round and current approved feedback identity. No new proof.reviewedSha field is required. Selection skips missing/stale proof; releaseBatch and verifyReviewProof refuse it; freshReleaseGuard rechecks before native effects; recordDeployment reaches the same review-proof gate. Existing internal mode needs no invented external proof. Tests exercise both comment and legacy external channels, missing/nonverified/SHA/round/fingerprint failure, matching proof actual merge, fresh proof drift zero effects and deployment recording refusal. Native/human/source/provider/SHA checks are unchanged.

## F3 — infrastructure retries separate from corrections

`external-review.runExternalReviewStep` archives failed/blocked/waiting-checks final records before retry. A separate durable codexFinalQaInfrastructure.attempts ledger permits at most3 reserved final-QA inference sessions for one SHA/Claude-round/feedback identity. Native-check and pre-inference identity polling reserve no inference slot. A legacy failed session is imported as already spent. Running remains owned. Blocked batch phase is never auto-unblocked; operator recovery must precede retry. Exhaustion blocks with final-qa-infrastructure-exhausted and retains records. Exceptions and unusable verdicts record failed infrastructure and never reserve code correction. A genuine model blocked-with-findings retains the existing mapping to changes-requested, which alone sends final-QA findings to reserveImplementation. All existing before/after PR identity, feedback and native checks remain. Tests show recovered failure invokes finalQa only, bounded repeated failures, explicit recovery, no implementation budget consumption, polling without inference consumption, invalid verdict refusal and real findings correction.

## F4 — fresh internal call boundaries

`pipeline.freshOwnership` re-reads current canonical ownership before save and each asynchronous workspace model/effect boundary (prepare, execute, verify, simplify, qa/finalQa, checkpoint, publish, review, evidence) and GitHub mutation boundary. This also covers prebuilt workspace implementations and each report/status effect. Initial implementation, PR feedback correction and internal Claude correction cannot checkpoint, push, createDraft, publish comments/status or diagnose/block an operator-owned subject after observing takeover. Canonical running reservations already durable stay as tombstones; unsaved completion/failure edits are discarded. Regression takeover occurs inside QA in all three real internal paths and checks exact unchanged canonical subject bytes with zero later effects. Existing AsyncLocalStorage native controller handling, concurrent/default explicit Max authorization and SHA rules remain unchanged and pass native compatibility tests.

## F5 — finite known CAS ownership loss

`github.createStateStore.observe()` uses an independent native state reader. It never advances the writer's remembered Contents SHA or base; the observer regression requires a real rejected409 followed by independently validated rebase and retains concurrent B data.

`save(...,{checkFreshOwnership})` optionally validates/checks freshly loaded canonical ownership only after a definite rejected409 and successful fresh load, before mergeIndependentEntities. Pipeline supplies full validateState/standalone validation then exact ownership. Typed review-operator-owned propagates unchanged, including the original merged validator path. All other merge/schema/auth/write failures retain their original fatal behavior. The hook never runs after403/502/timeout. Unowned same-entity A or B conflicts and malformed fresh state still fail.

Pipeline catches only the finite observed ownership-loss code without persistence failure, reloads canonical state, discards unsaved A changes and resolves subsequent subjects by identity. Native409 regressions cover both bound partial handback and takeover also changing A.operatorCoordination plus remote A data: A remains byte-identical and eligible B completes ready. No owned label, block or overwrite is issued. Global pause protects all. Generic conflicts or uncertain writes are not skips.

## Validation and preserved failures

Final affected7 suites:564/564 PASS. Final native compatibility4 suites:151/151 PASS. These are disjoint715 tests, not a count of repeated runs. Syntax13/13 PASS. Commands, exact exits/stdout and counts are retained. Earlier5 causal source failures, one reached-B fixture failure, two intentionally outdated expectations and the additional same-entity ownership causal failure remain in failure-history.json and raw logs. No unresolved author test failure remains.

Prior source4 QA/CI remains scoped historical evidence only; no clinical E2E or live provider test was repeated. All checks used injected offline boundaries; any fixture Git used only owned temporary paths, disabled hooks/global config and network protocols. No network/API/provider/model/credential/DB/browser/live Git/canonical mutation occurred. Independent QA, actual native/model review, protected publication and activation remain root-owned.
