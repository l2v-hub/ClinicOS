from pathlib import Path
import hashlib,json,re,difflib,stat,datetime
p=Path('/tmp/clinicos-autonomy-activation-20261022');a=p/'author5';s=p/'source5';b=p/'source4'
def digest(data):return hashlib.sha256(data).hexdigest()
def meta(path):
 data=path.read_bytes();return {'sha256':digest(data),'bytes':len(data)}
def write(name,value): (a/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
r=json.loads((a/'reservation.json').read_text());before=json.loads((p/'source5-before.json').read_text());allowed=json.loads((a/'allowlist.json').read_text());assert digest((a/'task-contract.md').read_bytes())==r['contractSha256'];assert digest((p/'source5-before.json').read_bytes())==r['snapshotSha256'];assert r['nonce']=='4b48cff3-a6d4-4727-99b8-e1cb237d0405';assert r['attempt']==5
changes=[];files={};patch=[]
for name,m in before.items():
 old=(b/name).read_bytes();new=(s/name).read_bytes();assert meta(b/name)==m,name
 assert stat.S_IMODE((b/name).stat().st_mode)==stat.S_IMODE((s/name).stat().st_mode),name
 files[name]={**meta(s/name),'mode':oct(stat.S_IMODE((s/name).stat().st_mode))}
 if old!=new:
  assert name in allowed,name;changes.append(name)
  patch.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
assert len(files)==138;assert len(changes)==15
previous=json.loads((p/'author4/source-manifest.json').read_text());cumulative=sorted(set([x['path'] for x in previous['files']]+changes))
manifest={'source':str(s),'attempt':5,'baseline':str(b),'publishedGitParent':r['sourceHead'],'previousCode':r['baselineCode'],'allowedPaths':allowed,'attemptDeltaPaths':changes,'cumulativePaths':len(cumulative),'cumulativeCodeAndTests':len([x for x in cumulative if x.endswith('.mjs')]),'docs':2,'baselineFiles':138,'outsideAttemptScopeUnchanged':True,'baselineSource4Immutable':True,'dependencySymlink':r['dependencyLink'],'files':[{'path':name,**files[name],'source4Sha256':before[name]['sha256'],'changedInAttempt5':name in changes} for name in cumulative]}
write('source-manifest.json',manifest);write('source-after-all.json',files);(a/'source.patch').write_text(''.join(patch))
for name in ['operator-ownership.mjs','contracts.mjs','pipeline.mjs','github.mjs','external-review.mjs','release.mjs']:
 path='agent-team/src/bug-pipeline/'+name
 (a/('diff-'+name+'.txt')).write_text(''.join(difflib.unified_diff((b/path).read_text().splitlines(True),(s/path).read_text().splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
# Actual captured Node summary counts, never inferred from test definitions.
runs={}
for label in ['prechange','causal-fixed','causal-fixed2','focused-first','focused-second','native-compatibility','same-entity-pre-fix','focused-final','native-compatibility-final']:
 log=(a/(label+'.log')).read_text();run=json.loads((a/(label+'.json')).read_text());run['counts']={key:int(re.search(r'^# '+key+r' (\d+)$',log,re.M).group(1)) for key in ['tests','pass','fail','cancelled','skipped','todo']};runs[label]=run
assert runs['focused-final']['counts']['tests']==564 and runs['focused-final']['counts']['fail']==0 and runs['focused-final']['exitCode']==0
assert runs['native-compatibility-final']['counts']['tests']==151 and runs['native-compatibility-final']['counts']['fail']==0 and runs['native-compatibility-final']['exitCode']==0
write('test-results.json',runs)
failures=[
 {'evidence':'preflight-initial.json','classification':'metadata binding failure','detail':'Reservation originally labeled semantic snapshot digest as raw. No edits occurred. Root preserved original and corrected canonical binding under same attempt/nonce before source edits; preflight-corrected.json PASS.'},
 {'evidence':'prechange.log','classification':'five causal source regressions','counts':runs['prechange']['counts'],'detail':'Immutable source4: stale handback accepted, external release selected without final proof, failed QA entered implementation, QA takeover published, native409 ownership wrapped as generic invalid state. Zero harness errors.'},
 {'evidence':'causal-fixed.log','classification':'fixture error after four causal fixes passed','counts':runs['causal-fixed']['counts'],'detail':'F5 finally reached B, exposing fixture duplicate PR81 on A/B. Assigned synthetic B PR82 and feedback by PR identity; no source workaround. causal-fixed2 all5 PASS.'},
 {'evidence':'focused-first.log','classification':'two obsolete expected outcomes after intentional behavior changes','counts':runs['focused-first']['counts'],'detail':'Malformed handback now rejects before effects; typed ownership CAS now skips successfully. Updated expectations and retained all no-effect/owner-byte assertions.'},
 {'evidence':'same-entity-pre-fix.log','classification':'one additional causal source regression, counted child+parent failures','counts':runs['same-entity-pre-fix']['counts'],'detail':'Top-level handback child PASS; takeover changing A.operatorCoordination plus data child failed state-rebase-conflict before ownership callback. Narrow after-definitive409 ownership hook fixes this; final suite both children PASS.'},
]
write('failure-history.json',failures)
reads=['author5/task-contract.md','author5/allowlist.json','author5/reservation.json','author5/reservation-initial-semantic-digest-mislabeled-before-source-edits.json','source5-before.json','publication4/actual-Claude1-comment-changes-requested.json','author4/source-manifest.json','author4/seal.json']
write('read-receipts.json',{'inputs':{name:meta(p/name) for name in reads},'sourceFilesBefore':138,'source4AfterByteVerification':True,'commentId':6353848644,'actualClaudeVerdict':'changes-requested','reviewFindings':5,'attempt':5,'nonce':r['nonce'],'canonicalReservation':r['stateCommit']})
syntax=json.loads((a/'syntax.json').read_text());assert syntax['passed']==13 and syntax['failed']==0
results={'status':'IMPLEMENTED_AWAITING_INDEPENDENT_QA','attempt':5,'model':'gpt-6.1-sol','nonce':r['nonce'],'source':str(s),'sourceHead':r['sourceHead'],'baselineCode':r['baselineCode'],'actualDeltaPaths':changes,'actualDeltaCount':len(changes),'cumulativePaths':len(cumulative),'actualFinalFocusedTests':runs['focused-final']['counts'],'actualFinalNativeCompatibilityTests':runs['native-compatibility-final']['counts'],'totalDisjointFinalTests':715,'syntax':{'passed':13,'failed':0},'findingsAddressed':['F1','F2','F3','F4','F5'],'failureHistory':'failure-history.json','priorImplementationEntriesPreservedByScope':4,'actualClaude1ChangesRequestedPreserved':True,'reviewApprovalClaimed':False,'clinicalE2ERerun':False,'liveActions':False,'sourceFrozen':True}
write('results.json',results)
report='''# Source continuation5 — implemented, awaiting independent QA

All five authentic Claude1 findings on PR504 have source fixes and causal regressions. This is author evidence, not QA approval, model review approval, native adoption, merge, activation or deployment.

## Scope and lineage

The reserved source5 snapshot contains exactly138 files, initially byte-identical to immutable source4. All15 allowed paths changed; no other source bytes or file modes changed and no extra source files appeared. Cumulative current code/test/docs scope is COUNT paths. Parent source head remains ce7993a781bd2d378a1ca3ad2956b2c3606b4fe2 and code4 cb2d095926282918777b9dd73a37ef7d90bb7b2f; only root may create the descendant commit. The fourth native implementation passed result and actual Claude1 changes-requested remain historical facts. Root performed typed budget4→5 and the actual fifth reservation before this author session; no attempt, review ledger or grant was reset or invented here.

The first preflight found a mislabeled manifest digest. All138 source bytes matched source4; no source edit preceded correction. Root durably corrected raw versus semantic digest labels under the same attempt/nonce, preserving the original reservation. Both preflight receipts are retained.

## F1 — bound canonical handback

`operator-ownership.validAutomationHandback` checks the complete audit/schema; `automationPaused` also requires exact nonempty takeover nonce equality. The trusted canonical writer records authorizedActor after actual permission verification; this string does not itself authenticate anyone. UTC ISO timestamp validity rejects invalid calendar dates. `contracts.validateState` rejects malformed handbacks; legacy takeover without a handback and a well-formed stale grant remain readable, paused data. All former valid handback fixtures were bound explicitly. Tests cover stale nonce before intake/selection and zero mutation, valid grant unowned work, malformed audit, legacy pause and preserved claims.

## F2 — release final Codex gate

`release.hasFinalCodexProof` recognizes every external channel by the durable externalReview object and checks verified status, proof.subjectSha equal to supplied release reviewedSha and batch.sha, latest Claude round and current approved feedback identity. No new proof.reviewedSha field is required. Selection skips missing/stale proof; releaseBatch and verifyReviewProof refuse it; freshReleaseGuard rechecks before native effects; recordDeployment reaches the same review-proof gate. Existing internal mode needs no invented external proof. Tests exercise both comment and legacy external channels, missing/nonverified/SHA/round/fingerprint failure, matching proof actual merge, fresh proof drift zero effects and deployment recording refusal. Native/human/source/provider/SHA checks are unchanged.

## F3 — infrastructure retries separate from corrections

`external-review.runExternalReviewStep` archives failed/blocked/waiting-checks final records before retry. A separate durable codexFinalQaInfrastructure.attempts ledger permits at most3 reserved final-QA inference sessions for one SHA/Claude-round/feedback identity. Native-check and pre-inference identity polling reserve no inference slot. A legacy failed session is imported as already spent. Running remains owned. Blocked batch phase is never auto-unblocked; operator recovery must precede retry. Exhaustion blocks with final-qa-infrastructure-exhausted and retains records. Exceptions and unusable verdicts record failed infrastructure and never reserve code correction. A genuine model blocked-with-findings retains the existing mapping to changes-requested, which alone sends final-QA findings to reserveImplementation. All existing before/after PR identity, feedback and native checks remain. Tests show recovered failure invokes finalQa only, bounded repeated failures, explicit recovery, no implementation budget consumption, polling without inference consumption, invalid verdict refusal and real findings correction.

## F4 — fresh internal call boundaries

`pipeline.freshOwnership` re-reads current canonical ownership before save and each asynchronous workspace model/effect boundary (prepare, execute, verify, simplify, qa/finalQa, checkpoint, publish, review, evidence) and GitHub mutation boundary. This also covers prebuilt workspace implementations and each report/status effect. Initial implementation, PR feedback correction and internal Claude correction cannot checkpoint, push, createDraft, publish comments/status or diagnose/block an operator-owned subject after observing takeover. Canonical running reservations already durable stay as tombstones; unsaved completion/failure edits are discarded. Regression takeover occurs inside QA in all three real internal paths and checks exact unchanged canonical subject bytes with zero later effects. Existing AsyncLocalStorage native controller handling, concurrent/default explicit Max authorization and SHA rules remain unchanged and pass native compatibility tests.

## F5 — finite known CAS ownership loss

`github.createStateStore.observe()` uses an independent native state reader. It never advances the writer's remembered Contents SHA or base; the observer regression requires a real rejected409 followed by independently validated rebase and retains concurrent B data.

`save(...,{checkFreshOwnership})` optionally validates/checks freshly loaded canonical ownership only after a definite rejected409 and successful fresh load, before mergeIndependentEntities. Pipeline supplies full validateState/standalone validation then exact ownership. Typed review-operator-owned propagates unchanged, including the original merged validator path. All other merge/schema/auth/write failures retain their original fatal behavior. The hook never runs after403/502/timeout. Unowned same-entity A or B conflicts and malformed fresh state still fail.

Pipeline catches only the finite observed ownership-loss code without persistence failure, reloads canonical state, discards unsaved A changes and resolves subsequent subjects by identity. Native409 regressions cover both bound partial handback and takeover also changing A.operatorCoordination plus remote A data: A remains byte-identical and eligible B completes ready. No owned label, block or overwrite is issued. Global pause protects all. Generic conflicts or uncertain writes are not skips.

## Validation and preserved failures

Final affected7 suites:564/564 PASS. Final native compatibility4 suites:151/151 PASS. These are disjoint715 tests, not a count of repeated runs. Syntax13/13 PASS. Commands, exact exits/stdout and counts are retained. Earlier5 causal source failures, one reached-B fixture failure, two intentionally outdated expectations and the additional same-entity ownership causal failure remain in failure-history.json and raw logs. No unresolved author test failure remains.

Prior source4 QA/CI remains scoped historical evidence only; no clinical E2E or live provider test was repeated. All checks used injected offline boundaries; any fixture Git used only owned temporary paths, disabled hooks/global config and network protocols. No network/API/provider/model/credential/DB/browser/live Git/canonical mutation occurred. Independent QA, actual native/model review, protected publication and activation remain root-owned.
'''.replace('COUNT',str(len(cumulative)))
(a/'report.md').write_text(report)
write('STOP.json',{'status':'STOP','reason':'Author5 five Claude findings implemented and byte-bound tests complete. Await independent QA; no approval, publication or live continuation claimed.','nonce':r['nonce'],'source':str(s),'sourceEditsStopped':True,'stoppedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
# Private temporary fixture files are excluded. All durable top-level author files,
# including original contracts/reservations and every failed run, are sealed.
seal={'status':'IMPLEMENTED_AWAITING_INDEPENDENT_QA','nonce':r['nonce'],'files':{f.name:meta(f) for f in sorted(a.iterdir()) if f.is_file() and f.name!='seal.json'},'excluded':['owned-tmp/ temporary synthetic fixtures'],'sourceManifestSha256':meta(a/'source-manifest.json')['sha256']}
write('seal.json',seal)
print(json.dumps({'sourceManifestSha256':meta(a/'source-manifest.json')['sha256'],'sealSha256':meta(a/'seal.json')['sha256'],'sourceChanges':len(changes),'cumulativePaths':len(cumulative),'sealedFiles':len(seal['files']),'status':results['status']},indent=2))
