from pathlib import Path
p=Path('/tmp/clinicos-autonomy-activation-20261022');s=p/'source5';a=p/'author5'
def edit(name,fn):
 f=s/name;f.write_text(fn(f.read_text()))
prod='agent-team/src/bug-pipeline/'
edit(prod+'operator-ownership.mjs',lambda t:t.replace('export function automationPaused(state) {', '''// Audit fields describe the authorized canonical handback; they never authenticate
// a GitHub actor themselves. Only the trusted state writer may record this grant.
export function validAutomationHandback(handback) {
  return Boolean(
    handback && typeof handback === 'object' && !Array.isArray(handback) &&
    typeof handback.enabled === 'boolean' &&
    handback.mode === 'new-unclaimed-only' &&
    typeof handback.takeoverNonce === 'string' && handback.takeoverNonce.trim() &&
    typeof handback.authorizedActor === 'string' && handback.authorizedActor.trim() &&
    typeof handback.handedBackAt === 'string' &&
    /^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d{3})?Z$/.test(handback.handedBackAt) &&
    Number.isFinite(Date.parse(handback.handedBackAt)) &&
    new Date(handback.handedBackAt).toISOString().replace('.000Z', 'Z') ===
      handback.handedBackAt.replace('.000Z', 'Z') &&
    Array.isArray(handback.protectedSubjects) && handback.protectedSubjects.every(validIdentity)
  );
}

export function automationPaused(state) {''').replace('''    handback?.enabled === true &&
    handback.mode === 'new-unclaimed-only' &&
    Array.isArray(handback.protectedSubjects) &&
    handback.protectedSubjects.every(validIdentity)''','''    validAutomationHandback(handback) && handback.enabled === true &&
    typeof state.operatorTakeover.nonce === 'string' && state.operatorTakeover.nonce.trim() &&
    handback.takeoverNonce === state.operatorTakeover.nonce'''))
edit(prod+'contracts.mjs',lambda t:t.replace("import path from 'node:path';","import path from 'node:path';\nimport { validAutomationHandback } from './operator-ownership.mjs';").replace('  const issues = new Set();\n  for (const b of state.batches)', '''  // Legacy takeovers without a handback stay valid and globally paused. A stale
  // well-formed grant is also valid data, but cannot enable the new nonce.
  if (state.operatorTakeover?.automation !== undefined &&
      !validAutomationHandback(state.operatorTakeover.automation))
    throw new Error('invalid operator automation handback');
  const issues = new Set();
  for (const b of state.batches)'''))
edit(prod+'release.mjs',lambda t:t.replace("          batch.approvedSha === batch.sha &&", "          batch.approvedSha === batch.sha &&\n          hasFinalCodexProof(batch, batch.sha) &&",1).replace('function verifyReviewProof(batch, sha) {', '''function hasFinalCodexProof(batch, sha) {
  // Both comment handoffs and the original external worker persist externalReview;
  // the channel value is not an authorization switch.
  if (!batch.externalReview) return true;
  const proof = batch.codexFinalReview;
  return Boolean(proof?.status === 'verified' && proof.subjectSha === sha &&
    proof.reviewedSha === sha && sha === batch.sha &&
    proof.claudeRound === batch.reviews.length &&
    typeof batch.feedbackFingerprint === 'string' && batch.feedbackFingerprint.length > 0 &&
    proof.feedbackFingerprint === batch.feedbackFingerprint &&
    batch.externalReview.subjectSha === sha &&
    batch.externalReview.feedbackFingerprint === batch.feedbackFingerprint);
}
function verifyFinalCodexProof(batch, sha) {
  if (!hasFinalCodexProof(batch, sha))
    fail('external review requires verified final Codex proof for this SHA, round and feedback');
}

function verifyReviewProof(batch, sha) {
  verifyFinalCodexProof(batch, sha);''').replace('''    assertNoReleaseHold(current);
    if (!current''','''    assertNoReleaseHold(current);
    if (current) verifyFinalCodexProof(current, current.sha);
    if (!current''').replace('''  assertNoReleaseHold(batch);
  assertSavedPolicy(batch, sourcePolicy);''','''  assertNoReleaseHold(batch);
  verifyFinalCodexProof(batch, reviewedSha);
  assertSavedPolicy(batch, sourcePolicy);''',1))
# F5 keep known ownership loss distinct from uncertain writes and invalid schemas.
edit(prod+'github.mjs',lambda t:t.replace('''          } catch (error) {
            throw stateError(
              'state-rebase-invalid',''','''          } catch (error) {
            if (error?.code === 'review-operator-owned') throw error;
            throw stateError(
              'state-rebase-invalid',''',1))
# Install already reproduced source-level regressions, with original fixture bodies.
for name in ['operator-ownership','release','external-review','pipeline']:
 edit('agent-team/tests/bug-pipeline/'+name+'.test.mjs',lambda t,n=name:t+(a/f'regression-{n}.txt').read_text())
# Bind all formerly valid handbacks, keeping all previous normal-path tests meaningful.
for name in ['operator-ownership','pipeline','issue-review-sync']:
 f='agent-team/tests/bug-pipeline/'+name+'.test.mjs'
 edit(f,lambda t:t.replace('''  active: true,
  automation:''','''  active: true,
  nonce: 'test-takeover',
  automation:''').replace("enabled: true, mode: 'new-unclaimed-only', protectedSubjects },", "enabled: true, mode: 'new-unclaimed-only', protectedSubjects, takeoverNonce: 'test-takeover', authorizedActor: 'maintainer', handedBackAt: '2026-10-22T00:00:00Z' },").replace("    mode: 'new-unclaimed-only',\n    protectedSubjects: [],\n  },\n});", "    mode: 'new-unclaimed-only',\n    takeoverNonce: 'test-takeover', authorizedActor: 'maintainer', handedBackAt: '2026-10-22T00:00:00Z',\n    protectedSubjects: [],\n  },\n});",1))
edit('agent-team/tests/bug-pipeline/release.test.mjs',lambda t:t.replace("f.state.operatorTakeover = { active: true };\n  assert.equal(selectAutoReleaseBatch", "f.state.operatorTakeover = { active: true, nonce: 'test-takeover' };\n  assert.equal(selectAutoReleaseBatch",1).replace("f.state.operatorTakeover.automation = {\n    enabled: true,", "f.state.operatorTakeover.automation = {\n    takeoverNonce: 'test-takeover', authorizedActor: 'maintainer', handedBackAt: '2026-10-22T00:00:00Z',\n    enabled: true,",1))
